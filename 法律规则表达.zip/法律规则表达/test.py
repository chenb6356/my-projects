
from main import LegalRuleProcessor


def test_marriage_family():
    print('=== 测试婚姻家庭纠纷 ===')
    processor = LegalRuleProcessor()
    
    text = '''案由：婚姻家庭纠纷
·《中华人民共和国民法典》第五编
2021年1月1日施行
·《民法典婚姻家庭编解释（一）》
2021年1月1日施行
·《民法典婚姻家庭编解释（二）》
2025年2月1日施行
·《涉彩礼纠纷规定》
2024年2月1日施行
'''
    
    result = processor.process(text, 'marriage', '婚姻家庭纠纷')
    json_file = processor.save_json(result, 'test_marriage.json')
    html_file = processor.generate_visualization(result, 'test_marriage.html')
    
    print('  婚姻家庭纠纷测试完成')
    print('  实体数: {}'.format(len(result['entities'])))
    print('  关系数: {}'.format(len(result['relations'])))
    print('  JSON文件: {}'.format(json_file))
    print('  可视化文件: {}'.format(html_file))
    print()


if __name__ == '__main__':
    print('婚姻家庭纠纷法律规则表达系统 - 自动化测试')
    print('=' * 50)
    print()
    
    test_marriage_family()
    
    print('=' * 50)
    print('所有测试完成！')
