
import json
import os
from datetime import datetime
from config import DOMAINS, NODE_COLORS, OUTPUT_DIR, VISUALIZATION_DIR
from models import Entity, Relation
from parsers import MarriageParser


class LegalRuleProcessor:
    def __init__(self):
        self.parsers = {
            'marriage': MarriageParser()
        }
    
    def process(self, text, domain, title='婚姻家庭纠纷'):
        if domain not in self.parsers:
            raise ValueError('不支持的领域: {}'.format(domain))
        
        parser = self.parsers[domain]
        entities, relations = parser.parse(text, title)
        
        result = {
            'metadata': {
                'domain': domain,
                'title': title,
                'source': DOMAINS[domain],
                'timestamp': datetime.now().isoformat()
            },
            'entities': [e.to_dict() for e in entities],
            'relations': [r.to_dict() for r in relations],
            'content': {
                'structure': {},
                'elements': {}
            }
        }
        
        return result
    
    def save_json(self, data, filename=None):
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = 'legal_rule_{}.json'.format(timestamp)
        
        filepath = os.path.join(OUTPUT_DIR, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        return filepath
    
    def generate_visualization(self, data, filename=None):
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = 'visualization_{}.html'.format(timestamp)
        
        filepath = os.path.join(VISUALIZATION_DIR, filename)
        
        nodes = []
        for entity in data['entities']:
            nodes.append({
                'id': entity['id'],
                'name': entity['name'],
                'category': entity['type'],
                'symbolSize': 30,
                'itemStyle': {
                    'color': NODE_COLORS.get(entity['type'], '#999999')
                }
            })
        
        links = []
        for relation in data['relations']:
            links.append({
                'source': relation['source'],
                'target': relation['target'],
                'name': relation['type']
            })
        
        html_content = self._generate_html(nodes, links, data['metadata']['title'])
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return filepath
    
    def _generate_html(self, nodes, links, title):
        html_template = '''<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{title}</title>
    <style>
        body {{ 
            margin: 0; 
            padding: 20px; 
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }}
        h1 {{ 
            text-align: center; 
            color: #333;
            margin-bottom: 30px;
        }}
        #main {{ 
            width: 100%; 
            height: 700px; 
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .info {{ 
            text-align: center; 
            margin-top: 20px; 
            color: #666;
            font-size: 14px;
        }}
        .entity-list, .relation-list {{ 
            margin-top: 30px;
            text-align: left;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }}
        ul {{ 
            list-style: none;
            padding: 0;
        }}
        li {{ 
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }}
        .bold {{ 
            font-weight: bold;
        }}
    </style>
</head>
<body>
    <h1>{title}</h1>
    <div id="main"></div>
    <div class="info">
        实体数: {entity_count} | 关系数: {relation_count}
    </div>
    
    <script type="text/javascript">
        var entity_count = {entity_count};
        var relation_count = {relation_count};
        var nodes_data = {nodes_json};
        var links_data = {links_json};
        
        window.onload = function() {{
            var mainDiv = document.getElementById('main');
            mainDiv.innerHTML = '';
            
            var content = document.createElement('div');
            content.style.padding = '40px';
            content.style.textAlign = 'center';
            
            var title = document.createElement('h2');
            title.textContent = '{title}';
            content.appendChild(title);
            
            var entityInfo = document.createElement('p');
            entityInfo.textContent = '实体数: ' + entity_count + ' | 关系数: ' + relation_count;
            entityInfo.style.fontSize = '16px';
            entityInfo.style.color = '#666';
            content.appendChild(entityInfo);
            
            var entityList = document.createElement('div');
            entityList.className = 'entity-list';
            
            var entityTitle = document.createElement('h3');
            entityTitle.textContent = '实体列表:';
            entityList.appendChild(entityTitle);
            
            var entityUl = document.createElement('ul');
            
            nodes_data.forEach(function(node) {{
                var li = document.createElement('li');
                li.innerHTML = '<span class="bold">' + node.name + '</span> - ' + node.category;
                entityUl.appendChild(li);
            }});
            
            entityList.appendChild(entityUl);
            content.appendChild(entityList);
            
            var relationList = document.createElement('div');
            relationList.className = 'relation-list';
            
            var relationTitle = document.createElement('h3');
            relationTitle.textContent = '关系列表:';
            relationList.appendChild(relationTitle);
            
            var relationUl = document.createElement('ul');
            
            links_data.forEach(function(link) {{
                var sourceNode = nodes_data.find(function(n) {{ return n.id === link.source; }});
                var targetNode = nodes_data.find(function(n) {{ return n.id === link.target; }});
                
                var li = document.createElement('li');
                li.innerHTML = sourceNode.name + ' → ' + link.name + ' → ' + targetNode.name;
                relationUl.appendChild(li);
            }});
            
            relationList.appendChild(relationUl);
            content.appendChild(relationList);
            
            mainDiv.appendChild(content);
        }};
    </script>
</body>
</html>'''
        
        return html_template.format(
            title=title,
            entity_count=len(nodes),
            relation_count=len(links),
            nodes_json=json.dumps(nodes, ensure_ascii=False),
            links_json=json.dumps(links, ensure_ascii=False)
        )


def main():
    import sys
    
    processor = LegalRuleProcessor()
    
    print('=== 婚姻家庭纠纷法律规则表达系统 ===')
    print()
    
    sample_text = '''案由：婚姻家庭纠纷
·《中华人民共和国民法典》第五编
2021年1月1日施行
·《民法典婚姻家庭编解释（一）》
2021年1月1日施行
·《民法典婚姻家庭编解释（二）》
2025年2月1日施行
·《涉彩礼纠纷规定》
2024年2月1日施行
'''
    
    print('选择输入方式:')
    print('  1: 使用示例数据 (婚姻家庭纠纷)')
    print('  2: 自定义输入')
    print()
    
    choice = input('请输入选择 (1-2): ').strip()
    
    domain = 'marriage'
    text = None
    title = None
    
    if choice == '1':
        text = sample_text
        title = '婚姻家庭纠纷'
    elif choice == '2':
        title = input('请输入案由标题 (默认: 婚姻家庭纠纷): ').strip()
        if not title:
            title = '婚姻家庭纠纷'
        print('请输入法条内容 (输入完后按Ctrl+Z或Ctrl+D结束):')
        print('格式示例:')
        print('  案由：婚姻家庭纠纷')
        print('  ·《中华人民共和国民法典》第五编')
        print('  2021年1月1日施行')
        print()
        try:
            text = sys.stdin.read()
        except:
            print('读取输入失败！')
            return
    else:
        print('无效选择！')
        return
    
    print()
    print('正在处理...')
    print('领域: 婚姻家庭纠纷')
    print('标题: {}'.format(title))
    print()
    
    try:
        result = processor.process(text, domain, title)
        json_file = processor.save_json(result)
        html_file = processor.generate_visualization(result)
        
        print('处理完成！')
        print('JSON文件: {}'.format(json_file))
        print('可视化文件: {}'.format(html_file))
        print()
        print('共提取 {} 个实体'.format(len(result['entities'])))
        print('共建立 {} 个关系'.format(len(result['relations'])))
        
    except Exception as e:
        print('错误: {}'.format(e))


if __name__ == '__main__':
    main()
