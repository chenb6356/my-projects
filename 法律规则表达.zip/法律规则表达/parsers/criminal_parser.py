
import re
from models import Entity, Relation


class CriminalParser:
    def __init__(self):
        self.entities = []
        self.relations = []
    
    def parse(self, text, title='刑事法律条文'):
        self.entities = []
        self.relations = []
        
        law_entity = Entity(title, 'law', {'source': '刑法', 'content': text[:200]})
        self.entities.append(law_entity)
        
        articles = self._extract_articles(text)
        
        for idx, article_text in enumerate(articles):
            article_title = '第{}条'.format(idx+1)
            article_entity = Entity(article_title, 'article', {'content': article_text})
            self.entities.append(article_entity)
            self.relations.append(Relation(law_entity.id, article_entity.id, 'constitutes'))
            
            crimes = self._extract_crimes(article_text)
            for crime_name in crimes:
                crime_entity = Entity(crime_name, 'crime', {})
                self.entities.append(crime_entity)
                self.relations.append(Relation(article_entity.id, crime_entity.id, 'defines'))
                
                elements = self._extract_crime_elements(article_text)
                for elem_name in elements:
                    elem_entity = Entity(elem_name, 'element', {})
                    self.entities.append(elem_entity)
                    self.relations.append(Relation(crime_entity.id, elem_entity.id, 'constitutes'))
                
                liabilities = self._extract_liabilities(article_text)
                for liab_name in liabilities:
                    liab_entity = Entity(liab_name, 'liability', {})
                    self.entities.append(liab_entity)
                    self.relations.append(Relation(crime_entity.id, liab_entity.id, 'punishes'))
        
        return self.entities, self.relations
    
    def _extract_articles(self, text):
        pattern = r'第[一二三四五六七八九十百千万\d]+条'
        parts = re.split(pattern, text)
        return [p.strip() for p in parts if p.strip()]
    
    def _extract_crimes(self, text):
        crimes = []
        keywords = ['故意', '过失', '盗窃', '诈骗', '抢劫', '伤害', '杀人']
        for keyword in keywords:
            if keyword in text:
                crimes.append(keyword)
        return list(set(crimes))
    
    def _extract_crime_elements(self, text):
        elements = []
        keywords = ['主体', '客体', '主观方面', '客观方面', '行为', '结果', '因果关系']
        for keyword in keywords:
            if keyword in text:
                elements.append(keyword)
        return elements
    
    def _extract_liabilities(self, text):
        liabilities = []
        keywords = ['有期徒刑', '无期徒刑', '死刑', '拘役', '管制', '罚金', '没收财产']
        for keyword in keywords:
            if keyword in text:
                liabilities.append(keyword)
        return liabilities
