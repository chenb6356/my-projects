
import re
from models import Entity, Relation


class AdminParser:
    def __init__(self):
        self.entities = []
        self.relations = []
    
    def parse(self, text, title='行政法律条文'):
        self.entities = []
        self.relations = []
        
        law_entity = Entity(title, 'law', {'source': '行政法', 'content': text[:200]})
        self.entities.append(law_entity)
        
        articles = self._extract_articles(text)
        
        for idx, article_text in enumerate(articles):
            article_title = '第{}条'.format(idx+1)
            article_entity = Entity(article_title, 'article', {'content': article_text})
            self.entities.append(article_entity)
            self.relations.append(Relation(law_entity.id, article_entity.id, 'constitutes'))
            
            elements = self._extract_elements(article_text)
            for elem_name in elements:
                elem_entity = Entity(elem_name, 'element', {})
                self.entities.append(elem_entity)
                self.relations.append(Relation(article_entity.id, elem_entity.id, 'applies_to'))
        
        return self.entities, self.relations
    
    def _extract_articles(self, text):
        pattern = r'第[一二三四五六七八九十百千万\d]+条'
        parts = re.split(pattern, text)
        return [p.strip() for p in parts if p.strip()]
    
    def _extract_elements(self, text):
        elements = []
        keywords = ['行政机关', '公民', '法人', '其他组织', '许可', '处罚', '强制', '复议', '诉讼']
        for keyword in keywords:
            if keyword in text:
                elements.append(keyword)
        return elements
