
from .marriage_parser import MarriageParser

__all__ = ['MarriageParser']
