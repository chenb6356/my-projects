
import re
from models import Entity, Relation


class MarriageParser:
    def __init__(self):
        self.entities = []
        self.relations = []
    
    def parse(self, text, title='婚姻家庭纠纷'):
        self.entities = []
        self.relations = []
        
        cause_entity = Entity(title, 'cause', {'source': '婚姻家庭纠纷', 'content': text[:200]})
        self.entities.append(cause_entity)
        
        lines = self._extract_lines(text)
        
        current_law_entity = None
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            if '案由' in line:
                cause_name = self._extract_cause_name(line)
                if cause_name:
                    # 更新案由实体
                    cause_entity.name = cause_name
            elif '《' in line and '》' in line:
                law_name = self._extract_law_name(line)
                current_law_entity = Entity(law_name, 'law', {'full_text': line})
                self.entities.append(current_law_entity)
                self.relations.append(Relation(cause_entity.id, current_law_entity.id, 'includes'))
                
                if '解释' in law_name:
                    interpretation_entity = Entity(law_name, 'interpretation', {'full_text': line})
                    self.entities.append(interpretation_entity)
                    self.relations.append(Relation(cause_entity.id, interpretation_entity.id, 'includes'))
            elif '年' in line and '月' in line and '日' in line:
                date = self._extract_date(line)
                if date and current_law_entity:
                    date_entity = Entity(date, 'date', {})
                    self.entities.append(date_entity)
                    self.relations.append(Relation(current_law_entity.id, date_entity.id, 'enforces_on'))
        
        return self.entities, self.relations
    
    def _extract_lines(self, text):
        return text.split('\n')
    
    def _extract_cause_name(self, line):
        match = re.search(r'案由[：:]\s*([^·]+)', line)
        if match:
            return match.group(1).strip()
        return '婚姻家庭纠纷'
    
    def _extract_law_name(self, line):
        match = re.search(r'《([^》]+)》', line)
        if match:
            return match.group(1).strip()
        return line.strip()
    
    def _extract_date(self, line):
        pattern = r'(\d{4})年(\d{1,2})月(\d{1,2})日'
        match = re.search(pattern, line)
        if match:
            return '{}-{}-{}'.format(match.group(1), match.group(2), match.group(3))
        return None
