
DOMAINS = {
    'marriage': '婚姻家庭纠纷'
}

ENTITY_TYPES = [
    'law',
    'article',
    'cause',
    'interpretation',
    'provision',
    'date',
    'concept'
]

RELATION_TYPES = [
    'refers_to',
    'includes',
    'implements',
    'applies_to',
    'enforces_on',
    'relates_to',
    'supersedes'
]

NODE_COLORS = {
    'law': '#4A90E2',
    'article': '#50E3C2',
    'cause': '#E74C3C',
    'interpretation': '#F39C12',
    'provision': '#9B59B6',
    'date': '#1ABC9C',
    'concept': '#95A5A6'
}

OUTPUT_DIR = 'output'
TEMPLATES_DIR = 'templates'
VISUALIZATION_DIR = 'visualization'
