
# 法律规则表达系统

## 系统概述
这是一个将法律规则自动处理系统，支持民法、刑法、行政法三大领域，将法条文本自动转换为结构化JSON文档和可视化知识图谱。

## 文件结构
```
e:\法律规则表达\
├── main.py                 # 主程序入口
├── config.py               # 配置文件
├── test.py                 # 测试脚本
├── parsers/                # 解析器目录
│   ├── __init__.py
│   ├── civil_parser.py     # 民法解析器
│   ├── criminal_parser.py  # 刑法解析器
│   └── admin_parser.py     # 行政法解析器
├── models/                 # 数据模型目录
│   ├── __init__.py
│   ├── entity.py           # 实体模型
│   └── relation.py         # 关系模型
├── output/                 # 输出目录（存放生成的JSON文件
├── templates/                # 模板目录
│   └── json_schema.json    # JSON规范模板
└── visualization/            # 可视化目录（存放生成的HTML文件
```

## 使用方法

### 1. 运行自动化测试
```bash
python test.py
```

### 2. 运行交互式程序
```bash
python main.py
```

## 支持领域
- **civil**: 民法
- **criminal**: 刑法
- **admin**: 行政法

## 输出格式

### JSON文档
生成的JSON包含以下部分：
- **metadata**: 元数据（领域、标题、来源、时间戳
- **entities**: 实体列表
- **relations**: 关系列表
- **content**: 内容结构

### 可视化链图
生成的HTML文件使用ECharts实现，支持：
- 节点颜色区分不同实体类型
- 连线表示实体关系
- 支持缩放、拖拽、点击查看详情

## 核心功能
1. 法条文本解析
2. 实体自动抽取
3. 关系自动构建
4. JSON规范生成
5. 知识图谱可视化
6. 多领域支持

## 实体类型
- law: 法律
- article: 法条
- crime: 罪名
- element: 构成要件
- liability: 法律责任
- case: 案例
- interpretation: 司法解释
- doctrine: 学说
