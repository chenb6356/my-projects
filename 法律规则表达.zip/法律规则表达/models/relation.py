
import uuid


class Relation:
    def __init__(self, source_id, target_id, relation_type, properties=None):
        self.id = str(uuid.uuid4())
        self.source_id = source_id
        self.target_id = target_id
        self.relation_type = relation_type
        self.properties = properties or {}
    
    def to_dict(self):
        return {
            'id': self.id,
            'source': self.source_id,
            'target': self.target_id,
            'type': self.relation_type,
            'properties': self.properties
        }
    
    @classmethod
    def from_dict(cls, data):
        relation = cls(
            source_id=data['source'],
            target_id=data['target'],
            relation_type=data['type'],
            properties=data.get('properties', {})
        )
        relation.id = data['id']
        return relation
