
import uuid


class Entity:
    def __init__(self, name, entity_type, properties=None):
        self.id = str(uuid.uuid4())
        self.name = name
        self.entity_type = entity_type
        self.properties = properties or {}
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'type': self.entity_type,
            'properties': self.properties
        }
    
    @classmethod
    def from_dict(cls, data):
        entity = cls(
            name=data['name'],
            entity_type=data['type'],
            properties=data.get('properties', {})
        )
        entity.id = data['id']
        return entity
