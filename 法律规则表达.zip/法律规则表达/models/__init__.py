
from .entity import Entity
from .relation import Relation

__all__ = ['Entity', 'Relation']
