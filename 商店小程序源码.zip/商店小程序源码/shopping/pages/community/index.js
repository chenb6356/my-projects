// 模拟帖子数据
const mockPosts = [
  {
    id: 1,
    user: {
      id: 1,
      nickname: "用户A",
      avatar: "https://picsum.photos/100/100?random=1"
    },
    content: "刚买的新衣服，质量特别好，分享给大家！",
    images: [
      "https://picsum.photos/400/400?random=1",
      "https://picsum.photos/400/400?random=2"
    ],
    createTime: "2024-01-15 10:00:00",
    likes: 12,
    comments: [
      {
        id: 1,
        user: {
          id: 2,
          nickname: "用户B",
          avatar: "https://picsum.photos/100/100?random=2"
        },
        content: "看起来不错，请问多少钱呢？",
        createTime: "2024-01-15 10:30:00"
      }
    ]
  },
  {
    id: 2,
    user: {
      id: 3,
      nickname: "用户C",
      avatar: "https://picsum.photos/100/100?random=3"
    },
    content: "今天收到了优惠券，准备买点好吃的，有推荐的吗？",
    images: [],
    createTime: "2024-01-15 09:00:00",
    likes: 5,
    comments: []
  }
];

Page({
  data: {
    posts: [],
    showPublish: false,
    newPost: {
      content: "",
      images: []
    },
    tabs: [
      {
        id: 0,
        value: "最新",
        isActive: true
      },
      {
        id: 1,
        value: "热门",
        isActive: false
      },
      {
        id: 2,
        value: "关注",
        isActive: false
      }
    ]
  },

  onLoad() {
    this.getPosts();
  },

  // 获取帖子列表
  getPosts() {
    // 模拟获取帖子数据
    this.setData({
      posts: mockPosts
    });
  },

  // 切换标签
  handleTabsItemChange(e) {
    const { index } = e.detail;
    let { tabs } = this.data;
    tabs.forEach((v, i) => i === index ? v.isActive = true : v.isActive = false);
    this.setData({
      tabs
    });
    // 根据标签重新获取帖子
    this.getPosts();
  },

  // 显示发帖面板
  showPublishPanel() {
    this.setData({
      showPublish: true
    });
  },

  // 隐藏发帖面板
  hidePublishPanel() {
    this.setData({
      showPublish: false,
      newPost: {
        content: "",
        images: []
      }
    });
  },

  // 输入帖子内容
  handleInput(e) {
    this.setData({
      'newPost.content': e.detail.value
    });
  },

  // 选择图片
  handleChooseImage() {
    const { images } = this.data.newPost;
    const count = 9 - images.length;
    if (count <= 0) {
      wx.showToast({
        title: '最多选择9张图片',
        icon: 'none'
      });
      return;
    }
    wx.chooseImage({
      count,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        this.setData({
          'newPost.images': [...images, ...res.tempFilePaths]
        });
      }
    });
  },

  // 删除图片
  handleDeleteImage(e) {
    const { index } = e.currentTarget.dataset;
    const { images } = this.data.newPost;
    images.splice(index, 1);
    this.setData({
      'newPost.images': images
    });
  },

  // 发布帖子
  handlePublish() {
    const { content, images } = this.data.newPost;
    if (!content.trim()) {
      wx.showToast({
        title: '请输入内容',
        icon: 'none'
      });
      return;
    }
    // 模拟发布帖子
    const newPost = {
      id: Date.now(),
      user: {
        id: 1,
        nickname: "我",
        avatar: "https://picsum.photos/100/100?random=10"
      },
      content,
      images,
      createTime: new Date().toLocaleString(),
      likes: 0,
      comments: []
    };
    this.setData({
      posts: [newPost, ...this.data.posts]
    });
    this.hidePublishPanel();
    wx.showToast({
      title: '发布成功'
    });
  },

  // 点赞
  handleLike(e) {
    const { index } = e.currentTarget.dataset;
    const { posts } = this.data;
    posts[index].likes++;
    this.setData({ posts });
  },

  // 评论
  handleComment(e) {
    const { postId } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/community/comment/index?post_id=${postId}`
    });
  },

  // 预览图片
  handlePreviewImage(e) {
    const { urls, current } = e.currentTarget.dataset;
    wx.previewImage({
      urls,
      current
    });
  }
}); 