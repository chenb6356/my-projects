// 0 引入 用来发送请求的 方法 一定要把路径补全
import { request } from "../../request/index.js";
import regeneratorRuntime from '../../lib/runtime/runtime';

// 模拟数据
const mockData = {
  swiperList: [
    {
      goods_id: 1,
      image_src: "/images/swiper/swiper1.jpg",
      navigator_url: "/pages/goods_detail/index?goods_id=1"
    },
    {
      goods_id: 2,
      image_src: "/images/swiper/swiper2.jpg",
      navigator_url: "/pages/goods_detail/index?goods_id=2"
    },
    {
      goods_id: 3,
      image_src: "/images/swiper/swiper3.jpg",
      navigator_url: "/pages/goods_detail/index?goods_id=3"
    }
  ],
  catesList: [
    {
      name: "分类1",
      image_src: "/images/cates/cate1.png"
    },
    {
      name: "分类2",
      image_src: "/images/cates/cate2.png"
    },
    {
      name: "分类3",
      image_src: "/images/cates/cate3.png"
    },
    {
      name: "分类4",
      image_src: "/images/cates/cate4.png"
    }
  ],
  floorList: [
    {
      floor_title: {
        name: "时尚女装",
        image_src: "/images/floor/floor_title.jpg"
      },
      product_list: [
        {
          name: "商品1",
          image_src: "/images/floor/floor1.jpg",
          navigator_url: "/pages/goods_list/index?query=女装"
        },
        {
          name: "商品2",
          image_src: "/images/floor/floor2.jpg",
          navigator_url: "/pages/goods_list/index?query=女装"
        },
        {
          name: "商品3",
          image_src: "/images/floor/floor3.jpg",
          navigator_url: "/pages/goods_list/index?query=女装"
        },
        {
          name: "商品4",
          image_src: "/images/floor/floor4.jpg",
          navigator_url: "/pages/goods_list/index?query=女装"
        },
        {
          name: "商品5",
          image_src: "/images/floor/floor5.jpg",
          navigator_url: "/pages/goods_list/index?query=女装"
        }
      ]
    }
  ],
  mockGoods: [
    {
      goods_id: 1,
      goods_name: "测试商品1",
      goods_price: 99.99,
      goods_small_logo: "/images/goods/goods1.jpg"
    },
    {
      goods_id: 2,
      goods_name: "测试商品2",
      goods_price: 199.99,
      goods_small_logo: "/images/goods/goods2.jpg"
    },
    {
      goods_id: 3,
      goods_name: "测试商品3",
      goods_price: 299.99,
      goods_small_logo: "/images/goods/goods3.jpg"
    },
    {
      goods_id: 4,
      goods_name: "测试商品4",
      goods_price: 399.99,
      goods_small_logo: "/images/goods/goods4.jpg"
    },
    {
      goods_id: 5,
      goods_name: "测试商品5",
      goods_price: 499.99,
      goods_small_logo: "/images/goods/goods5.jpg"
    },
    {
      goods_id: 6,
      goods_name: "测试商品6",
      goods_price: 599.99,
      goods_small_logo: "/images/goods/goods6.jpg"
    }
  ]
};

Page({
  data: {
    // 轮播图数组
    swiperList: [],
    // 导航 数组
    catesList:[],
    // 楼层数据
    floorList:[],
    // 随机商品数据
    randomGoods: []
  },
  // 获取轮播图数据
  getSwiperList(){
    // 使用模拟数据
    this.setData({
      swiperList: mockData.swiperList
    });
  },
  // 获取分类导航数据
  getCateList(){
    // 使用模拟数据
    this.setData({
      catesList: mockData.catesList
    });
  },
  // 获取楼层数据
  getFloorList(){
    // 使用模拟数据
    this.setData({
      floorList: mockData.floorList
    });
  },
  // 获取推荐商品数据
  getRecommendGoods() {
    // 获取用户搜索历史
    const searchHistory = wx.getStorageSync('searchHistory') || [];
    
    // 计算权重并排序搜索记录
    const weightedHistory = searchHistory
      .map(item => ({
        ...item,
        // 计算权重：搜索次数 * 0.6 + 时间衰减因子 * 0.4
        weight: item.count * 0.6 + 
          (1 / (1 + (Date.now() - item.lastTime) / (1000 * 60 * 60 * 24))) * 0.4
      }))
      .sort((a, b) => b.weight - a.weight)
      .slice(0, 3); // 取权重最高的3个

    // 获取关键词
    const keywords = weightedHistory.map(item => item.keyword);
    
    // 根据搜索历史筛选商品
    let recommendGoods = [];
    if (keywords.length > 0) {
      // 基于搜索历史推荐商品
      recommendGoods = mockData.mockGoods.filter(good => {
        return keywords.some(keyword => 
          good.goods_name.toLowerCase().includes(keyword.toLowerCase())
        );
      });

      // 根据关键词权重排序商品
      recommendGoods.sort((a, b) => {
        const aScore = keywords.reduce((score, keyword) => {
          return score + (a.goods_name.toLowerCase().includes(keyword.toLowerCase()) ? 1 : 0);
        }, 0);
        const bScore = keywords.reduce((score, keyword) => {
          return score + (b.goods_name.toLowerCase().includes(keyword.toLowerCase()) ? 1 : 0);
        }, 0);
        return bScore - aScore;
      });
    }
    
    // 如果基于历史搜索没有找到足够的商品，补充随机商品
    if (recommendGoods.length < 6) {
      const randomGoods = [...mockData.mockGoods]
        .filter(good => !recommendGoods.find(rGood => rGood.goods_id === good.goods_id))
        .sort(() => Math.random() - 0.5)
        .slice(0, 6 - recommendGoods.length);
      recommendGoods = [...recommendGoods, ...randomGoods];
    }

    // 最多显示6个商品
    recommendGoods = recommendGoods.slice(0, 6);

    this.setData({
      randomGoods: recommendGoods
    });
  },

  onShow() {
    // 每次页面显示时更新推荐商品
    this.getRecommendGoods();
  },

  // 页面开始加载就会触发
  onLoad: function (options) {
    this.getSwiperList();
    this.getCateList();
    this.getFloorList();
    this.getRecommendGoods();
  },
})
