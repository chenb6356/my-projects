// pages/user/index.js
Page({
  data: {
    userinfo: {},
    // 收藏的商品数量
    collectNums: 0,
    // 优惠券数量
    couponNums: 0,
    // 订单数量
    orderNums: {
      all: 0,
      unpaid: 0,
      unshipped: 0,
      unreceived: 0
    }
  },

  onShow() {
    const userinfo = wx.getStorageSync("userinfo");
    const collect = wx.getStorageSync("collect") || [];
    const coupons = wx.getStorageSync("coupons") || [];
    
    // 获取订单数量
    const orders = wx.getStorageSync("orders") || [];
    const orderNums = {
      all: orders.length,
      unpaid: orders.filter(order => order.order_status === 1).length,
      unshipped: orders.filter(order => order.order_status === 2).length,
      unreceived: orders.filter(order => order.order_status === 3).length
    };

    // 获取可用优惠券数量
    const validCoupons = coupons.filter(coupon => coupon.status === 0);

    this.setData({ 
      userinfo,
      collectNums: collect.length,
      couponNums: validCoupons.length,
      orderNums
    });
  },

  // 点击 收货地址
  handleChooseAddress() {
    wx.navigateTo({
      url: '/pages/address/index'
    });
  },

  // 点击 我的订单
  handleOrder(e) {
    const { type = 0 } = e.currentTarget.dataset;
    wx.navigateTo({
      url: '/pages/order/index?type=' + type
    });
  },

  // 点击 我的收藏
  handleCollect() {
    wx.navigateTo({
      url: '/pages/collect/index'
    });
  },

  // 点击 优惠券
  handleCoupon() {
    wx.navigateTo({
      url: '/pages/coupon/index'
    });
  },

  // 点击 意见反馈
  handleFeedback() {
    wx.navigateTo({
      url: '/pages/feedback/index'
    });
  },

  // 点击 关于我们
  handleAbout() {
    wx.navigateTo({
      url: '/pages/about/index'
    });
  },

  // 退出登录
  handleLogout() {
    wx.showModal({
      title: '提示',
      content: '确认退出登录？',
      success: (res) => {
        if (res.confirm) {
          wx.removeStorageSync("token");
          wx.removeStorageSync("userinfo");
          this.setData({
            userinfo: {}
          });
        }
      }
    });
  }
})