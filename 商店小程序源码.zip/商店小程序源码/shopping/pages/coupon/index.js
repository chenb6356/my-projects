Page({
  /**
   * 页面的初始数据
   */
  data: {
    tabs: [
      {
        id: 0,
        value: "可使用",
        isActive: true
      },
      {
        id: 1,
        value: "已使用",
        isActive: false
      },
      {
        id: 2,
        value: "已过期",
        isActive: false
      }
    ],
    // 优惠券列表
    coupons: [
      {
        id: 1,
        name: "新人专享券",
        type: "discount", // discount:折扣券 minus:满减券
        discount: 0.8, // 折扣率
        condition: 100, // 使用条件（满多少可用）
        validDays: 30, // 有效期（天）
        status: 0, // 0:可使用 1:已使用 2:已过期
        startTime: "2024-01-01",
        endTime: "2024-12-31",
        minAmount: 100, // 最低使用金额
        maxDiscount: 50 // 最高优惠金额
      },
      {
        id: 2,
        name: "满100减20",
        type: "minus",
        minus: 20, // 减免金额
        condition: 100,
        validDays: 30,
        status: 0,
        startTime: "2024-01-01",
        endTime: "2024-12-31",
        minAmount: 100,
        maxDiscount: 20
      }
    ],
    myCoupons: [] // 添加myCoupons数组
  },

  onLoad() {
    // 设置导航栏标题
    wx.setNavigationBarTitle({
      title: '优惠券'
    });
  },

  // 标题点击事件
  handleTabsItemChange(e) {
    const { index } = e.detail;
    let { tabs } = this.data;
    tabs.forEach((v, i) => i === index ? v.isActive = true : v.isActive = false);
    this.setData({
      tabs
    });
  },

  // 领取优惠券
  handleReceiveCoupon(e) {
    const { id } = e.currentTarget.dataset;
    // 获取本地存储中的优惠券
    let myCoupons = wx.getStorageSync("coupons") || [];
    // 判断是否已经领取过
    const isExist = myCoupons.some(v => v.id === id);
    if (isExist) {
      wx.showToast({
        title: '您已领取过该优惠券',
        icon: 'none'
      });
      return;
    }
    // 找到要领取的优惠券
    const coupon = this.data.coupons.find(v => v.id === id);
    // 设置领取时间和到期时间
    const now = new Date();
    coupon.receiveTime = now.toISOString();
    const expireTime = new Date(now.getTime() + coupon.validDays * 24 * 60 * 60 * 1000);
    coupon.expireTime = expireTime.toISOString();
    // 添加到我的优惠券中
    myCoupons.push(coupon);
    wx.setStorageSync("coupons", myCoupons);
    wx.showToast({
      title: '领取成功',
      icon: 'success'
    });

    // 更新页面数据
    this.setData({
      myCoupons
    });
  },

  // 使用优惠券
  handleUseCoupon(e) {
    const { id } = e.currentTarget.dataset;
    // 跳转到商品列表页
    wx.navigateTo({
      url: '/pages/goods_list/index?coupon_id=' + id
    });
  },

  onShow() {
    // 获取本地存储中的优惠券
    const myCoupons = wx.getStorageSync("coupons") || [];
    // 更新优惠券状态
    const now = new Date().getTime();
    myCoupons.forEach(coupon => {
      const expireTime = new Date(coupon.expireTime).getTime();
      if (expireTime < now) {
        coupon.status = 2; // 已过期
      }
    });
    wx.setStorageSync("coupons", myCoupons);
    this.setData({
      myCoupons
    });
  }
}) 