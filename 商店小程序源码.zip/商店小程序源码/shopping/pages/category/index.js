import { request } from "../../request/index.js";
import regeneratorRuntime from '../../lib/runtime/runtime';

// 模拟分类数据
const mockCategoriesData = [
  {
    cat_id: 1,
    cat_name: "食品饮料",
    cat_pid: 0,
    cat_level: 0,
    cat_deleted: false,
    cat_icon: "",
    children: [
      {
        cat_id: 101,
        cat_name: "休闲食品",
        cat_pid: 1,
        cat_level: 1,
        cat_deleted: false,
        cat_icon: "",
        children: [
          {
            cat_id: 1001,
            cat_name: "饼干糕点",
            cat_pid: 101,
            cat_level: 2,
            cat_deleted: false,
            cat_icon: "https://picsum.photos/200/200?random=1",
            goods_count: 45,
            hot_score: 98
          },
          {
            cat_id: 1002,
            cat_name: "坚果炒货",
            cat_pid: 101,
            cat_level: 2,
            cat_deleted: false,
            cat_icon: "https://picsum.photos/200/200?random=2",
            goods_count: 32,
            hot_score: 95
          }
        ]
      },
      {
        cat_id: 102,
        cat_name: "酒水饮料",
        cat_pid: 1,
        cat_level: 1,
        cat_deleted: false,
        cat_icon: "",
        children: [
          {
            cat_id: 1003,
            cat_name: "果汁饮料",
            cat_pid: 102,
            cat_level: 2,
            cat_deleted: false,
            cat_icon: "https://picsum.photos/200/200?random=3",
            goods_count: 28,
            hot_score: 90
          }
        ]
      }
    ]
  },
  {
    cat_id: 2,
    cat_name: "生鲜果蔬",
    cat_pid: 0,
    cat_level: 0,
    cat_deleted: false,
    cat_icon: "",
    children: [
      {
        cat_id: 201,
        cat_name: "新鲜水果",
        cat_pid: 2,
        cat_level: 1,
        cat_deleted: false,
        cat_icon: "",
        children: [
          {
            cat_id: 2001,
            cat_name: "应季水果",
            cat_pid: 201,
            cat_level: 2,
            cat_deleted: false,
            cat_icon: "https://picsum.photos/200/200?random=4",
            goods_count: 56,
            hot_score: 99
          },
          {
            cat_id: 2002,
            cat_name: "进口水果",
            cat_pid: 201,
            cat_level: 2,
            cat_deleted: false,
            cat_icon: "https://picsum.photos/200/200?random=5",
            goods_count: 23,
            hot_score: 92
          }
        ]
      }
    ]
  },
  {
    cat_id: 3,
    cat_name: "日用百货",
    cat_pid: 0,
    cat_level: 0,
    cat_deleted: false,
    cat_icon: "",
    children: [
      {
        cat_id: 301,
        cat_name: "个人护理",
        cat_pid: 3,
        cat_level: 1,
        cat_deleted: false,
        cat_icon: "",
        children: [
          {
            cat_id: 3001,
            cat_name: "洗护用品",
            cat_pid: 301,
            cat_level: 2,
            cat_deleted: false,
            cat_icon: "https://picsum.photos/200/200?random=6",
            goods_count: 89,
            hot_score: 96
          }
        ]
      }
    ]
  }
];

Page({
  data: {
    // 左侧的菜单数据
    leftMenuList: [],
    // 右侧的商品数据
    rightContent: [],
    // 被点击的左侧的菜单
    currentIndex: 0,
    // 右侧内容的滚动条距离顶部的距离
    scrollTop: 0,
    // 搜索关键词
    searchValue: "",
    // 是否显示搜索结果
    showSearchResult: false,
    // 搜索结果
    searchResults: []
  },
  // 接口的返回数据
  Cates: [],

  onLoad: function (options) {
    /* 
    0 web中的本地存储和 小程序中的本地存储的区别
      1 写代码的方式不一样了 
        web: localStorage.setItem("key","value") localStorage.getItem("key")
    小程序中: wx.setStorageSync("key", "value"); wx.getStorageSync("key");
      2:存的时候 有没有做类型转换
        web: 不管存入的是什么类型的数据，最终都会先调用以下 toString(),把数据变成了字符串 再存入进去
      小程序: 不存在 类型转换的这个操作 存什么类似的数据进去，获取的时候就是什么类型
    1 先判断一下本地存储中有没有旧的数据
      {time:Date.now(),data:[...]}
    2 没有旧数据 直接发送新请求 
    3 有旧的数据 同时 旧的数据也没有过期 就使用 本地存储中的旧数据即可
     */

    //  1 获取本地存储中的数据  (小程序中也是存在本地存储 技术)
    const Cates = wx.getStorageSync("cates");
    // 2 判断
    if (!Cates) {
      // 不存在  发送请求获取数据
      this.getCates();
    } else {
      // 有旧的数据 定义过期时间  10s 改成 5分钟
      if (Date.now() - Cates.time > 1000 * 10) {
        // 重新发送请求
        this.getCates();
      } else {
        // 可以使用旧的数据
        this.Cates = Cates.data;
        let leftMenuList = this.Cates.map(v => v.cat_name);
        let rightContent = this.Cates[0].children;
        this.setData({
          leftMenuList,
          rightContent
        })
      }
    }

  },
  // 获取分类数据
  async getCates() {
    // 使用模拟数据
    this.Cates = mockCategoriesData;
    // 把接口的数据存入到本地存储中
    wx.setStorageSync("cates", { time: Date.now(), data: this.Cates });
    // 构造左侧的大菜单数据
    let leftMenuList = this.Cates.map(v => v.cat_name);
    // 构造右侧的商品数据
    let rightContent = this.Cates[0].children;
    this.setData({
      leftMenuList,
      rightContent
    });
  },
  // 左侧菜单的点击事件
  handleItemTap(e) {
    /* 
    1 获取被点击的标题身上的索引
    2 给data中的currentIndex赋值就可以了
    3 根据不同的索引来渲染右侧的商品内容
     */
    const { index } = e.currentTarget.dataset;

    let rightContent = this.Cates[index].children;
    this.setData({
      currentIndex: index,
      rightContent,
      // 重新设置 右侧内容的scroll-view标签的距离顶部的距离
      scrollTop: 0
    })

  },
  // 搜索功能
  handleSearch(e) {
    const searchValue = e.detail.value;
    this.setData({
      searchValue,
      showSearchResult: true
    });

    // 记录搜索历史
    if (searchValue.trim()) {
      let searchHistory = wx.getStorageSync('searchHistory') || [];
      // 查找是否已存在该关键词
      const existingIndex = searchHistory.findIndex(item => 
        item.keyword.toLowerCase() === searchValue.toLowerCase()
      );

      if (existingIndex !== -1) {
        // 如果已存在，更新搜索次数和时间
        searchHistory[existingIndex].count++;
        searchHistory[existingIndex].lastTime = Date.now();
        // 将更新的记录移到最前面
        const item = searchHistory.splice(existingIndex, 1)[0];
        searchHistory.unshift(item);
      } else {
        // 如果不存在，添加新记录
        searchHistory.unshift({
          keyword: searchValue,
          count: 1,
          lastTime: Date.now()
        });
      }

      // 最多保存20条
      if (searchHistory.length > 20) {
        searchHistory.pop();
      }

      wx.setStorageSync('searchHistory', searchHistory);
    }

    // 搜索逻辑
    const searchResults = [];
    const searchInCategory = (categories) => {
      categories.forEach(category => {
        if (category.cat_name.includes(searchValue)) {
          searchResults.push({
            id: category.cat_id,
            name: category.cat_name,
            type: 'category'
          });
        }
        if (category.children) {
          searchInCategory(category.children);
        }
      });
    };
    
    searchInCategory(this.Cates);
    
    this.setData({
      searchResults: searchResults
    });
  },

  // 清除搜索
  clearSearch() {
    this.setData({
      searchValue: "",
      showSearchResult: false,
      searchResults: []
    });
  }
})