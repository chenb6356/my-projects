App({
  globalData: {
    userInfo: null,
    theme: {
      primaryColor: '#E3170D',  // 樱桃红
      secondaryColor: '#4CAF50',  // 清新绿
      backgroundColor: '#ffffff',  // 白色
      textColor: '#333333',  // 主文本色
      lightGrey: '#f5f5f5'  // 浅灰色
    }
  },
  
  onLaunch() {
    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          wx.getUserInfo({
            success: res => {
              this.globalData.userInfo = res.userInfo
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
  }
}) 