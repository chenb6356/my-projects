Page({
  data: {
    customerService: {
      phone: '400-123-4567',
      workTime: '09:00-18:00',
      wechat: 'shangwangcun',
      email: 'service@shangwangcun.com'
    },
    faqs: [
      {
        question: '樱桃如何保存？',
        answer: '建议将樱桃放入保鲜袋中，置于冰箱保鲜室4℃左右保存，可保存7-10天。'
      },
      {
        question: '樱桃什么时候发货？',
        answer: '我们会在下单后24小时内发货，节假日可能会有延迟。'
      },
      {
        question: '樱桃是新鲜采摘的吗？',
        answer: '是的，我们的樱桃都是当日采摘，确保新鲜送达。'
      },
      {
        question: '可以开发票吗？',
        answer: '可以，请在下单时备注开发票信息。'
      }
    ]
  },

  makePhoneCall() {
    wx.makePhoneCall({
      phoneNumber: this.data.customerService.phone,
      fail() {
        wx.showToast({
          title: '拨打失败，请稍后重试',
          icon: 'none'
        })
      }
    })
  },

  copyWechat() {
    wx.setClipboardData({
      data: this.data.customerService.wechat,
      success() {
        wx.showToast({
          title: '微信号已复制',
          icon: 'success'
        })
      }
    })
  },

  copyEmail() {
    wx.setClipboardData({
      data: this.data.customerService.email,
      success() {
        wx.showToast({
          title: '邮箱已复制',
          icon: 'success'
        })
      }
    })
  },

  onShareAppMessage() {
    return {
      title: '上王村樱桃 - 在线客服',
      path: '/pages/service/index'
    }
  }
}) 