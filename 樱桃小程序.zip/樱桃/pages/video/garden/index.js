const app = getApp()

Page({
  data: {
    categories: [
      { id: 'all', name: '全部' },
      { id: 'planting', name: '种植技术' },
      { id: 'harvest', name: '采摘季节' },
      { id: 'storage', name: '储存方法' },
      { id: 'cooking', name: '美食制作' }
    ],
    currentCategory: 'all',
    videos: [],
    pageNum: 1,
    pageSize: 10,
    loading: false,
    noMore: false,
    isRefreshing: false,
    showVideoPopup: false,
    showSharePopup: false,
    currentVideo: null,
    searchValue: ''
  },

  onLoad() {
    this.loadVideos()
  },

  // 加载视频列表
  loadVideos(isRefresh = false) {
    if (this.data.loading) return
    
    if (isRefresh) {
      this.setData({ pageNum: 1, noMore: false })
    }

    this.setData({ loading: true })
    
    // 模拟接口调用
    this.mockGetVideos().then(res => {
      const { videos, hasMore } = res
      
      if (isRefresh) {
        this.setData({ videos })
      } else {
        this.setData({
          videos: [...this.data.videos, ...videos]
        })
      }
      
      this.setData({
        loading: false,
        noMore: !hasMore,
        pageNum: this.data.pageNum + 1
      })

      if (isRefresh) {
        this.setData({ isRefreshing: false })
      }
    }).catch(() => {
      this.setData({ 
        loading: false,
        isRefreshing: false
      })
      wx.showToast({
        title: '加载失败',
        icon: 'error'
      })
    })
  },

  // 搜索输入
  onSearchInput(e) {
    this.setData({
      searchValue: e.detail.value
    })
    // 可以实现输入防抖
    if (this.searchTimer) {
      clearTimeout(this.searchTimer)
    }
    this.searchTimer = setTimeout(() => {
      this.setData({
        videos: [],
        pageNum: 1,
        noMore: false
      })
      this.loadVideos()
    }, 500)
  },

  // 切换分类
  onCategoryTap(e) {
    const categoryId = e.currentTarget.dataset.id
    this.setData({
      currentCategory: categoryId,
      videos: [],
      pageNum: 1,
      noMore: false
    })
    this.loadVideos()
  },

  // 播放视频
  playVideo(e) {
    const videoId = e.currentTarget.dataset.id
    const video = this.data.videos.find(item => item.id === videoId)
    if (video) {
      this.setData({
        showVideoPopup: true,
        currentVideo: video
      })
    }
  },

  // 关闭视频
  closeVideoPopup() {
    this.setData({
      showVideoPopup: false,
      currentVideo: null
    })
  },

  // 视频播放结束
  onVideoEnd() {
    this.closeVideoPopup()
  },

  // 视频播放错误
  onVideoError() {
    wx.showToast({
      title: '视频播放失败',
      icon: 'error'
    })
    this.closeVideoPopup()
  },

  // 点赞
  onLikeTap(e) {
    const videoId = e.currentTarget.dataset.id
    const videos = this.data.videos.map(item => {
      if (item.id === videoId) {
        const isLiked = !item.isLiked
        return {
          ...item,
          isLiked,
          likeCount: isLiked ? item.likeCount + 1 : item.likeCount - 1
        }
      }
      return item
    })
    this.setData({ videos })
  },

  // 收藏
  onCollectTap(e) {
    const videoId = e.currentTarget.dataset.id
    const videos = this.data.videos.map(item => {
      if (item.id === videoId) {
        const isCollected = !item.isCollected
        return {
          ...item,
          isCollected,
          collectCount: isCollected ? item.collectCount + 1 : item.collectCount - 1
        }
      }
      return item
    })
    this.setData({ videos })
  },

  // 分享
  onShareTap(e) {
    const videoId = e.currentTarget.dataset.id
    const video = this.data.videos.find(item => item.id === videoId)
    if (video) {
      this.setData({
        showSharePopup: true,
        currentVideo: video
      })
    }
  },

  // 关闭分享弹窗
  closeSharePopup() {
    this.setData({
      showSharePopup: false,
      currentVideo: null
    })
  },

  // 分享到朋友圈
  shareToTimeline() {
    wx.showToast({
      title: '分享成功',
      icon: 'success'
    })
    this.closeSharePopup()
  },

  // 复制链接
  copyLink() {
    const { currentVideo } = this.data
    if (currentVideo) {
      wx.setClipboardData({
        data: `https://example.com/video/${currentVideo.id}`,
        success: () => {
          wx.showToast({
            title: '链接已复制',
            icon: 'success'
          })
          this.closeSharePopup()
        }
      })
    }
  },

  // 下拉刷新
  onRefresh() {
    this.setData({ isRefreshing: true })
    this.loadVideos(true)
  },

  // 触底加载更多
  onReachBottom() {
    if (!this.data.noMore) {
      this.loadVideos()
    }
  },

  // 分享给好友
  onShareAppMessage() {
    const { currentVideo } = this.data
    if (currentVideo) {
      return {
        title: currentVideo.title,
        path: `/pages/video/garden/index?videoId=${currentVideo.id}`,
        imageUrl: currentVideo.coverUrl
      }
    }
    return {
      title: '上王村樱桃园 - 种植视频',
      path: '/pages/video/garden/index'
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '上王村樱桃园 - 种植视频',
      query: ''
    }
  },

  // 模拟获取视频列表
  mockGetVideos() {
    return new Promise((resolve) => {
      setTimeout(() => {
        const mockVideos = [
          {
            id: 'V001',
            title: '樱桃树修剪技术',
            description: '专业果农为您详细讲解樱桃树修剪的关键技术要点',
            coverUrl: '/assets/images/video-cover1.jpg',
            videoUrl: 'http://example.com/video1.mp4',
            duration: '10:30',
            publishTime: '2024-03-25',
            viewCount: '2.3w',
            likeCount: 356,
            collectCount: 89,
            isLiked: false,
            isCollected: false
          },
          {
            id: 'V002',
            title: '樱桃采摘季节来啦！',
            description: '带您了解樱桃的最佳采摘时间和方法',
            coverUrl: '/assets/images/video-cover2.jpg',
            videoUrl: 'http://example.com/video2.mp4',
            duration: '08:45',
            publishTime: '2024-03-24',
            viewCount: '1.8w',
            likeCount: 286,
            collectCount: 67,
            isLiked: false,
            isCollected: false
          }
        ]
        resolve({
          videos: mockVideos,
          hasMore: this.data.pageNum < 3
        })
      }, 500)
    })
  }
}) 