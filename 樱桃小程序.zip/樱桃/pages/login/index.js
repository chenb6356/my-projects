const app = getApp()

Page({
  data: {
    loginType: 'password', // password: 密码登录, code: 验证码登录
    phone: '',
    password: '',
    code: '',
    showPassword: false,
    countdown: 0,
    canSendCode: false,
    canSubmit: false,
    agreed: false,
    loading: false,
    loadingText: '登录中...',
    primaryColor: '#E3170D'
  },

  onLoad() {
    // 获取主题色
    this.setData({
      primaryColor: app.globalData.theme.primaryColor
    })
  },

  // 切换登录方式
  switchType(e) {
    const type = e.currentTarget.dataset.type
    this.setData({
      loginType: type,
      password: '',
      code: '',
      showPassword: false
    })
    this.checkCanSubmit()
  },

  // 手机号输入
  onPhoneInput(e) {
    const phone = e.detail.value
    this.setData({
      phone,
      canSendCode: this.isValidPhone(phone)
    })
    this.checkCanSubmit()
  },

  // 清除手机号
  clearPhone() {
    this.setData({
      phone: '',
      canSendCode: false
    })
    this.checkCanSubmit()
  },

  // 密码输入
  onPasswordInput(e) {
    const password = e.detail.value
    this.setData({ password })
    this.checkCanSubmit()
  },

  // 切换密码可见性
  togglePasswordVisibility() {
    this.setData({
      showPassword: !this.data.showPassword
    })
  },

  // 验证码输入
  onCodeInput(e) {
    const code = e.detail.value
    this.setData({ code })
    this.checkCanSubmit()
  },

  // 发送验证码
  async sendCode() {
    if (this.data.countdown > 0 || !this.isValidPhone(this.data.phone)) {
      return
    }

    this.setData({ loading: true, loadingText: '发送中...' })
    try {
      await this.mockSendCode(this.data.phone)
      this.startCountdown()
      wx.showToast({
        title: '验证码已发送',
        icon: 'success'
      })
    } catch (error) {
      wx.showToast({
        title: error.message || '发送失败',
        icon: 'error'
      })
    } finally {
      this.setData({ loading: false })
    }
  },

  // 开始倒计时
  startCountdown() {
    this.setData({ countdown: 60 })
    const timer = setInterval(() => {
      if (this.data.countdown <= 1) {
        clearInterval(timer)
      }
      this.setData({
        countdown: this.data.countdown - 1
      })
    }, 1000)
  },

  // 提交表单
  async submitForm() {
    if (!this.checkFormValid()) {
      return
    }

    this.setData({ loading: true, loadingText: '登录中...' })
    try {
      const loginParams = {
        phone: this.data.phone,
        type: this.data.loginType,
        ...(this.data.loginType === 'password' 
          ? { password: this.data.password }
          : { code: this.data.code }
        )
      }

      const userInfo = await this.mockLogin(loginParams)
      
      // 保存用户信息
      app.globalData.userInfo = userInfo
      wx.setStorageSync('userInfo', userInfo)

      wx.showToast({
        title: '登录成功',
        icon: 'success'
      })

      // 延迟返回，让用户看到成功提示
      setTimeout(() => {
        const pages = getCurrentPages()
        if (pages.length > 1) {
          wx.navigateBack()
        } else {
          wx.switchTab({
            url: '/pages/index/index'
          })
        }
      }, 1500)
    } catch (error) {
      wx.showToast({
        title: error.message || '登录失败',
        icon: 'error'
      })
    } finally {
      this.setData({ loading: false })
    }
  },

  // 检查是否可以提交
  checkCanSubmit() {
    const { loginType, phone, password, code, agreed } = this.data
    const canSubmit = this.isValidPhone(phone) && agreed && (
      (loginType === 'password' && password.length >= 6) ||
      (loginType === 'code' && code.length === 6)
    )
    this.setData({ canSubmit })
  },

  // 检查表单是否有效
  checkFormValid() {
    const { loginType, phone, password, code, agreed } = this.data

    if (!this.isValidPhone(phone)) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none'
      })
      return false
    }

    if (loginType === 'password' && password.length < 6) {
      wx.showToast({
        title: '请输入正确的密码',
        icon: 'none'
      })
      return false
    }

    if (loginType === 'code' && code.length !== 6) {
      wx.showToast({
        title: '请输入6位验证码',
        icon: 'none'
      })
      return false
    }

    if (!agreed) {
      wx.showToast({
        title: '请同意用户协议和隐私政策',
        icon: 'none'
      })
      return false
    }

    return true
  },

  // 验证手机号格式
  isValidPhone(phone) {
    return /^1[3-9]\d{9}$/.test(phone)
  },

  // 同意协议变化
  onPrivacyChange(e) {
    this.setData({
      agreed: e.detail.value.includes('agreed')
    })
    this.checkCanSubmit()
  },

  // 跳转到注册页面
  navigateToRegister() {
    wx.navigateTo({
      url: '/pages/register/index'
    })
  },

  // 跳转到重置密码页面
  navigateToReset() {
    wx.navigateTo({
      url: '/pages/user/password/reset/index'
    })
  },

  // 跳转到用户协议页面
  navigateToTerms() {
    wx.navigateTo({
      url: '/pages/user/terms/index'
    })
  },

  // 跳转到隐私政策页面
  navigateToPrivacy() {
    wx.navigateTo({
      url: '/pages/user/privacy/index'
    })
  },

  // 微信登录
  async loginWithWechat() {
    this.setData({ loading: true, loadingText: '登录中...' })
    try {
      // 获取用户信息
      const { code } = await wx.login()
      const userInfo = await this.mockWechatLogin(code)
      
      // 保存用户信息
      app.globalData.userInfo = userInfo
      wx.setStorageSync('userInfo', userInfo)

      wx.showToast({
        title: '登录成功',
        icon: 'success'
      })

      // 延迟返回
      setTimeout(() => {
        const pages = getCurrentPages()
        if (pages.length > 1) {
          wx.navigateBack()
        } else {
          wx.switchTab({
            url: '/pages/index/index'
          })
        }
      }, 1500)
    } catch (error) {
      wx.showToast({
        title: error.message || '登录失败',
        icon: 'error'
      })
    } finally {
      this.setData({ loading: false })
    }
  },

  // 模拟发送验证码
  mockSendCode(phone) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (this.isValidPhone(phone)) {
          resolve()
        } else {
          reject(new Error('手机号格式错误'))
        }
      }, 1000)
    })
  },

  // 模拟登录
  mockLogin({ phone, type, password, code }) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (!this.isValidPhone(phone)) {
          reject(new Error('手机号格式错误'))
          return
        }

        if (type === 'password' && password !== '123456') {
          reject(new Error('密码错误'))
          return
        }

        if (type === 'code' && code !== '123456') {
          reject(new Error('验证码错误'))
          return
        }

        resolve({
          id: '88888888',
          phone: phone,
          nickname: '樱桃用户',
          avatar: '/assets/images/default-avatar.png'
        })
      }, 1500)
    })
  },

  // 模拟微信登录
  mockWechatLogin(code) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          id: '88888888',
          phone: '13888888888',
          nickname: '樱桃用户',
          avatar: '/assets/images/default-avatar.png'
        })
      }, 1500)
    })
  }
}) 