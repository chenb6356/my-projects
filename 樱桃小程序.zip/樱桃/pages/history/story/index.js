const app = getApp()

Page({
  data: {
    story: null
  },

  onLoad(options) {
    const { id } = options
    this.loadStoryDetail(id)
  },

  // 加载故事详情
  async loadStoryDetail(id) {
    try {
      // TODO: 从服务器获取故事详情
      // 模拟数据
      const mockStory = {
        id: 1,
        name: '王大伯',
        title: '第三代种植传承人',
        coverImage: '/assets/images/story-cover1.jpg',
        avatar: '/assets/images/avatar1.jpg',
        introduction: '从事樱桃种植50余年，是上王村最资深的樱桃种植专家之一。多年来致力于樱桃品种改良和种植技术创新，为上王村樱桃产业的发展做出了重要贡献。',
        journey: [
          {
            year: '1970',
            title: '开始种植樱桃',
            description: '跟随父辈学习樱桃种植技术，开始接触樱桃种植。',
            images: ['/assets/images/journey1.jpg', '/assets/images/journey2.jpg']
          },
          {
            year: '1985',
            title: '技术革新',
            description: '引进新品种，改进种植技术，带领村民提高樱桃品质。',
            images: ['/assets/images/journey3.jpg', '/assets/images/journey4.jpg']
          },
          {
            year: '2000',
            title: '品牌建设',
            description: '参与创立上王村樱桃品牌，推动产业标准化发展。',
            images: ['/assets/images/journey5.jpg', '/assets/images/journey6.jpg']
          }
        ],
        innovations: [
          {
            id: 1,
            title: '水肥一体化技术',
            description: '研发智能水肥系统，实现精准灌溉施肥，提高果品品质。',
            image: '/assets/images/innovation1.jpg'
          },
          {
            id: 2,
            title: '整形修剪新方法',
            description: '创新树形修剪技术，提高通风透光性，增加产量。',
            image: '/assets/images/innovation2.jpg'
          }
        ],
        honors: [
          {
            id: 1,
            year: '2010',
            title: '全国农业技术推广标兵',
            description: '获农业部表彰，推广先进种植技术。'
          },
          {
            id: 2,
            year: '2015',
            title: '省级农业科技带头人',
            description: '带领农户增收致富，推动产业发展。'
          }
        ],
        quote: '种好樱桃，不仅要懂技术，更要用心。每一棵树都是一个生命，都需要精心照料。',
        experience: '五十年的种植经验告诉我，樱桃种植是一门科学，也是一门艺术。要想种出好樱桃，必须严格把控每个环节，从整形修剪到水肥管理，从病虫防治到采摘保鲜，每一步都不能马虎。同时，也要与时俱进，不断学习新技术、新方法，才能跟上时代的发展。',
        contact: {
          phone: '13812345678',
          wechat: 'wang_cherry'
        }
      }

      this.setData({ story: mockStory })
    } catch (error) {
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      })
    }
  },

  // 预览图片
  previewImage(e) {
    const { url, urls } = e.currentTarget.dataset
    wx.previewImage({
      current: url,
      urls: urls
    })
  },

  // 拨打电话
  makePhoneCall(e) {
    const { phone } = e.currentTarget.dataset
    wx.makePhoneCall({
      phoneNumber: phone
    })
  },

  // 复制微信号
  copyWechat(e) {
    const { wechat } = e.currentTarget.dataset
    wx.setClipboardData({
      data: wechat,
      success: () => {
        wx.showToast({
          title: '微信号已复制',
          icon: 'success'
        })
      }
    })
  },

  onShareAppMessage() {
    const { story } = this.data
    return {
      title: `${story.name} - ${story.title}`,
      path: `/pages/history/story/index?id=${story.id}`,
      imageUrl: story.coverImage
    }
  },

  onShareTimeline() {
    const { story } = this.data
    return {
      title: `${story.name} - ${story.title}`,
      query: `id=${story.id}`,
      imageUrl: story.coverImage
    }
  }
}) 