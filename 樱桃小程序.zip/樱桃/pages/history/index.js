const app = getApp()

Page({
  data: {
    timeline: [
      {
        year: '1920',
        title: '樱桃种植起源',
        description: '上王村最早引进樱桃树苗，开始小规模种植。',
        image: '/assets/images/history1.jpg'
      },
      {
        year: '1950',
        title: '规模化种植',
        description: '村民开始大规模种植樱桃，形成初具规模的樱桃园。',
        image: '/assets/images/history2.jpg'
      },
      {
        year: '1980',
        title: '技术革新',
        description: '引进先进种植技术，提高樱桃品质和产量。',
        image: '/assets/images/history3.jpg'
      },
      {
        year: '2000',
        title: '品牌化发展',
        description: '上王村樱桃获得地理标志认证，建立品牌。',
        image: '/assets/images/history4.jpg'
      },
      {
        year: '2020',
        title: '现代化发展',
        description: '引入智能化种植系统，实现科学化管理。',
        image: '/assets/images/history5.jpg'
      }
    ],
    varieties: [
      {
        id: 1,
        name: '美早樱桃',
        year: '1980年引进',
        description: '果实硕大，色泽鲜艳，肉质细腻，口感甜美。',
        image: '/assets/images/variety1.jpg'
      },
      {
        id: 2,
        name: '红灯樱桃',
        year: '1985年培育',
        description: '本地优良品种，抗病性强，产量稳定。',
        image: '/assets/images/variety2.jpg'
      },
      {
        id: 3,
        name: '黄蜜樱桃',
        year: '1990年引进',
        description: '果肉金黄，汁水丰富，香甜可口。',
        image: '/assets/images/variety3.jpg'
      }
    ],
    techniques: [
      {
        id: 1,
        name: '整形修剪',
        icon: '/assets/icons/technique1.png',
        image: '/assets/images/technique1.jpg',
        description: '采用现代整形修剪技术，确保树形优美，通风透光，提高结果率。'
      },
      {
        id: 2,
        name: '水肥管理',
        icon: '/assets/icons/technique2.png',
        image: '/assets/images/technique2.jpg',
        description: '科学灌溉施肥，保证樱桃生长所需营养，提高果实品质。'
      },
      {
        id: 3,
        name: '病虫防治',
        icon: '/assets/icons/technique3.png',
        image: '/assets/images/technique3.jpg',
        description: '采用生态防治方法，减少农药使用，确保果品安全。'
      },
      {
        id: 4,
        name: '采摘技术',
        icon: '/assets/icons/technique4.png',
        image: '/assets/images/technique4.jpg',
        description: '选择最佳采摘时机，使用专业工具，保证果实品质。'
      }
    ],
    honors: [
      {
        id: 1,
        title: '中国地理标志产品',
        year: '2010年',
        description: '获得国家质检总局颁发的地理标志产品认证。',
        image: '/assets/images/honor1.jpg'
      },
      {
        id: 2,
        title: '全国名特优新农产品',
        year: '2015年',
        description: '被农业部评为全国名特优新农产品。',
        image: '/assets/images/honor2.jpg'
      }
    ],
    stories: [
      {
        id: 1,
        name: '王大伯',
        title: '第三代种植传承人',
        description: '从事樱桃种植50余年，培育出多个优良品种。',
        image: '/assets/images/story1.jpg'
      },
      {
        id: 2,
        name: '李师傅',
        title: '技术创新带头人',
        description: '致力于樱桃种植技术创新，带领村民增收致富。',
        image: '/assets/images/story2.jpg'
      }
    ],
    showTechniquePopup: false,
    currentTechnique: null
  },

  onLoad() {
    // 页面加载时的处理
  },

  // 预览图片
  previewImage(e) {
    const { url } = e.currentTarget.dataset
    wx.previewImage({
      current: url,
      urls: [url]
    })
  },

  // 显示种植技艺详情
  showTechniqueDetail(e) {
    const { id } = e.currentTarget.dataset
    const technique = this.data.techniques.find(item => item.id === id)
    this.setData({
      showTechniquePopup: true,
      currentTechnique: technique
    })
  },

  // 关闭种植技艺详情
  closeTechniquePopup() {
    this.setData({
      showTechniquePopup: false
    })
  },

  // 跳转到传承人故事详情
  navigateToStory(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/history/story?id=${id}`
    })
  },

  onShareAppMessage() {
    return {
      title: '上王村樱桃 - 百年传承 匠心种植',
      path: '/pages/history/index'
    }
  },

  onShareTimeline() {
    return {
      title: '上王村樱桃 - 百年传承 匠心种植'
    }
  }
})
 