const app = getApp()

Page({
  data: {
    categories: [
      { id: 0, name: '全部' },
      { id: 1, name: '营养价值' },
      { id: 2, name: '功效作用' },
      { id: 3, name: '食用方法' },
      { id: 4, name: '注意事项' },
      { id: 5, name: '养生食谱' }
    ],
    currentCategory: 0,
    nutritionData: [
      { name: '热量', value: '63', unit: 'kcal' },
      { name: '蛋白质', value: '1.1', unit: 'g' },
      { name: '脂肪', value: '0.2', unit: 'g' },
      { name: '碳水化合物', value: '14.3', unit: 'g' },
      { name: '维生素C', value: '7', unit: 'mg' },
      { name: '钾', value: '222', unit: 'mg' }
    ],
    benefits: [
      {
        title: '美容养颜',
        description: '樱桃富含维生素C和花青素，具有抗氧化作用，可以延缓衰老，美容养颜。',
        icon: '/assets/icons/beauty.png'
      },
      {
        title: '改善睡眠',
        description: '樱桃含有褪黑激素，可以帮助改善睡眠质量，缓解失眠问题。',
        icon: '/assets/icons/sleep.png'
      },
      {
        title: '提高免疫力',
        description: '樱桃中的维生素C和多酚类物质可以增强机体免疫力，提高抵抗力。',
        icon: '/assets/icons/immune.png'
      },
      {
        title: '护眼明目',
        description: '樱桃中的胡萝卜素和花青素对保护视力、预防眼部疾病有帮助。',
        icon: '/assets/icons/eye.png'
      }
    ],
    eatingMethods: [
      {
        title: '生食',
        description: '新鲜樱桃洗净后直接食用，可以最大程度保留营养成分。',
        image: '/assets/images/eating1.jpg'
      },
      {
        title: '果汁',
        description: '将樱桃榨汁饮用，可以添加适量蜂蜜调味。',
        image: '/assets/images/eating2.jpg'
      },
      {
        title: '果酱',
        description: '自制樱桃果酱，可以长期保存，搭配面包等食用。',
        image: '/assets/images/eating3.jpg'
      }
    ],
    precautions: [
      {
        title: '适量食用',
        description: '樱桃性质偏温，一次不宜食用过多，建议每次食用15-20颗。',
        icon: '/assets/icons/amount.png'
      },
      {
        title: '空腹禁忌',
        description: '不建议空腹食用樱桃，可能会导致胃部不适。',
        icon: '/assets/icons/stomach.png'
      },
      {
        title: '特殊人群注意',
        description: '糖尿病患者、消化道溃疡患者应在医生指导下食用。',
        icon: '/assets/icons/special.png'
      }
    ],
    recipes: [
      {
        id: 1,
        title: '樱桃冰沙',
        time: 10,
        difficulty: '简单',
        image: '/assets/images/recipe1.jpg',
        portion: 2,
        ingredients: [
          { name: '樱桃', amount: '200g' },
          { name: '酸奶', amount: '200ml' },
          { name: '蜂蜜', amount: '适量' },
          { name: '冰块', amount: '适量' }
        ],
        steps: [
          '将樱桃洗净，去核。',
          '将樱桃、酸奶、冰块放入搅拌机。',
          '加入适量蜂蜜调味。',
          '搅拌均匀即可饮用。'
        ],
        tips: [
          '可以用酸奶提前冰冻，这样就不需要加入冰块。',
          '根据个人口味可以调整蜂蜜用量。'
        ]
      },
      {
        id: 2,
        title: '樱桃果酱',
        time: 40,
        difficulty: '中等',
        image: '/assets/images/recipe2.jpg',
        portion: 4,
        ingredients: [
          { name: '樱桃', amount: '500g' },
          { name: '白砂糖', amount: '250g' },
          { name: '柠檬汁', amount: '1汤匙' }
        ],
        steps: [
          '樱桃洗净去核，切碎。',
          '锅中加入樱桃和糖，小火煮至糖溶解。',
          '加入柠檬汁，继续煮至浓稠。',
          '装入消毒的玻璃瓶中密封保存。'
        ],
        tips: [
          '煮制过程要不断搅拌，防止糊锅。',
          '可以根据喜好调整糖的用量。',
          '密封后可以保存1-2个月。'
        ]
      }
    ],
    showRecipeDetail: false,
    currentRecipe: null
  },

  onLoad() {
    // TODO: 从服务器获取数据
  },

  onSearchInput(e) {
    const keyword = e.detail.value
    // TODO: 根据关键词搜索
  },

  onCategoryTap(e) {
    const { id } = e.currentTarget.dataset
    this.setData({ currentCategory: id })
  },

  showMethodDetail(e) {
    const { index } = e.currentTarget.dataset
    const method = this.data.eatingMethods[index]
    wx.showModal({
      title: method.title,
      content: method.description,
      showCancel: false
    })
  },

  showRecipeDetail(e) {
    const { id } = e.currentTarget.dataset
    const recipe = this.data.recipes.find(item => item.id === id)
    this.setData({
      showRecipeDetail: true,
      currentRecipe: recipe
    })
  },

  closeRecipeDetail() {
    this.setData({ showRecipeDetail: false })
  },

  onShareAppMessage() {
    return {
      title: '樱桃健康知识',
      path: '/pages/health/index'
    }
  },

  onShareTimeline() {
    return {
      title: '樱桃健康知识'
    }
  }
}) 