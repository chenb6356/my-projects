const app = getApp()

Page({
  data: {
    phone: '',
    code: '',
    password: '',
    confirmPassword: '',
    showPassword: false,
    showConfirmPassword: false,
    countdown: 0,
    canSendCode: false,
    canSubmit: false,
    agreed: false,
    loading: false,
    loadingText: '注册中...',
    primaryColor: '#E3170D'
  },

  onLoad() {
    // 获取主题色
    this.setData({
      primaryColor: app.globalData.theme.primaryColor
    })
  },

  // 手机号输入
  onPhoneInput(e) {
    const phone = e.detail.value
    this.setData({
      phone,
      canSendCode: this.isValidPhone(phone)
    })
    this.checkCanSubmit()
  },

  // 清除手机号
  clearPhone() {
    this.setData({
      phone: '',
      canSendCode: false
    })
    this.checkCanSubmit()
  },

  // 验证码输入
  onCodeInput(e) {
    const code = e.detail.value
    this.setData({ code })
    this.checkCanSubmit()
  },

  // 密码输入
  onPasswordInput(e) {
    const password = e.detail.value
    this.setData({ password })
    this.checkCanSubmit()
  },

  // 确认密码输入
  onConfirmPasswordInput(e) {
    const confirmPassword = e.detail.value
    this.setData({ confirmPassword })
    this.checkCanSubmit()
  },

  // 切换密码可见性
  togglePasswordVisibility() {
    this.setData({
      showPassword: !this.data.showPassword
    })
  },

  // 切换确认密码可见性
  toggleConfirmPasswordVisibility() {
    this.setData({
      showConfirmPassword: !this.data.showConfirmPassword
    })
  },

  // 发送验证码
  async sendCode() {
    if (this.data.countdown > 0 || !this.isValidPhone(this.data.phone)) {
      return
    }

    this.setData({ loading: true, loadingText: '发送中...' })
    try {
      // 检查手机号是否已注册
      const isRegistered = await this.mockCheckPhone(this.data.phone)
      if (isRegistered) {
        wx.showToast({
          title: '该手机号已注册',
          icon: 'error'
        })
        return
      }

      await this.mockSendCode(this.data.phone)
      this.startCountdown()
      wx.showToast({
        title: '验证码已发送',
        icon: 'success'
      })
    } catch (error) {
      wx.showToast({
        title: error.message || '发送失败',
        icon: 'error'
      })
    } finally {
      this.setData({ loading: false })
    }
  },

  // 开始倒计时
  startCountdown() {
    this.setData({ countdown: 60 })
    const timer = setInterval(() => {
      if (this.data.countdown <= 1) {
        clearInterval(timer)
      }
      this.setData({
        countdown: this.data.countdown - 1
      })
    }, 1000)
  },

  // 提交表单
  async submitForm() {
    if (!this.checkFormValid()) {
      return
    }

    this.setData({ loading: true, loadingText: '注册中...' })
    try {
      const { phone, code, password } = this.data
      await this.mockRegister({ phone, code, password })
      
      wx.showToast({
        title: '注册成功',
        icon: 'success'
      })

      // 延迟跳转到登录页
      setTimeout(() => {
        wx.redirectTo({
          url: '/pages/login/index'
        })
      }, 1500)
    } catch (error) {
      wx.showToast({
        title: error.message || '注册失败',
        icon: 'error'
      })
    } finally {
      this.setData({ loading: false })
    }
  },

  // 检查是否可以提交
  checkCanSubmit() {
    const { phone, code, password, confirmPassword, agreed } = this.data
    const canSubmit = this.isValidPhone(phone) && 
      code.length === 6 && 
      this.isValidPassword(password) && 
      password === confirmPassword && 
      agreed
    this.setData({ canSubmit })
  },

  // 检查表单是否有效
  checkFormValid() {
    const { phone, code, password, confirmPassword, agreed } = this.data

    if (!this.isValidPhone(phone)) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none'
      })
      return false
    }

    if (code.length !== 6) {
      wx.showToast({
        title: '请输入6位验证码',
        icon: 'none'
      })
      return false
    }

    if (!this.isValidPassword(password)) {
      wx.showToast({
        title: '密码必须包含字母和数字，长度8-20位',
        icon: 'none'
      })
      return false
    }

    if (password !== confirmPassword) {
      wx.showToast({
        title: '两次输入的密码不一致',
        icon: 'none'
      })
      return false
    }

    if (!agreed) {
      wx.showToast({
        title: '请同意用户协议和隐私政策',
        icon: 'none'
      })
      return false
    }

    return true
  },

  // 验证手机号格式
  isValidPhone(phone) {
    return /^1[3-9]\d{9}$/.test(phone)
  },

  // 验证密码格式
  isValidPassword(password) {
    return /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,20}$/.test(password)
  },

  // 同意协议变化
  onAgreementChange(e) {
    this.setData({
      agreed: e.detail.value.includes('agreed')
    })
    this.checkCanSubmit()
  },

  // 跳转到登录页面
  navigateToLogin() {
    wx.navigateBack()
  },

  // 跳转到用户协议页面
  navigateToTerms() {
    wx.navigateTo({
      url: '/pages/user/terms/index'
    })
  },

  // 跳转到隐私政策页面
  navigateToPrivacy() {
    wx.navigateTo({
      url: '/pages/user/privacy/index'
    })
  },

  // 模拟检查手机号是否已注册
  mockCheckPhone(phone) {
    return new Promise((resolve) => {
      setTimeout(() => {
        // 模拟手机号13888888888已被注册
        resolve(phone === '13888888888')
      }, 500)
    })
  },

  // 模拟发送验证码
  mockSendCode(phone) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (this.isValidPhone(phone)) {
          resolve()
        } else {
          reject(new Error('手机号格式错误'))
        }
      }, 1000)
    })
  },

  // 模拟注册
  mockRegister({ phone, code, password }) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (!this.isValidPhone(phone)) {
          reject(new Error('手机号格式错误'))
          return
        }

        if (code !== '123456') {
          reject(new Error('验证码错误'))
          return
        }

        if (!this.isValidPassword(password)) {
          reject(new Error('密码格式错误'))
          return
        }

        resolve()
      }, 1500)
    })
  }
}) 