const app = getApp()

Page({
  data: {
    categories: [
      { id: 0, name: '全部' },
      { id: 1, name: '美早樱桃' },
      { id: 2, name: '红灯樱桃' },
      { id: 3, name: '黄蜜樱桃' },
      { id: 4, name: '礼盒装' },
      { id: 5, name: '散装' }
    ],
    currentCategory: 0,
    currentSort: 'default',
    priceAsc: true,
    products: [],
    pageNum: 1,
    pageSize: 10,
    loading: false,
    noMore: false,
    keyword: ''
  },

  onLoad() {
    this.loadProducts()
  },

  // 加载产品数据
  async loadProducts(refresh = false) {
    if (this.data.loading) return
    
    if (refresh) {
      this.setData({
        products: [],
        pageNum: 1,
        noMore: false
      })
    }

    this.setData({ loading: true })

    try {
      // TODO: 从服务器获取产品数据
      // 模拟数据
      const mockProducts = [
        {
          id: 1,
          name: '美早樱桃礼盒装',
          description: '精选美早樱桃，果大味甜，送礼佳品',
          price: 168.00,
          originalPrice: 198.00,
          salesCount: 1234,
          imageUrl: '/assets/images/product1.jpg',
          category: 1
        },
        {
          id: 2,
          name: '红灯樱桃精选装',
          description: '本地红灯樱桃，个大饱满，果肉细腻',
          price: 128.00,
          originalPrice: 158.00,
          salesCount: 2345,
          imageUrl: '/assets/images/product2.jpg',
          category: 2
        }
      ]

      // 模拟加载延迟
      await new Promise(resolve => setTimeout(resolve, 500))

      let newProducts = [...mockProducts]
      
      // 根据分类筛选
      if (this.data.currentCategory !== 0) {
        newProducts = newProducts.filter(item => item.category === this.data.currentCategory)
      }

      // 根据关键词搜索
      if (this.data.keyword) {
        newProducts = newProducts.filter(item => 
          item.name.includes(this.data.keyword) || 
          item.description.includes(this.data.keyword)
        )
      }

      // 排序处理
      switch (this.data.currentSort) {
        case 'sales':
          newProducts.sort((a, b) => b.salesCount - a.salesCount)
          break
        case 'price':
          newProducts.sort((a, b) => this.data.priceAsc ? a.price - b.price : b.price - a.price)
          break
      }

      this.setData({
        products: [...this.data.products, ...newProducts],
        pageNum: this.data.pageNum + 1,
        noMore: newProducts.length < this.data.pageSize
      })
    } catch (error) {
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      })
    } finally {
      this.setData({ loading: false })
    }
  },

  // 搜索输入处理
  onSearchInput(e) {
    this.setData({
      keyword: e.detail.value
    })
    this.debounceSearch()
  },

  // 防抖搜索
  debounceSearch: (function() {
    let timer = null
    return function() {
      if (timer) {
        clearTimeout(timer)
      }
      timer = setTimeout(() => {
        this.loadProducts(true)
      }, 500)
    }
  })(),

  // 分类点击处理
  onCategoryTap(e) {
    const { id } = e.currentTarget.dataset
    if (id === this.data.currentCategory) return
    this.setData({ currentCategory: id })
    this.loadProducts(true)
  },

  // 排序点击处理
  onSortTap(e) {
    const { sort } = e.currentTarget.dataset
    if (sort === this.data.currentSort) {
      if (sort === 'price') {
        this.setData({ priceAsc: !this.data.priceAsc })
      }
    } else {
      this.setData({ 
        currentSort: sort,
        priceAsc: true
      })
    }
    this.loadProducts(true)
  },

  // 产品点击处理
  onProductTap(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/product/detail?id=${id}`
    })
  },

  // 下拉刷新
  onPullDownRefresh() {
    this.loadProducts(true).then(() => {
      wx.stopPullDownRefresh()
    })
  },

  // 触底加载更多
  onReachBottom() {
    if (!this.data.noMore) {
      this.loadProducts()
    }
  },

  onShareAppMessage() {
    return {
      title: '上王村樱桃 - 品质樱桃，健康生活',
      path: '/pages/product/list'
    }
  }
}) 