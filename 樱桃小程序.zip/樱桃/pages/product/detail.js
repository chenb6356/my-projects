const app = getApp()

Page({
  data: {
    product: null,
    selectedSpec: null,
    selectedSpecName: '',
    quantity: 1,
    showSpecsPopup: false,
    isFavorite: false,
    actionType: '' // 'cart' or 'buy'
  },

  onLoad(options) {
    const { id } = options
    this.loadProductDetail(id)
    this.checkFavoriteStatus(id)
  },

  // 加载商品详情
  async loadProductDetail(id) {
    try {
      // TODO: 从服务器获取商品详情
      // 模拟数据
      const mockProduct = {
        id: 1,
        name: '美早樱桃礼盒装',
        subtitle: '精选美早樱桃，果大味甜，送礼佳品',
        price: 168.00,
        originalPrice: 198.00,
        salesCount: 1234,
        stock: 999,
        images: [
          '/assets/images/product1.jpg',
          '/assets/images/product2.jpg',
          '/assets/images/product3.jpg'
        ],
        specs: [
          { id: 1, name: '500g装' },
          { id: 2, name: '1kg装' },
          { id: 3, name: '2kg礼盒装' }
        ],
        description: '上王村美早樱桃，果实硕大，色泽鲜艳，肉质细腻，口感甜美。采用先进的种植技术，保证果品品质。',
        detailImages: [
          '/assets/images/detail1.jpg',
          '/assets/images/detail2.jpg',
          '/assets/images/detail3.jpg'
        ]
      }

      this.setData({ product: mockProduct })
    } catch (error) {
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      })
    }
  },

  // 检查收藏状态
  async checkFavoriteStatus(id) {
    // TODO: 从服务器获取收藏状态
    this.setData({ isFavorite: false })
  },

  // 预览图片
  previewImage(e) {
    const { url } = e.currentTarget.dataset
    const { images } = this.data.product
    wx.previewImage({
      current: url,
      urls: images
    })
  },

  // 规格选择
  onSpecSelect(e) {
    const { id } = e.currentTarget.dataset
    const spec = this.data.product.specs.find(item => item.id === id)
    this.setData({
      selectedSpec: id,
      selectedSpecName: spec.name
    })
  },

  // 弹窗内规格选择
  onPopupSpecSelect(e) {
    this.onSpecSelect(e)
  },

  // 数量减少
  onQuantityMinus() {
    if (this.data.quantity > 1) {
      this.setData({
        quantity: this.data.quantity - 1
      })
    }
  },

  // 数量增加
  onQuantityPlus() {
    if (this.data.quantity < this.data.product.stock) {
      this.setData({
        quantity: this.data.quantity + 1
      })
    }
  },

  // 数量输入
  onQuantityInput(e) {
    let quantity = parseInt(e.detail.value)
    if (isNaN(quantity) || quantity < 1) {
      quantity = 1
    } else if (quantity > this.data.product.stock) {
      quantity = this.data.product.stock
    }
    this.setData({ quantity })
  },

  // 显示规格弹窗
  showSpecsPopup(actionType) {
    this.setData({
      showSpecsPopup: true,
      actionType
    })
  },

  // 关闭规格弹窗
  closeSpecsPopup() {
    this.setData({ showSpecsPopup: false })
  },

  // 加入购物车
  onAddToCart() {
    if (!this.data.selectedSpec) {
      this.showSpecsPopup('cart')
      return
    }
    // TODO: 添加到购物车
    wx.showToast({
      title: '已加入购物车',
      icon: 'success'
    })
    this.closeSpecsPopup()
  },

  // 立即购买
  onBuyNow() {
    if (!this.data.selectedSpec) {
      this.showSpecsPopup('buy')
      return
    }
    // TODO: 跳转到订单确认页
    wx.navigateTo({
      url: '/pages/order/confirm'
    })
    this.closeSpecsPopup()
  },

  // 规格确认
  onSpecConfirm() {
    if (this.data.actionType === 'cart') {
      this.onAddToCart()
    } else {
      this.onBuyNow()
    }
  },

  // 联系客服
  onContactService() {
    // TODO: 调用客服接口
  },

  // 添加/取消收藏
  async onAddFavorite() {
    try {
      // TODO: 调用收藏接口
      this.setData({
        isFavorite: !this.data.isFavorite
      })
      wx.showToast({
        title: this.data.isFavorite ? '已收藏' : '已取消收藏',
        icon: 'success'
      })
    } catch (error) {
      wx.showToast({
        title: '操作失败，请重试',
        icon: 'none'
      })
    }
  },

  // 分享
  onShareTap() {
    // 微信小程序原生分享
  },

  onShareAppMessage() {
    const { product } = this.data
    return {
      title: product.name,
      path: `/pages/product/detail?id=${product.id}`,
      imageUrl: product.images[0]
    }
  },

  onShareTimeline() {
    const { product } = this.data
    return {
      title: product.name,
      query: `id=${product.id}`,
      imageUrl: product.images[0]
    }
  }
}) 