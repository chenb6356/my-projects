const app = getApp()

Page({
  data: {
    banners: [
      {
        id: 1,
        imageUrl: '/assets/images/activity-banner1.jpg',
        title: '樱桃采摘季开始啦！'
      },
      {
        id: 2,
        imageUrl: '/assets/images/activity-banner2.jpg',
        title: '樱桃手工DIY体验'
      },
      {
        id: 3,
        imageUrl: '/assets/images/activity-banner3.jpg',
        title: '樱桃科普小课堂'
      }
    ],
    categories: [
      {
        id: 1,
        name: '采摘体验',
        iconUrl: '/assets/icons/picking.png'
      },
      {
        id: 2,
        name: '手工制作',
        iconUrl: '/assets/icons/diy.png'
      },
      {
        id: 3,
        name: '科普教育',
        iconUrl: '/assets/icons/education.png'
      },
      {
        id: 4,
        name: '文化活动',
        iconUrl: '/assets/icons/culture.png'
      }
    ],
    activities: [
      {
        id: 1,
        title: '春季樱桃采摘体验',
        description: '带您体验最地道的樱桃采摘，品尝最新鲜的樱桃。专业果农现场指导，让您学习专业的采摘技巧。',
        imageUrl: '/assets/images/activity1.jpg',
        time: '2024-04-15 09:00',
        location: '上王村樱桃园',
        price: '￥128/人',
        tags: ['亲子活动', '采摘体验', '现场品尝'],
        status: '报名中',
        images: [
          '/assets/images/activity1-1.jpg',
          '/assets/images/activity1-2.jpg',
          '/assets/images/activity1-3.jpg'
        ],
        schedule: [
          {
            time: '09:00',
            content: '集合签到，发放采摘工具'
          },
          {
            time: '09:30',
            content: '采摘技巧讲解，安全注意事项说明'
          },
          {
            time: '10:00',
            content: '开始采摘体验'
          },
          {
            time: '12:00',
            content: '午餐时间（农家特色菜）'
          },
          {
            time: '13:30',
            content: '继续采摘/自由活动'
          },
          {
            time: '15:30',
            content: '活动结束，称重结算'
          }
        ],
        notices: [
          '请穿着舒适的衣物和运动鞋',
          '活动费用包含采摘工具、导览、午餐',
          '采摘的樱桃需另付费（市场价8折）',
          '请勿攀爬果树，注意安全',
          '儿童需在家长陪同下参加'
        ]
      },
      {
        id: 2,
        title: '樱桃果酱DIY工坊',
        description: '跟随专业老师学习制作纯天然樱桃果酱，体验手工制作的乐趣。',
        imageUrl: '/assets/images/activity2.jpg',
        time: '2024-04-20 14:00',
        location: '农业科技馆',
        price: '￥98/人',
        tags: ['DIY体验', '亲子互动', '伴手礼'],
        status: '报名中',
        images: [
          '/assets/images/activity2-1.jpg',
          '/assets/images/activity2-2.jpg',
          '/assets/images/activity2-3.jpg'
        ],
        schedule: [
          {
            time: '14:00',
            content: '签到，发放工具和材料'
          },
          {
            time: '14:15',
            content: '果酱制作工艺讲解'
          },
          {
            time: '14:45',
            content: '开始制作果酱'
          },
          {
            time: '16:00',
            content: '成品展示与品鉴'
          },
          {
            time: '16:30',
            content: '活动结束，领取成品'
          }
        ],
        notices: [
          '每人可获得2瓶自制果酱',
          '建议8岁以上儿童参加',
          '所有材料均已消毒，请放心使用',
          '如有食物过敏，请提前告知'
        ]
      }
    ],
    currentCategory: 0,
    showActivityDetail: false,
    showSignupForm: false,
    currentActivity: null
  },

  onLoad() {
    // TODO: 从服务器获取活动列表
  },

  onPullDownRefresh() {
    // TODO: 刷新活动列表
    wx.stopPullDownRefresh()
  },

  onCategoryTap(e) {
    const { id } = e.currentTarget.dataset
    this.setData({ currentCategory: id })
    // TODO: 根据分类筛选活动
  },

  onActivityTap(e) {
    const { id } = e.currentTarget.dataset
    const activity = this.data.activities.find(item => item.id === id)
    this.setData({
      showActivityDetail: true,
      currentActivity: activity
    })
  },

  closeActivityDetail() {
    this.setData({ showActivityDetail: false })
  },

  onSignupTap(e) {
    const { id } = e.currentTarget.dataset
    const activity = this.data.activities.find(item => item.id === id)
    if (activity.status !== '报名中') {
      wx.showToast({
        title: '活动已结束',
        icon: 'none'
      })
      return
    }
    this.setData({
      showSignupForm: true,
      currentActivity: activity,
      showActivityDetail: false
    })
  },

  closeSignupForm() {
    this.setData({ showSignupForm: false })
  },

  submitSignup(e) {
    const formData = e.detail.value
    // 表单验证
    if (!formData.name || !formData.phone || !formData.participants) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      })
      return
    }
    // 手机号验证
    if (!/^1[3-9]\d{9}$/.test(formData.phone)) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none'
      })
      return
    }
    // 参与人数验证
    const participants = parseInt(formData.participants)
    if (isNaN(participants) || participants < 1) {
      wx.showToast({
        title: '请输入正确的参与人数',
        icon: 'none'
      })
      return
    }

    // TODO: 提交报名信息到服务器
    wx.showLoading({
      title: '提交中...'
    })

    // 模拟提交
    setTimeout(() => {
      wx.hideLoading()
      wx.showToast({
        title: '报名成功',
        icon: 'success'
      })
      this.setData({ showSignupForm: false })
    }, 1500)
  },

  onShareAppMessage(res) {
    if (res.from === 'button') {
      const { currentActivity } = this.data
      return {
        title: currentActivity.title,
        path: `/pages/activity/index?id=${currentActivity.id}`,
        imageUrl: currentActivity.imageUrl
      }
    }
    return {
      title: '上王村樱桃园趣味活动',
      path: '/pages/activity/index'
    }
  },

  onShareTimeline() {
    return {
      title: '上王村樱桃园趣味活动',
      query: '',
      imageUrl: this.data.banners[0].imageUrl
    }
  }
}) 