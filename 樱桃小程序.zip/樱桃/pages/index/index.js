const app = getApp()

Page({
  data: {
    banners: [
      {
        id: 1,
        imageUrl: '/assets/images/banner1.jpg',
        link: '/pages/history/index'
      },
      {
        id: 2,
        imageUrl: '/assets/images/banner2.jpg',
        link: '/pages/product/detail?id=1'
      },
      {
        id: 3,
        imageUrl: '/assets/images/banner3.jpg',
        link: '/pages/video/garden/index'
      }
    ],
    features: [
      {
        id: 1,
        name: '樱桃历史',
        icon: '/assets/icons/history.png',
        path: '/pages/history/index'
      },
      {
        id: 2,
        name: '产品介绍',
        icon: '/assets/icons/product.png',
        path: '/pages/product/list'
      },
      {
        id: 3,
        name: '园林视频',
        icon: '/assets/icons/video.png',
        path: '/pages/video/garden/index'
      },
      {
        id: 4,
        name: '趣味活动',
        icon: '/assets/icons/activity.png',
        path: '/pages/activity/index'
      },
      {
        id: 5,
        name: '养生知识',
        icon: '/assets/icons/health.png',
        path: '/pages/health/index'
      },
      {
        id: 6,
        name: '用户晒单',
        icon: '/assets/icons/post.png',
        path: '/pages/user/posts'
      },
      {
        id: 7,
        name: '在线客服',
        icon: '/assets/icons/service.png',
        path: '/pages/service/index'
      },
      {
        id: 8,
        name: '我的订单',
        icon: '/assets/icons/order.png',
        path: '/pages/user/orders'
      }
    ],
    recommendProducts: [],
    healthArticles: []
  },

  onLoad() {
    this.loadRecommendProducts()
    this.loadHealthArticles()
  },

  // 加载推荐产品
  loadRecommendProducts() {
    // TODO: 从服务器获取推荐产品数据
    this.setData({
      recommendProducts: [
        {
          id: 1,
          name: '美早樱桃礼盒装',
          price: 168.00,
          imageUrl: '/assets/images/product1.jpg'
        },
        {
          id: 2,
          name: '红灯樱桃精选装',
          price: 128.00,
          imageUrl: '/assets/images/product2.jpg'
        },
        {
          id: 3,
          name: '黄蜜樱桃尊享装',
          price: 198.00,
          imageUrl: '/assets/images/product3.jpg'
        }
      ]
    })
  },

  // 加载养生文章
  loadHealthArticles() {
    // TODO: 从服务器获取养生文章数据
    this.setData({
      healthArticles: [
        {
          id: 1,
          title: '樱桃的8大养生功效',
          description: '樱桃不仅美味可口，还具有多种保健功效...',
          imageUrl: '/assets/images/health1.jpg'
        },
        {
          id: 2,
          title: '春季养生必备：樱桃食谱',
          description: '春季是食用樱桃的最佳时节，推荐几道美味樱桃食谱...',
          imageUrl: '/assets/images/health2.jpg'
        }
      ]
    })
  },

  // 搜索输入处理
  onSearchInput(e) {
    const keyword = e.detail.value
    // TODO: 处理搜索逻辑
  },

  // 语音搜索
  onVoiceSearch() {
    // TODO: 调用语音识别API
    wx.showToast({
      title: '语音搜索开发中',
      icon: 'none'
    })
  },

  // Banner点击处理
  onBannerTap(e) {
    const { id } = e.currentTarget.dataset
    const banner = this.data.banners.find(item => item.id === id)
    if (banner && banner.link) {
      wx.navigateTo({
        url: banner.link
      })
    }
  },

  // 功能模块点击处理
  onFeatureTap(e) {
    const { path } = e.currentTarget.dataset
    // tabBar页面使用switchTab
    if (['/pages/product/list', '/pages/activity/index', '/pages/user/index'].includes(path)) {
      wx.switchTab({
        url: path
      })
    } else {
      wx.navigateTo({
        url: path
      })
    }
  },

  // 查看更多产品
  onMoreTap() {
    wx.switchTab({
      url: '/pages/product/list'
    })
  },

  // 产品点击处理
  onProductTap(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/product/detail?id=${id}`
    })
  },

  // 查看更多养生文章
  onMoreHealthTap() {
    wx.navigateTo({
      url: '/pages/health/index'
    })
  },

  // 文章点击处理
  onArticleTap(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/health/detail?id=${id}`
    })
  },

  onShareAppMessage() {
    return {
      title: '上王村樱桃 - 品质樱桃，健康生活',
      path: '/pages/index/index'
    }
  }
}) 