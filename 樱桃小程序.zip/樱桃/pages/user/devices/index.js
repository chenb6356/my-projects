Page({
  data: {
    currentDevice: {
      id: '',
      name: '',
      type: '',
      location: '',
      loginTime: ''
    },
    otherDevices: [],
    loading: false,
    loadingText: '加载中...'
  },

  onLoad() {
    this.loadDevices()
  },

  // 加载设备列表
  async loadDevices() {
    this.setData({ loading: true, loadingText: '加载中...' })
    try {
      const { currentDevice, otherDevices } = await this.mockGetDevices()
      this.setData({ currentDevice, otherDevices })
    } catch (error) {
      wx.showToast({
        title: error.message || '加载失败',
        icon: 'error'
      })
    } finally {
      this.setData({ loading: false })
    }
  },

  // 退出单个设备
  async logoutDevice(e) {
    const deviceId = e.currentTarget.dataset.id
    const device = this.data.otherDevices.find(item => item.id === deviceId)
    
    wx.showModal({
      title: '退出确认',
      content: `确定要退出设备"${device.name}"吗？`,
      async success: (res) => {
        if (res.confirm) {
          this.setData({ loading: true, loadingText: '退出中...' })
          try {
            await this.mockLogoutDevice(deviceId)
            
            // 更新设备列表
            const otherDevices = this.data.otherDevices.filter(item => item.id !== deviceId)
            this.setData({ otherDevices })

            wx.showToast({
              title: '已退出该设备',
              icon: 'success'
            })
          } catch (error) {
            wx.showToast({
              title: error.message || '退出失败',
              icon: 'error'
            })
          } finally {
            this.setData({ loading: false })
          }
        }
      }
    })
  },

  // 退出所有其他设备
  logoutAllDevices() {
    wx.showModal({
      title: '退出确认',
      content: '确定要退出所有其他设备吗？',
      async success: (res) => {
        if (res.confirm) {
          this.setData({ loading: true, loadingText: '退出中...' })
          try {
            await this.mockLogoutAllDevices()
            
            // 清空其他设备列表
            this.setData({ otherDevices: [] })

            wx.showToast({
              title: '已退出所有设备',
              icon: 'success'
            })
          } catch (error) {
            wx.showToast({
              title: error.message || '退出失败',
              icon: 'error'
            })
          } finally {
            this.setData({ loading: false })
          }
        }
      }
    })
  },

  // 模拟获取设备列表
  mockGetDevices() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          currentDevice: {
            id: 'D001',
            name: 'iPhone 14 Pro',
            type: 'ios',
            location: '浙江杭州',
            loginTime: '2024-03-25 15:30:00'
          },
          otherDevices: [
            {
              id: 'D002',
              name: 'MacBook Pro',
              type: 'mac',
              location: '浙江杭州',
              loginTime: '2024-03-24 10:20:00'
            },
            {
              id: 'D003',
              name: 'Xiaomi 13',
              type: 'android',
              location: '浙江宁波',
              loginTime: '2024-03-23 18:45:00'
            }
          ]
        })
      }, 500)
    })
  },

  // 模拟退出设备
  mockLogoutDevice(deviceId) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve()
      }, 1000)
    })
  },

  // 模拟退出所有设备
  mockLogoutAllDevices() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve()
      }, 1500)
    })
  }
}) 