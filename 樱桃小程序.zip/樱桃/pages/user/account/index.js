const app = getApp()

Page({
  data: {
    accountInfo: {
      id: '',
      phone: '',
      registerTime: '',
      lastLoginTime: '',
      deviceCount: 0
    },
    showDeletePopup: false,
    agreed: false,
    loading: false,
    loadingText: '加载中...'
  },

  onLoad() {
    this.loadAccountInfo()
  },

  // 加载账号信息
  async loadAccountInfo() {
    this.setData({ loading: true, loadingText: '加载中...' })
    try {
      const accountInfo = await this.mockGetAccountInfo()
      this.setData({ accountInfo })
    } catch (error) {
      wx.showToast({
        title: error.message || '加载失败',
        icon: 'error'
      })
    } finally {
      this.setData({ loading: false })
    }
  },

  // 修改密码
  changePassword() {
    wx.navigateTo({
      url: '/pages/user/password/index'
    })
  },

  // 更换手机号
  changePhone() {
    wx.navigateTo({
      url: '/pages/user/phone/index'
    })
  },

  // 管理登录设备
  manageDevices() {
    wx.navigateTo({
      url: '/pages/user/devices/index'
    })
  },

  // 注销账号
  deleteAccount() {
    this.setData({
      showDeletePopup: true,
      agreed: false
    })
  },

  // 关闭注销弹窗
  closeDeletePopup() {
    this.setData({
      showDeletePopup: false,
      agreed: false
    })
  },

  // 阻止冒泡
  stopPropagation() {
    return
  },

  // 同意协议变化
  onAgreementChange(e) {
    this.setData({
      agreed: e.detail.value.includes('agreed')
    })
  },

  // 确认注销
  async confirmDelete() {
    if (!this.data.agreed) {
      return
    }

    this.setData({ loading: true, loadingText: '注销中...' })
    try {
      await this.mockDeleteAccount()
      
      wx.showToast({
        title: '注销成功',
        icon: 'success'
      })

      // 清除本地存储
      wx.clearStorageSync()

      // 延迟跳转到登录页
      setTimeout(() => {
        wx.reLaunch({
          url: '/pages/login/index'
        })
      }, 1500)
    } catch (error) {
      wx.showToast({
        title: error.message || '注销失败',
        icon: 'error'
      })
    } finally {
      this.setData({ 
        loading: false,
        showDeletePopup: false
      })
    }
  },

  // 模拟获取账号信息
  mockGetAccountInfo() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          id: 'U123456789',
          phone: '138****8888',
          registerTime: '2024-03-20 10:00:00',
          lastLoginTime: '2024-03-25 15:30:00',
          deviceCount: 2
        })
      }, 500)
    })
  },

  // 模拟注销账号
  mockDeleteAccount() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve()
      }, 1500)
    })
  }
}) 