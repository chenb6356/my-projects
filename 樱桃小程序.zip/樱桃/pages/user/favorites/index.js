const app = getApp();

Page({
  data: {
    currentTab: 'product', // product 或 post
    products: [],
    posts: [],
    page: 1,
    pageSize: 10,
    loading: false,
    refreshing: false,
    noMore: false,
    showToolbar: false,
    isAllSelected: false,
    selectedIds: [],
    primaryColor: app.globalData.theme.primaryColor
  },

  onLoad() {
    this.loadFavorites();
  },

  onShow() {
    // 如果从商品详情或帖子详情返回，可能需要刷新列表
    if (app.globalData.needRefreshFavorites) {
      this.refreshFavorites();
      app.globalData.needRefreshFavorites = false;
    }
  },

  // 切换标签
  onTabChange(e) {
    const tab = e.currentTarget.dataset.tab;
    if (tab === this.data.currentTab) return;
    
    this.setData({
      currentTab: tab,
      products: [],
      posts: [],
      page: 1,
      noMore: false,
      showToolbar: false,
      isAllSelected: false,
      selectedIds: []
    });
    this.loadFavorites();
  },

  // 加载收藏列表
  async loadFavorites() {
    if (this.data.loading || this.data.noMore) return;

    try {
      this.setData({ loading: true });

      // TODO: 调用后端API获取收藏列表
      const list = await this.mockGetFavorites();
      
      const key = this.data.currentTab === 'product' ? 'products' : 'posts';
      this.setData({
        [key]: [...this.data[key], ...list],
        page: this.data.page + 1,
        noMore: list.length < this.data.pageSize,
        loading: false
      });
    } catch (error) {
      console.error('加载收藏列表失败:', error);
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      });
      this.setData({ loading: false });
    }
  },

  // 刷新收藏列表
  async refreshFavorites() {
    try {
      this.setData({ refreshing: true });

      // TODO: 调用后端API获取收藏列表
      const list = await this.mockGetFavorites(true);
      
      const key = this.data.currentTab === 'product' ? 'products' : 'posts';
      this.setData({
        [key]: list,
        page: 2,
        noMore: list.length < this.data.pageSize,
        refreshing: false,
        showToolbar: false,
        isAllSelected: false,
        selectedIds: []
      });
    } catch (error) {
      console.error('刷新收藏列表失败:', error);
      wx.showToast({
        title: '刷新失败，请重试',
        icon: 'none'
      });
      this.setData({ refreshing: false });
    }
  },

  // 加载更多
  onLoadMore() {
    this.loadFavorites();
  },

  // 下拉刷新
  onRefresh() {
    this.refreshFavorites();
  },

  // 跳转到商品详情
  navigateToProduct(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/product/detail?id=${id}`
    });
  },

  // 跳转到帖子详情
  navigateToPost(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/community/post/detail?id=${id}`
    });
  },

  // 加入购物车
  async addToCart(e) {
    const { id } = e.currentTarget.dataset;
    try {
      // TODO: 调用后端API添加到购物车
      await new Promise(resolve => setTimeout(resolve, 500));
      
      wx.showToast({
        title: '已加入购物车',
        icon: 'success'
      });
    } catch (error) {
      console.error('加入购物车失败:', error);
      wx.showToast({
        title: '加入失败，请重试',
        icon: 'none'
      });
    }
  },

  // 取消收藏商品
  async unfavoriteProduct(e) {
    const { id } = e.currentTarget.dataset;
    wx.showModal({
      title: '提示',
      content: '确定要取消收藏该商品吗？',
      async success: (res) => {
        if (res.confirm) {
          try {
            // TODO: 调用后端API取消收藏
            await new Promise(resolve => setTimeout(resolve, 500));
            
            // 更新列表
            const products = this.data.products.filter(item => item.id !== id);
            this.setData({ products });
            
            wx.showToast({
              title: '已取消收藏',
              icon: 'success'
            });
          } catch (error) {
            console.error('取消收藏失败:', error);
            wx.showToast({
              title: '操作失败，请重试',
              icon: 'none'
            });
          }
        }
      }
    });
  },

  // 取消收藏帖子
  async unfavoritePost(e) {
    const { id } = e.currentTarget.dataset;
    wx.showModal({
      title: '提示',
      content: '确定要取消收藏该帖子吗？',
      async success: (res) => {
        if (res.confirm) {
          try {
            // TODO: 调用后端API取消收藏
            await new Promise(resolve => setTimeout(resolve, 500));
            
            // 更新列表
            const posts = this.data.posts.filter(item => item.id !== id);
            this.setData({ posts });
            
            wx.showToast({
              title: '已取消收藏',
              icon: 'success'
            });
          } catch (error) {
            console.error('取消收藏失败:', error);
            wx.showToast({
              title: '操作失败，请重试',
              icon: 'none'
            });
          }
        }
      }
    });
  },

  // 预览图片
  previewImage(e) {
    const { url, urls } = e.currentTarget.dataset;
    wx.previewImage({
      current: url,
      urls
    });
  },

  // 跳转到列表页
  navigateToList() {
    if (this.data.currentTab === 'product') {
      wx.switchTab({
        url: '/pages/product/list'
      });
    } else {
      wx.navigateTo({
        url: '/pages/community/post/list'
      });
    }
  },

  // Mock数据 - 实际开发时替换为真实API调用
  mockGetFavorites(isRefresh = false) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (this.data.currentTab === 'product') {
          const products = Array.from({ length: this.data.pageSize }, (_, i) => ({
            id: isRefresh ? `new_${i}` : `${this.data.page}_${i}`,
            name: '上王村樱桃 - 美早樱桃',
            description: '果大色艳，肉质细嫩，甜度适中',
            price: 68.00,
            salesCount: Math.floor(Math.random() * 1000),
            image: '/assets/images/cherry1.jpg'
          }));
          resolve(products);
        } else {
          const posts = Array.from({ length: this.data.pageSize }, (_, i) => ({
            id: isRefresh ? `new_${i}` : `${this.data.page}_${i}`,
            title: '樱桃种植技术分享',
            content: '今天给大家分享一下我种植樱桃的心得体会。首先要选择适合的品种，其次是土壤管理要得当，再者是科学的修剪技术...',
            createTime: '2024-03-15 14:30',
            images: [
              '/assets/images/cherry1.jpg',
              '/assets/images/cherry2.jpg',
              '/assets/images/cherry3.jpg'
            ],
            viewCount: Math.floor(Math.random() * 1000),
            likeCount: Math.floor(Math.random() * 100),
            commentCount: Math.floor(Math.random() * 50)
          }));
          resolve(posts);
        }
      }, 500);
    });
  }
}); 