const app = getApp();

Page({
  data: {
    currentTab: 'published', // published 或 draft
    posts: [],
    page: 1,
    pageSize: 10,
    loading: false,
    refreshing: false,
    noMore: false,
    showSharePopup: false,
    currentSharePostId: '',
    primaryColor: app.globalData.theme.primaryColor
  },

  onLoad() {
    this.loadPosts();
  },

  onShow() {
    // 如果从发布页面返回，可能需要刷新列表
    if (app.globalData.needRefreshPosts) {
      this.refreshPosts();
      app.globalData.needRefreshPosts = false;
    }
  },

  // 切换标签
  onTabChange(e) {
    const tab = e.currentTarget.dataset.tab;
    if (tab === this.data.currentTab) return;
    
    this.setData({
      currentTab: tab,
      posts: [],
      page: 1,
      noMore: false
    });
    this.loadPosts();
  },

  // 加载帖子列表
  async loadPosts() {
    if (this.data.loading || this.data.noMore) return;

    try {
      this.setData({ loading: true });

      // TODO: 调用后端API获取帖子列表
      const posts = await this.mockGetPosts();
      
      this.setData({
        posts: [...this.data.posts, ...posts],
        page: this.data.page + 1,
        noMore: posts.length < this.data.pageSize,
        loading: false
      });
    } catch (error) {
      console.error('加载帖子列表失败:', error);
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      });
      this.setData({ loading: false });
    }
  },

  // 刷新帖子列表
  async refreshPosts() {
    try {
      this.setData({ refreshing: true });

      // TODO: 调用后端API获取帖子列表
      const posts = await this.mockGetPosts(true);
      
      this.setData({
        posts,
        page: 2,
        noMore: posts.length < this.data.pageSize,
        refreshing: false
      });
    } catch (error) {
      console.error('刷新帖子列表失败:', error);
      wx.showToast({
        title: '刷新失败，请重试',
        icon: 'none'
      });
      this.setData({ refreshing: false });
    }
  },

  // 加载更多
  onLoadMore() {
    this.loadPosts();
  },

  // 下拉刷新
  onRefresh() {
    this.refreshPosts();
  },

  // 跳转到帖子详情
  navigateToDetail(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/community/post/detail?id=${id}`
    });
  },

  // 编辑帖子
  editPost(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/community/post/edit?id=${id}`
    });
  },

  // 删除帖子
  deletePost(e) {
    const { id } = e.currentTarget.dataset;
    wx.showModal({
      title: '提示',
      content: '确定要删除这条帖子吗？',
      async success: (res) => {
        if (res.confirm) {
          try {
            // TODO: 调用后端API删除帖子
            await new Promise(resolve => setTimeout(resolve, 500));
            
            // 更新列表
            const posts = this.data.posts.filter(post => post.id !== id);
            this.setData({ posts });
            
            wx.showToast({
              title: '删除成功',
              icon: 'success'
            });
          } catch (error) {
            console.error('删除帖子失败:', error);
            wx.showToast({
              title: '删除失败，请重试',
              icon: 'none'
            });
          }
        }
      }
    });
  },

  // 创建新帖子
  createPost() {
    wx.navigateTo({
      url: '/pages/community/post/edit'
    });
  },

  // 分享帖子
  sharePost(e) {
    const { id } = e.currentTarget.dataset;
    this.setData({
      showSharePopup: true,
      currentSharePostId: id
    });
  },

  // 关闭分享弹窗
  closeSharePopup() {
    this.setData({
      showSharePopup: false,
      currentSharePostId: ''
    });
  },

  // 分享到朋友圈
  shareToTimeline() {
    // TODO: 实现分享到朋友圈的功能
    wx.showToast({
      title: '分享到朋友圈',
      icon: 'success'
    });
    this.closeSharePopup();
  },

  // 复制链接
  copyLink() {
    // TODO: 生成分享链接
    const link = `https://example.com/post/${this.data.currentSharePostId}`;
    wx.setClipboardData({
      data: link,
      success: () => {
        wx.showToast({
          title: '链接已复制',
          icon: 'success'
        });
        this.closeSharePopup();
      }
    });
  },

  // 预览图片
  previewImage(e) {
    const { url, urls } = e.currentTarget.dataset;
    wx.previewImage({
      current: url,
      urls
    });
  },

  onShareAppMessage(res) {
    if (res.from === 'button') {
      const post = this.data.posts.find(p => p.id === this.data.currentSharePostId);
      return {
        title: post.title,
        path: `/pages/community/post/detail?id=${post.id}`,
        imageUrl: post.images?.[0]
      };
    }
    return {
      title: '我的帖子',
      path: '/pages/user/posts/index'
    };
  },

  // Mock数据 - 实际开发时替换为真实API调用
  mockGetPosts(isRefresh = false) {
    return new Promise((resolve) => {
      setTimeout(() => {
        const posts = Array.from({ length: this.data.pageSize }, (_, i) => ({
          id: isRefresh ? `new_${i}` : `${this.data.page}_${i}`,
          title: '樱桃种植技术分享',
          content: '今天给大家分享一下我种植樱桃的心得体会。首先要选择适合的品种，其次是土壤管理要得当，再者是科学的修剪技术...',
          createTime: '2024-03-15 14:30',
          images: [
            '/assets/images/cherry1.jpg',
            '/assets/images/cherry2.jpg',
            '/assets/images/cherry3.jpg'
          ],
          viewCount: Math.floor(Math.random() * 1000),
          likeCount: Math.floor(Math.random() * 100),
          commentCount: Math.floor(Math.random() * 50)
        }));
        resolve(posts);
      }, 500);
    });
  }
}); 