const app = getApp()

Page({
  data: {
    userInfo: null,
    userData: {
      orderCount: 0,
      postCount: 0,
      favoriteCount: 0,
      couponCount: 0,
      pendingPayment: 0,
      processing: 0,
      shipping: 0,
      afterSale: 0
    }
  },

  onLoad() {
    this.checkLoginStatus()
    this.getUserData()
  },

  onShow() {
    if (this.data.userInfo) {
      this.getUserData()
    }
  },

  onPullDownRefresh() {
    if (this.data.userInfo) {
      this.getUserData().then(() => {
        wx.stopPullDownRefresh()
      })
    } else {
      wx.stopPullDownRefresh()
    }
  },

  // 检查登录状态
  checkLoginStatus() {
    const userInfo = wx.getStorageSync('userInfo')
    if (userInfo) {
      this.setData({ userInfo })
    }
  },

  // 获取用户数据
  async getUserData() {
    if (!this.data.userInfo) return

    try {
      // TODO: 调用后端API获取用户数据
      const userData = {
        orderCount: 8,
        postCount: 3,
        favoriteCount: 12,
        couponCount: 5,
        pendingPayment: 2,
        processing: 1,
        shipping: 3,
        afterSale: 0
      }
      this.setData({ userData })
    } catch (error) {
      console.error('获取用户数据失败：', error)
      wx.showToast({
        title: '获取数据失败',
        icon: 'none'
      })
    }
  },

  // 登录
  async onLogin() {
    try {
      // 获取用户信息
      const { userInfo } = await wx.getUserProfile({
        desc: '用于完善会员资料'
      })

      // TODO: 调用后端登录接口
      const loginResult = {
        success: true,
        data: {
          ...userInfo,
          memberLevel: '普通会员'
        }
      }

      if (loginResult.success) {
        wx.setStorageSync('userInfo', loginResult.data)
        this.setData({ userInfo: loginResult.data })
        this.getUserData()
      }
    } catch (error) {
      console.error('登录失败：', error)
      wx.showToast({
        title: '登录失败',
        icon: 'none'
      })
    }
  },

  // 导航函数
  navigateToOrders(e) {
    const type = e.currentTarget.dataset.type
    wx.navigateTo({
      url: `/pages/user/orders/index?type=${type}`
    })
  },

  navigateToPosts() {
    wx.navigateTo({
      url: 'posts/index',
      fail(err) {
        console.error('跳转失败:', err)
        wx.showToast({
          title: '页面加载失败',
          icon: 'none'
        })
      }
    })
  },

  navigateToFavorites() {
    wx.navigateTo({
      url: '/pages/user/favorites/index'
    })
  },

  navigateToCoupons() {
    wx.navigateTo({
      url: '/pages/user/coupons/index'
    })
  },

  navigateToAddress() {
    wx.navigateTo({
      url: '/pages/user/address/index'
    })
  },

  navigateToFeedback() {
    wx.navigateTo({
      url: '/pages/user/feedback/index'
    })
  },

  navigateToHelp() {
    wx.navigateTo({
      url: '/pages/user/help/index'
    })
  },

  navigateToSettings() {
    wx.navigateTo({
      url: '/pages/user/settings/index'
    })
  },

  navigateToMerchant() {
    wx.navigateTo({
      url: '/pages/merchant/index'
    })
  },

  onShareAppMessage() {
    return {
      title: '上望樱桃',
      path: '/pages/index/index'
    }
  },

  onShareTimeline() {
    return {
      title: '上望樱桃'
    }
  }
}) 