const app = getApp();

Page({
  data: {
    orderId: '',
    order: null,
    rating: {
      quality: 0,
      logistics: 0,
      service: 0
    },
    content: '',
    images: [],
    isAnonymous: false,
    loading: false,
    primaryColor: app.globalData.theme.primaryColor,
    canSubmit: false
  },

  onLoad(options) {
    if (options.id) {
      this.setData({
        orderId: options.id
      });
      this.loadOrderInfo();
    }
  },

  // 加载订单信息
  async loadOrderInfo() {
    try {
      // TODO: 调用后端API获取订单信息
      const order = await this.mockGetOrderInfo();
      this.setData({ order });
    } catch (error) {
      console.error('加载订单信息失败:', error);
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      });
    }
  },

  // 商品质量评分
  onQualityRating(e) {
    const rating = e.currentTarget.dataset.rating;
    this.setData({
      'rating.quality': rating
    });
    this.checkCanSubmit();
  },

  // 物流服务评分
  onLogisticsRating(e) {
    const rating = e.currentTarget.dataset.rating;
    this.setData({
      'rating.logistics': rating
    });
    this.checkCanSubmit();
  },

  // 服务态度评分
  onServiceRating(e) {
    const rating = e.currentTarget.dataset.rating;
    this.setData({
      'rating.service': rating
    });
    this.checkCanSubmit();
  },

  // 评价内容输入
  onContentInput(e) {
    this.setData({
      content: e.detail.value
    });
    this.checkCanSubmit();
  },

  // 选择图片
  async chooseImage() {
    try {
      const res = await wx.chooseMedia({
        count: 9 - this.data.images.length,
        mediaType: ['image'],
        sourceType: ['album', 'camera'],
        sizeType: ['compressed']
      });
      
      const newImages = res.tempFiles.map(file => file.tempFilePath);
      this.setData({
        images: [...this.data.images, ...newImages]
      });
    } catch (error) {
      console.error('选择图片失败:', error);
    }
  },

  // 预览图片
  previewImage(e) {
    const { url } = e.currentTarget.dataset;
    wx.previewImage({
      current: url,
      urls: this.data.images
    });
  },

  // 删除图片
  deleteImage(e) {
    const { index } = e.currentTarget.dataset;
    const images = this.data.images.filter((_, i) => i !== index);
    this.setData({ images });
  },

  // 匿名评价切换
  onAnonymousChange(e) {
    this.setData({
      isAnonymous: e.detail.value
    });
  },

  // 检查是否可以提交
  checkCanSubmit() {
    const { rating, content } = this.data;
    const canSubmit = rating.quality > 0 && 
                      rating.logistics > 0 && 
                      rating.service > 0 && 
                      content.trim().length > 0;
    this.setData({ canSubmit });
  },

  // 提交评价
  async submitReview() {
    if (!this.data.canSubmit) return;

    try {
      this.setData({ loading: true });

      // 上传图片
      const uploadedImages = [];
      for (const image of this.data.images) {
        try {
          // TODO: 实现图片上传
          await new Promise(resolve => setTimeout(resolve, 500));
          uploadedImages.push(`https://example.com/image${Date.now()}.jpg`);
        } catch (error) {
          console.error('图片上传失败:', error);
          wx.showToast({
            title: '图片上传失败',
            icon: 'none'
          });
          this.setData({ loading: false });
          return;
        }
      }

      // 提交评价
      const params = {
        orderId: this.data.orderId,
        rating: this.data.rating,
        content: this.data.content,
        images: uploadedImages,
        isAnonymous: this.data.isAnonymous
      };

      // TODO: 调用后端API提交评价
      await new Promise(resolve => setTimeout(resolve, 1000));

      this.setData({ loading: false });
      wx.showToast({
        title: '评价成功',
        icon: 'success'
      });

      // 返回上一页
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);

    } catch (error) {
      console.error('提交评价失败:', error);
      this.setData({ loading: false });
      wx.showToast({
        title: '提交失败，请重试',
        icon: 'none'
      });
    }
  },

  // Mock数据 - 实际开发时替换为真实API调用
  mockGetOrderInfo() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          id: '123456',
          goods: [{
            id: 1,
            image: '/assets/images/goods/cherry1.jpg',
            name: '樱桃大礼包',
            spec: '500g/盒'
          }]
        });
      }, 500);
    });
  }
}); 