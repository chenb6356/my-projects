Page({
  data: {
    orderId: '',
    logistics: null,
    loading: true,
    error: ''
  },

  onLoad(options) {
    try {
      if (options.id) {
        this.setData({
          orderId: options.id
        });
        this.loadLogisticsInfo();
      }
    } catch (error) {
      console.error('页面加载错误:', error);
      this.setData({ 
        loading: false,
        error: '加载失败，请重试'
      });
    }
  },

  onPullDownRefresh() {
    this.loadLogisticsInfo();
  },

  // 加载物流信息
  async loadLogisticsInfo() {
    try {
      this.setData({ 
        loading: true,
        error: ''
      });
      // TODO: 调用后端API获取物流信息
      const logistics = await this.mockGetLogisticsInfo();
      this.setData({
        logistics,
        loading: false
      });
      wx.stopPullDownRefresh();
    } catch (error) {
      console.error('加载物流信息失败:', error);
      this.setData({ 
        loading: false,
        error: '加载失败，请重试'
      });
      wx.stopPullDownRefresh();
    }
  },

  // 复制运单号
  copyTrackingNo() {
    const { logistics } = this.data;
    if (logistics && logistics.trackingNo) {
      wx.setClipboardData({
        data: logistics.trackingNo,
        success() {
          wx.showToast({
            title: '复制成功',
            icon: 'success'
          });
        }
      });
    }
  },

  // 联系客服
  contactService() {
    // TODO: 实现客服联系功能
    wx.showToast({
      title: '正在接入客服...',
      icon: 'loading'
    });
  },

  // 重试加载
  retry() {
    this.loadLogisticsInfo();
  },

  // Mock数据 - 实际开发时替换为真实API调用
  mockGetLogisticsInfo() {
    return new Promise((resolve, reject) => {
      try {
        setTimeout(() => {
          resolve({
            company: '顺丰速运',
            trackingNo: 'SF1234567890123',
            status: '运输中',
            updateTime: '2024-03-15 14:30:00',
            receiver: {
              name: '张三',
              phone: '13800138000',
              address: '浙江省杭州市西湖区西溪路100号'
            },
            traces: [
              {
                status: '【杭州市】快件已到达【西湖区配送点】',
                time: '2024-03-15 14:30:00',
                location: '浙江省杭州市'
              },
              {
                status: '【杭州市】快件在【杭州转运中心】完成分拣，准备发往【西湖区配送点】',
                time: '2024-03-15 10:20:00',
                location: '浙江省杭州市'
              },
              {
                status: '【金华市】快件已从【金华中心】发出，准备发往【杭州转运中心】',
                time: '2024-03-15 06:15:00',
                location: '浙江省金华市'
              },
              {
                status: '【金华市】快件已到达【金华中心】',
                time: '2024-03-15 03:30:00',
                location: '浙江省金华市'
              },
              {
                status: '【金华市】【上王村营业点】已揽收',
                time: '2024-03-14 16:45:00',
                location: '浙江省金华市'
              }
            ]
          });
        }, 1000);
      } catch (error) {
        reject(error);
      }
    });
  }
}); 