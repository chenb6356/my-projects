const app = getApp()

Page({
  data: {
    tabs: [
      { name: '全部', type: 'all', count: 0 },
      { name: '待付款', type: 'pending', count: 0 },
      { name: '待发货', type: 'processing', count: 0 },
      { name: '待收货', type: 'shipping', count: 0 },
      { name: '已完成', type: 'completed', count: 0 }
    ],
    currentTab: 0,
    orders: [],
    page: 1,
    pageSize: 10,
    loading: false,
    refreshing: false,
    noMore: false
  },

  onLoad(options) {
    // 根据传入的type参数切换到对应标签
    const { type } = options
    if (type) {
      const index = this.data.tabs.findIndex(tab => tab.type === type)
      if (index !== -1) {
        this.setData({ currentTab: index })
      }
    }
    this.loadOrders(true)
  },

  onShow() {
    this.loadOrderCounts()
  },

  // 加载订单数量
  async loadOrderCounts() {
    try {
      // TODO: 调用后端API获取各状态订单数量
      const counts = {
        all: 8,
        pending: 2,
        processing: 1,
        shipping: 3,
        completed: 2
      }

      const tabs = this.data.tabs.map(tab => ({
        ...tab,
        count: counts[tab.type] || 0
      }))

      this.setData({ tabs })
    } catch (error) {
      console.error('获取订单数量失败：', error)
    }
  },

  // 加载订单列表
  async loadOrders(refresh = false) {
    if (this.data.loading) return

    const { currentTab, tabs, page, pageSize } = this.data
    const type = tabs[currentTab].type

    try {
      this.setData({ loading: true })

      // TODO: 调用后端API获取订单列表
      const res = {
        list: [
          {
            id: '1',
            createTime: '2024-03-10 14:30',
            status: 'pending',
            statusText: '待付款',
            goods: [
              {
                id: '1',
                image: '/assets/images/cherry1.jpg',
                name: '美早樱桃',
                spec: '500g/盒',
                price: 68.00,
                count: 2
              }
            ],
            totalCount: 2,
            totalAmount: 136.00
          },
          {
            id: '2',
            createTime: '2024-03-09 15:20',
            status: 'shipping',
            statusText: '待收货',
            goods: [
              {
                id: '2',
                image: '/assets/images/cherry2.jpg',
                name: '红灯樱桃',
                spec: '1kg/盒',
                price: 128.00,
                count: 1
              }
            ],
            totalCount: 1,
            totalAmount: 128.00
          }
        ],
        hasMore: false
      }

      if (refresh) {
        this.setData({
          orders: res.list,
          page: 1,
          noMore: !res.hasMore
        })
      } else {
        this.setData({
          orders: [...this.data.orders, ...res.list],
          page: page + 1,
          noMore: !res.hasMore
        })
      }
    } catch (error) {
      console.error('获取订单列表失败：', error)
      wx.showToast({
        title: '获取订单失败',
        icon: 'none'
      })
    } finally {
      this.setData({
        loading: false,
        refreshing: false
      })
    }
  },

  // 切换标签
  onTabChange(e) {
    const index = e.currentTarget.dataset.index
    this.setData({
      currentTab: index,
      orders: [],
      page: 1,
      noMore: false
    })
    this.loadOrders(true)
  },

  // 下拉刷新
  onRefresh() {
    this.setData({ refreshing: true })
    this.loadOrders(true)
  },

  // 上拉加载更多
  onLoadMore() {
    if (!this.data.noMore) {
      this.loadOrders()
    }
  },

  // 跳转到订单详情
  navigateToDetail(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/user/orders/detail?id=${id}`
    })
  },

  // 取消订单
  async cancelOrder(e) {
    const { id } = e.currentTarget.dataset
    try {
      await wx.showModal({
        title: '提示',
        content: '确定要取消该订单吗？'
      })

      // TODO: 调用后端API取消订单
      wx.showToast({
        title: '取消成功',
        icon: 'success'
      })
      this.loadOrders(true)
    } catch (error) {
      console.error('取消订单失败：', error)
    }
  },

  // 支付订单
  async payOrder(e) {
    const { id } = e.currentTarget.dataset
    try {
      // TODO: 调用后端API发起支付
      wx.showToast({
        title: '支付成功',
        icon: 'success'
      })
      this.loadOrders(true)
    } catch (error) {
      console.error('支付失败：', error)
    }
  },

  // 确认收货
  async confirmReceive(e) {
    const { id } = e.currentTarget.dataset
    try {
      await wx.showModal({
        title: '提示',
        content: '确认已收到商品吗？'
      })

      // TODO: 调用后端API确认收货
      wx.showToast({
        title: '确认成功',
        icon: 'success'
      })
      this.loadOrders(true)
    } catch (error) {
      console.error('确认收货失败：', error)
    }
  },

  // 删除订单
  async deleteOrder(e) {
    const { id } = e.currentTarget.dataset
    try {
      await wx.showModal({
        title: '提示',
        content: '确定要删除该订单吗？'
      })

      // TODO: 调用后端API删除订单
      wx.showToast({
        title: '删除成功',
        icon: 'success'
      })
      this.loadOrders(true)
    } catch (error) {
      console.error('删除订单失败：', error)
    }
  },

  // 再次购买
  buyAgain(e) {
    const { id } = e.currentTarget.dataset
    // TODO: 跳转到商品详情页或直接加入购物车
  },

  // 评价订单
  writeReview(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/user/orders/review?id=${id}`
    })
  },

  // 查看物流
  checkLogistics(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/user/orders/logistics?id=${id}`
    })
  },

  // 联系客服
  contactService() {
    // TODO: 实现客服联系功能
  },

  // 返回首页
  navigateToHome() {
    wx.switchTab({
      url: '/pages/index/index'
    })
  }
}) 