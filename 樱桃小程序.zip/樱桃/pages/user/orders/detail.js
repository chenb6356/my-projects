Page({
  data: {
    orderId: '',
    orderInfo: null,
    loading: true
  },

  onLoad(options) {
    if (options.id) {
      this.setData({
        orderId: options.id
      });
      this.loadOrderDetail();
    }
  },

  onPullDownRefresh() {
    this.loadOrderDetail();
  },

  // 加载订单详情
  async loadOrderDetail() {
    try {
      this.setData({ loading: true });
      // TODO: 调用后端API获取订单详情
      const orderInfo = await this.mockGetOrderDetail();
      this.setData({
        orderInfo,
        loading: false
      });
      wx.stopPullDownRefresh();
    } catch (error) {
      console.error('加载订单详情失败:', error);
      this.setData({ loading: false });
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      });
      wx.stopPullDownRefresh();
    }
  },

  // 复制订单号
  copyOrderNo() {
    const { orderInfo } = this.data;
    if (orderInfo && orderInfo.orderNo) {
      wx.setClipboardData({
        data: orderInfo.orderNo,
        success() {
          wx.showToast({
            title: '复制成功',
            icon: 'success'
          });
        }
      });
    }
  },

  // 查看物流
  viewLogistics() {
    const { orderId } = this.data;
    wx.navigateTo({
      url: `/pages/user/orders/logistics?id=${orderId}`
    });
  },

  // 取消订单
  async cancelOrder() {
    const { orderId } = this.data;
    wx.showModal({
      title: '提示',
      content: '确定要取消该订单吗？',
      async success(res) {
        if (res.confirm) {
          try {
            wx.showLoading({ title: '处理中' });
            // TODO: 调用后端API取消订单
            await new Promise(resolve => setTimeout(resolve, 1000));
            wx.hideLoading();
            wx.showToast({
              title: '取消成功',
              icon: 'success'
            });
            // 刷新订单详情
            this.loadOrderDetail();
          } catch (error) {
            console.error('取消订单失败:', error);
            wx.hideLoading();
            wx.showToast({
              title: '操作失败，请重试',
              icon: 'none'
            });
          }
        }
      }
    });
  },

  // 去支付
  async goPay() {
    const { orderId } = this.data;
    try {
      wx.showLoading({ title: '处理中' });
      // TODO: 调用后端API获取支付参数
      await new Promise(resolve => setTimeout(resolve, 1000));
      wx.hideLoading();
      // TODO: 调用支付API
      wx.showToast({
        title: '支付成功',
        icon: 'success'
      });
      // 刷新订单详情
      this.loadOrderDetail();
    } catch (error) {
      console.error('支付失败:', error);
      wx.hideLoading();
      wx.showToast({
        title: '支付失败，请重试',
        icon: 'none'
      });
    }
  },

  // 确认收货
  confirmReceipt() {
    const { orderId } = this.data;
    wx.showModal({
      title: '提示',
      content: '确认已收到商品吗？',
      async success(res) {
        if (res.confirm) {
          try {
            wx.showLoading({ title: '处理中' });
            // TODO: 调用后端API确认收货
            await new Promise(resolve => setTimeout(resolve, 1000));
            wx.hideLoading();
            wx.showToast({
              title: '确认成功',
              icon: 'success'
            });
            // 刷新订单详情
            this.loadOrderDetail();
          } catch (error) {
            console.error('确认收货失败:', error);
            wx.hideLoading();
            wx.showToast({
              title: '操作失败，请重试',
              icon: 'none'
            });
          }
        }
      }
    });
  },

  // 删除订单
  deleteOrder() {
    const { orderId } = this.data;
    wx.showModal({
      title: '提示',
      content: '确定要删除该订单吗？',
      async success(res) {
        if (res.confirm) {
          try {
            wx.showLoading({ title: '处理中' });
            // TODO: 调用后端API删除订单
            await new Promise(resolve => setTimeout(resolve, 1000));
            wx.hideLoading();
            wx.showToast({
              title: '删除成功',
              icon: 'success'
            });
            // 返回上一页
            wx.navigateBack();
          } catch (error) {
            console.error('删除订单失败:', error);
            wx.hideLoading();
            wx.showToast({
              title: '操作失败，请重试',
              icon: 'none'
            });
          }
        }
      }
    });
  },

  // 去评价
  goReview() {
    const { orderId } = this.data;
    wx.navigateTo({
      url: `/pages/user/orders/review?id=${orderId}`
    });
  },

  // 再次购买
  buyAgain() {
    const { orderInfo } = this.data;
    if (orderInfo && orderInfo.goods && orderInfo.goods.length > 0) {
      // TODO: 处理再次购买逻辑
      wx.showToast({
        title: '已加入购物车',
        icon: 'success'
      });
    }
  },

  // 联系客服
  contactService() {
    // TODO: 实现客服联系功能
  },

  // Mock数据 - 实际开发时替换为真实API调用
  mockGetOrderDetail() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          orderNo: 'ORDER202403150001',
          status: 'PENDING_PAYMENT',
          statusText: '待付款',
          statusDesc: '请在23小时59分钟内完成支付',
          address: {
            name: '张三',
            phone: '13800138000',
            address: '浙江省杭州市西湖区西溪路100号'
          },
          goods: [{
            id: 1,
            image: '/images/goods/cherry1.jpg',
            name: '樱桃大礼包',
            spec: '500g/盒',
            price: 99.00,
            count: 2
          }],
          totalPrice: 198.00,
          shippingFee: 10.00,
          discount: 20.00,
          finalAmount: 188.00,
          createTime: '2024-03-15 10:00:00',
          payTime: '',
          shipTime: '',
          completeTime: '',
          cancelTime: ''
        });
      }, 1000);
    });
  }
}); 