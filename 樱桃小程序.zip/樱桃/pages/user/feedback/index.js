const app = getApp();

Page({
  data: {
    feedbackTypes: [
      { label: '功能异常', value: 'bug' },
      { label: '体验问题', value: 'experience' },
      { label: '产品建议', value: 'suggestion' },
      { label: '其他问题', value: 'other' }
    ],
    selectedType: '',
    content: '',
    images: [],
    contact: '',
    canSubmit: false,
    showSuccessPopup: false,
    primaryColor: app.globalData.theme.primaryColor,
    primaryColorLight: app.globalData.theme.primaryColor + '19' // 主题色带 10% 透明度
  },

  onLoad() {
    // 设置默认选中的反馈类型
    this.setData({
      selectedType: this.data.feedbackTypes[0].value
    });
  },

  // 选择反馈类型
  selectType(e) {
    const { type } = e.currentTarget.dataset;
    this.setData({
      selectedType: type
    });
    this.checkCanSubmit();
  },

  // 输入反馈内容
  onContentInput(e) {
    const { value } = e.detail;
    this.setData({
      content: value
    });
    this.checkCanSubmit();
  },

  // 选择图片
  async chooseImage() {
    try {
      const res = await wx.chooseMedia({
        count: 4 - this.data.images.length,
        mediaType: ['image'],
        sourceType: ['album', 'camera'],
        sizeType: ['compressed']
      });

      const images = this.data.images.concat(res.tempFiles.map(file => file.tempFilePath));
      this.setData({ images });
    } catch (error) {
      console.error('选择图片失败:', error);
    }
  },

  // 预览图片
  previewImage(e) {
    const { url } = e.currentTarget.dataset;
    wx.previewImage({
      urls: this.data.images,
      current: url
    });
  },

  // 删除图片
  deleteImage(e) {
    const { index } = e.currentTarget.dataset;
    const images = this.data.images.filter((_, i) => i !== index);
    this.setData({ images });
  },

  // 检查是否可以提交
  checkCanSubmit() {
    const { selectedType, content } = this.data;
    const canSubmit = selectedType && content.trim().length >= 10;
    this.setData({ canSubmit });
  },

  // 提交表单
  async submitForm(e) {
    if (!this.data.canSubmit) return;

    const { content, contact } = e.detail.value;
    const { selectedType, images } = this.data;

    try {
      wx.showLoading({ title: '提交中...' });

      // 上传图片
      const uploadedImages = [];
      if (images.length > 0) {
        for (const tempFilePath of images) {
          // TODO: 调用后端API上传图片
          const imageUrl = await this.mockUploadImage(tempFilePath);
          uploadedImages.push(imageUrl);
        }
      }

      // 提交反馈
      const data = {
        type: selectedType,
        content: content.trim(),
        images: uploadedImages,
        contact: contact.trim()
      };

      // TODO: 调用后端API提交反馈
      await this.mockSubmitFeedback(data);

      wx.hideLoading();
      this.setData({ showSuccessPopup: true });
    } catch (error) {
      console.error('提交反馈失败:', error);
      wx.hideLoading();
      wx.showToast({
        title: '提交失败，请重试',
        icon: 'none'
      });
    }
  },

  // 关闭成功弹窗
  closeSuccessPopup() {
    this.setData({ showSuccessPopup: false });
    // 返回上一页
    wx.navigateBack();
  },

  // Mock数据 - 实际开发时替换为真实API调用
  mockUploadImage(tempFilePath) {
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log('上传图片:', tempFilePath);
        resolve('https://example.com/image.jpg');
      }, 500);
    });
  },

  mockSubmitFeedback(data) {
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log('提交反馈:', data);
        resolve();
      }, 500);
    });
  }
}); 