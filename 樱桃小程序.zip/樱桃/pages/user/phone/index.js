const app = getApp()

Page({
  data: {
    phone: '',
    code: '',
    countdown: 0,
    canSendCode: false,
    canSubmit: false,
    loading: false,
    loadingText: '',
    primaryColor: app.globalData.theme.primaryColor
  },

  onLoad() {
    // 检查是否已绑定手机号
    this.checkPhoneBinding()
  },

  // 检查手机号绑定状态
  async checkPhoneBinding() {
    try {
      const userInfo = await this.mockGetUserInfo()
      if (userInfo.phone) {
        wx.showModal({
          title: '提示',
          content: '您已绑定手机号',
          showCancel: false,
          success: () => {
            wx.navigateBack()
          }
        })
      }
    } catch (error) {
      console.error('获取用户信息失败:', error)
    }
  },

  // 手机号输入
  onPhoneInput(e) {
    const phone = e.detail.value
    this.setData({
      phone,
      canSendCode: this.isValidPhone(phone)
    })
    this.checkCanSubmit()
  },

  // 清除手机号
  clearPhone() {
    this.setData({
      phone: '',
      canSendCode: false
    })
    this.checkCanSubmit()
  },

  // 验证码输入
  onCodeInput(e) {
    const code = e.detail.value
    this.setData({ code })
    this.checkCanSubmit()
  },

  // 发送验证码
  async sendCode() {
    if (!this.data.canSendCode || this.data.countdown > 0) return

    this.setData({
      loading: true,
      loadingText: '发送中...'
    })

    try {
      await this.mockSendCode(this.data.phone)
      
      // 开始倒计时
      this.setData({
        countdown: 60,
        loading: false
      })
      
      this.startCountdown()
      
      wx.showToast({
        title: '验证码已发送',
        icon: 'success'
      })
    } catch (error) {
      console.error('发送验证码失败:', error)
      wx.showToast({
        title: '发送失败，请重试',
        icon: 'none'
      })
      this.setData({ loading: false })
    }
  },

  // 开始倒计时
  startCountdown() {
    if (this.countdownTimer) {
      clearInterval(this.countdownTimer)
    }

    this.countdownTimer = setInterval(() => {
      if (this.data.countdown <= 1) {
        clearInterval(this.countdownTimer)
        this.setData({
          countdown: 0,
          canSendCode: this.isValidPhone(this.data.phone)
        })
      } else {
        this.setData({
          countdown: this.data.countdown - 1
        })
      }
    }, 1000)
  },

  // 提交表单
  async submitForm() {
    if (!this.data.canSubmit) return

    this.setData({
      loading: true,
      loadingText: '绑定中...'
    })

    try {
      await this.mockBindPhone(this.data.phone, this.data.code)
      
      wx.showToast({
        title: '绑定成功',
        icon: 'success'
      })

      // 延迟返回上一页
      setTimeout(() => {
        wx.navigateBack()
      }, 1500)
    } catch (error) {
      console.error('绑定手机号失败:', error)
      wx.showToast({
        title: error.message || '绑定失败，请重试',
        icon: 'none'
      })
      this.setData({ loading: false })
    }
  },

  // 跳转到隐私政策
  navigateToPrivacy() {
    wx.navigateTo({
      url: '/pages/user/privacy/index'
    })
  },

  // 检查是否可以提交
  checkCanSubmit() {
    const canSubmit = this.isValidPhone(this.data.phone) && 
                     this.data.code.length === 6
    this.setData({ canSubmit })
  },

  // 验证手机号格式
  isValidPhone(phone) {
    return /^1[3-9]\d{9}$/.test(phone)
  },

  // 页面卸载时清除定时器
  onUnload() {
    if (this.countdownTimer) {
      clearInterval(this.countdownTimer)
    }
  },

  // Mock API: 获取用户信息
  mockGetUserInfo() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          phone: '' // 模拟未绑定手机号
        })
      }, 500)
    })
  },

  // Mock API: 发送验证码
  mockSendCode(phone) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (Math.random() > 0.1) { // 90%成功率
          resolve()
        } else {
          reject(new Error('发送验证码失败'))
        }
      }, 1000)
    })
  },

  // Mock API: 绑定手机号
  mockBindPhone(phone, code) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (code === '123456') { // 模拟正确的验证码
          resolve()
        } else {
          reject(new Error('验证码错误'))
        }
      }, 1500)
    })
  }
}) 