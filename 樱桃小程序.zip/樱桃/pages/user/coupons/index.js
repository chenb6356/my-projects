const app = getApp();

Page({
  data: {
    currentTab: 'available', // available, used, expired
    coupons: [],
    page: 1,
    pageSize: 10,
    loading: false,
    refreshing: false,
    noMore: false,
    showRulesPopup: false,
    currentCoupon: null,
    primaryColor: app.globalData.theme.primaryColor
  },

  onLoad() {
    this.loadCoupons();
  },

  onShow() {
    // 如果从商品详情页返回，可能需要刷新列表
    if (app.globalData.needRefreshCoupons) {
      this.refreshCoupons();
      app.globalData.needRefreshCoupons = false;
    }
  },

  // 切换标签
  onTabChange(e) {
    const tab = e.currentTarget.dataset.tab;
    if (tab === this.data.currentTab) return;
    
    this.setData({
      currentTab: tab,
      coupons: [],
      page: 1,
      noMore: false
    });
    this.loadCoupons();
  },

  // 加载优惠券列表
  async loadCoupons() {
    if (this.data.loading || this.data.noMore) return;

    try {
      this.setData({ loading: true });

      // TODO: 调用后端API获取优惠券列表
      const coupons = await this.mockGetCoupons();
      
      this.setData({
        coupons: [...this.data.coupons, ...coupons],
        page: this.data.page + 1,
        noMore: coupons.length < this.data.pageSize,
        loading: false
      });
    } catch (error) {
      console.error('加载优惠券列表失败:', error);
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      });
      this.setData({ loading: false });
    }
  },

  // 刷新优惠券列表
  async refreshCoupons() {
    try {
      this.setData({ refreshing: true });

      // TODO: 调用后端API获取优惠券列表
      const coupons = await this.mockGetCoupons(true);
      
      this.setData({
        coupons,
        page: 2,
        noMore: coupons.length < this.data.pageSize,
        refreshing: false
      });
    } catch (error) {
      console.error('刷新优惠券列表失败:', error);
      wx.showToast({
        title: '刷新失败，请重试',
        icon: 'none'
      });
      this.setData({ refreshing: false });
    }
  },

  // 加载更多
  onLoadMore() {
    this.loadCoupons();
  },

  // 下拉刷新
  onRefresh() {
    this.refreshCoupons();
  },

  // 显示使用规则
  showRules(e) {
    const { id } = e.currentTarget.dataset;
    const coupon = this.data.coupons.find(item => item.id === id);
    this.setData({
      showRulesPopup: true,
      currentCoupon: coupon
    });
  },

  // 关闭使用规则弹窗
  closeRulesPopup() {
    this.setData({
      showRulesPopup: false,
      currentCoupon: null
    });
  },

  // 立即使用
  useNow(e) {
    const { id } = e.currentTarget.dataset;
    const coupon = this.data.coupons.find(item => item.id === id);
    // 跳转到商品列表页
    wx.switchTab({
      url: '/pages/product/list'
    });
  },

  // 去领券
  getCoupons() {
    // TODO: 跳转到领券中心
    wx.showToast({
      title: '即将上线',
      icon: 'none'
    });
  },

  // Mock数据 - 实际开发时替换为真实API调用
  mockGetCoupons(isRefresh = false) {
    return new Promise((resolve) => {
      setTimeout(() => {
        const coupons = Array.from({ length: this.data.pageSize }, (_, i) => ({
          id: isRefresh ? `new_${i}` : `${this.data.page}_${i}`,
          name: '新人专享券',
          description: '全场商品可用',
          amount: Math.floor(Math.random() * 50) + 10,
          minAmount: Math.floor(Math.random() * 100) + 50,
          startTime: '2024-03-15',
          endTime: '2024-04-15',
          status: this.data.currentTab,
          rules: [
            '仅限购买樱桃类商品使用',
            '每个订单限使用一张优惠券',
            '不可与其他优惠活动同时使用',
            '优惠券不可转让',
            '优惠券不可兑换现金',
            '优惠券不可找零'
          ]
        }));
        resolve(coupons);
      }, 500);
    });
  }
}); 