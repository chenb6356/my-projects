Page({
  data: {
    // 页面数据
  },

  onLoad() {
    // 页面加载时的处理
  },

  // 分享到聊天
  onShareAppMessage() {
    return {
      title: '上王村樱桃 - 用户协议',
      path: '/pages/user/terms/index'
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '上王村樱桃 - 用户协议'
    }
  }
}) 