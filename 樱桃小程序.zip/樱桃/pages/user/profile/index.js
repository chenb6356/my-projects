const app = getApp();

Page({
  data: {
    userInfo: null,
    primaryColor: app.globalData.theme.primaryColor,
    showNicknamePopup: false,
    showGenderPopup: false,
    showBirthdayPopup: false,
    newNickname: '',
    years: [],
    months: [],
    days: [],
    birthdayArray: [0, 0, 0]
  },

  onLoad() {
    this.loadUserInfo();
    this.initBirthdayPicker();
  },

  onShow() {
    // 每次显示页面时重新加载用户信息
    this.loadUserInfo();
  },

  // 加载用户信息
  async loadUserInfo() {
    try {
      // TODO: 调用后端API获取用户信息
      const userInfo = await this.mockGetUserInfo();
      this.setData({ userInfo });
    } catch (error) {
      console.error('加载用户信息失败:', error);
      wx.showToast({
        title: '加载失败',
        icon: 'none'
      });
    }
  },

  // 初始化生日选择器
  initBirthdayPicker() {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let i = currentYear - 100; i <= currentYear; i++) {
      years.push(i);
    }

    const months = [];
    for (let i = 1; i <= 12; i++) {
      months.push(i);
    }

    const days = [];
    for (let i = 1; i <= 31; i++) {
      days.push(i);
    }

    this.setData({ years, months, days });
  },

  // 修改头像
  async changeAvatar() {
    try {
      const res = await wx.chooseMedia({
        count: 1,
        mediaType: ['image'],
        sourceType: ['album', 'camera'],
        sizeType: ['compressed']
      });

      wx.showLoading({ title: '上传中...' });

      // TODO: 调用后端API上传头像
      const avatarUrl = await this.mockUploadAvatar(res.tempFiles[0].tempFilePath);

      // 更新用户信息
      const userInfo = { ...this.data.userInfo, avatarUrl };
      this.setData({ userInfo });

      wx.hideLoading();
      wx.showToast({
        title: '修改成功',
        icon: 'success'
      });
    } catch (error) {
      console.error('修改头像失败:', error);
      wx.hideLoading();
      wx.showToast({
        title: '修改失败',
        icon: 'none'
      });
    }
  },

  // 修改昵称
  changeNickname() {
    this.setData({
      showNicknamePopup: true,
      newNickname: this.data.userInfo.nickName || ''
    });
  },

  onNicknameInput(e) {
    this.setData({
      newNickname: e.detail.value
    });
  },

  closeNicknamePopup() {
    this.setData({
      showNicknamePopup: false,
      newNickname: ''
    });
  },

  async confirmNickname() {
    const { newNickname } = this.data;
    if (!newNickname.trim()) return;

    try {
      wx.showLoading({ title: '保存中...' });

      // TODO: 调用后端API更新昵称
      await this.mockUpdateUserInfo({ nickName: newNickname });

      // 更新用户信息
      const userInfo = { ...this.data.userInfo, nickName: newNickname };
      this.setData({
        userInfo,
        showNicknamePopup: false,
        newNickname: ''
      });

      wx.hideLoading();
      wx.showToast({
        title: '修改成功',
        icon: 'success'
      });
    } catch (error) {
      console.error('修改昵称失败:', error);
      wx.hideLoading();
      wx.showToast({
        title: '修改失败',
        icon: 'none'
      });
    }
  },

  // 修改性别
  changeGender() {
    this.setData({
      showGenderPopup: true
    });
  },

  closeGenderPopup() {
    this.setData({
      showGenderPopup: false
    });
  },

  async selectGender(e) {
    const gender = parseInt(e.currentTarget.dataset.gender);
    try {
      wx.showLoading({ title: '保存中...' });

      // TODO: 调用后端API更新性别
      await this.mockUpdateUserInfo({ gender });

      // 更新用户信息
      const userInfo = { ...this.data.userInfo, gender };
      this.setData({
        userInfo,
        showGenderPopup: false
      });

      wx.hideLoading();
      wx.showToast({
        title: '修改成功',
        icon: 'success'
      });
    } catch (error) {
      console.error('修改性别失败:', error);
      wx.hideLoading();
      wx.showToast({
        title: '修改失败',
        icon: 'none'
      });
    }
  },

  // 修改生日
  changeBirthday() {
    this.setData({
      showBirthdayPopup: true
    });
  },

  closeBirthdayPopup() {
    this.setData({
      showBirthdayPopup: false
    });
  },

  onBirthdayChange(e) {
    this.setData({
      birthdayArray: e.detail.value
    });
  },

  async confirmBirthday() {
    const { years, months, days, birthdayArray } = this.data;
    const birthday = `${years[birthdayArray[0]]}-${String(months[birthdayArray[1]]).padStart(2, '0')}-${String(days[birthdayArray[2]]).padStart(2, '0')}`;

    try {
      wx.showLoading({ title: '保存中...' });

      // TODO: 调用后端API更新生日
      await this.mockUpdateUserInfo({ birthday });

      // 更新用户信息
      const userInfo = { ...this.data.userInfo, birthday };
      this.setData({
        userInfo,
        showBirthdayPopup: false
      });

      wx.hideLoading();
      wx.showToast({
        title: '修改成功',
        icon: 'success'
      });
    } catch (error) {
      console.error('修改生日失败:', error);
      wx.hideLoading();
      wx.showToast({
        title: '修改失败',
        icon: 'none'
      });
    }
  },

  // 修改手机号
  changePhone() {
    wx.navigateTo({
      url: '/pages/user/phone/index'
    });
  },

  // 修改密码
  changePassword() {
    wx.navigateTo({
      url: '/pages/user/password/index'
    });
  },

  // 账号管理
  manageAccount() {
    wx.navigateTo({
      url: '/pages/user/account/index'
    });
  },

  // 退出登录
  logout() {
    wx.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          // TODO: 调用后端API退出登录
          app.globalData.userInfo = null;
          wx.reLaunch({
            url: '/pages/user/index'
          });
        }
      }
    });
  },

  // Mock数据 - 实际开发时替换为真实API调用
  mockGetUserInfo() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          avatarUrl: '/assets/icons/default-avatar.png',
          nickName: '张三',
          gender: 1,
          birthday: '1990-01-01',
          phone: '13800138000'
        });
      }, 500);
    });
  },

  mockUploadAvatar(tempFilePath) {
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log('上传头像:', tempFilePath);
        resolve('/assets/icons/default-avatar.png');
      }, 500);
    });
  },

  mockUpdateUserInfo(data) {
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log('更新用户信息:', data);
        resolve();
      }, 500);
    });
  }
});
 
Page({
  data: {
    userInfo: null,
    primaryColor: app.globalData.theme.primaryColor,
    showNicknamePopup: false,
    showGenderPopup: false,
    showBirthdayPopup: false,
    newNickname: '',
    years: [],
    months: [],
    days: [],
    birthdayArray: [0, 0, 0]
  },

  onLoad() {
    this.loadUserInfo();
    this.initBirthdayPicker();
  },

  onShow() {
    // 每次显示页面时重新加载用户信息
    this.loadUserInfo();
  },

  // 加载用户信息
  async loadUserInfo() {
    try {
      // TODO: 调用后端API获取用户信息
      const userInfo = await this.mockGetUserInfo();
      this.setData({ userInfo });
    } catch (error) {
      console.error('加载用户信息失败:', error);
      wx.showToast({
        title: '加载失败',
        icon: 'none'
      });
    }
  },

  // 初始化生日选择器
  initBirthdayPicker() {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let i = currentYear - 100; i <= currentYear; i++) {
      years.push(i);
    }

    const months = [];
    for (let i = 1; i <= 12; i++) {
      months.push(i);
    }

    const days = [];
    for (let i = 1; i <= 31; i++) {
      days.push(i);
    }

    this.setData({ years, months, days });
  },

  // 修改头像
  async changeAvatar() {
    try {
      const res = await wx.chooseMedia({
        count: 1,
        mediaType: ['image'],
        sourceType: ['album', 'camera'],
        sizeType: ['compressed']
      });

      wx.showLoading({ title: '上传中...' });

      // TODO: 调用后端API上传头像
      const avatarUrl = await this.mockUploadAvatar(res.tempFiles[0].tempFilePath);

      // 更新用户信息
      const userInfo = { ...this.data.userInfo, avatarUrl };
      this.setData({ userInfo });

      wx.hideLoading();
      wx.showToast({
        title: '修改成功',
        icon: 'success'
      });
    } catch (error) {
      console.error('修改头像失败:', error);
      wx.hideLoading();
      wx.showToast({
        title: '修改失败',
        icon: 'none'
      });
    }
  },

  // 修改昵称
  changeNickname() {
    this.setData({
      showNicknamePopup: true,
      newNickname: this.data.userInfo.nickName || ''
    });
  },

  onNicknameInput(e) {
    this.setData({
      newNickname: e.detail.value
    });
  },

  closeNicknamePopup() {
    this.setData({
      showNicknamePopup: false,
      newNickname: ''
    });
  },

  async confirmNickname() {
    const { newNickname } = this.data;
    if (!newNickname.trim()) return;

    try {
      wx.showLoading({ title: '保存中...' });

      // TODO: 调用后端API更新昵称
      await this.mockUpdateUserInfo({ nickName: newNickname });

      // 更新用户信息
      const userInfo = { ...this.data.userInfo, nickName: newNickname };
      this.setData({
        userInfo,
        showNicknamePopup: false,
        newNickname: ''
      });

      wx.hideLoading();
      wx.showToast({
        title: '修改成功',
        icon: 'success'
      });
    } catch (error) {
      console.error('修改昵称失败:', error);
      wx.hideLoading();
      wx.showToast({
        title: '修改失败',
        icon: 'none'
      });
    }
  },

  // 修改性别
  changeGender() {
    this.setData({
      showGenderPopup: true
    });
  },

  closeGenderPopup() {
    this.setData({
      showGenderPopup: false
    });
  },

  async selectGender(e) {
    const gender = parseInt(e.currentTarget.dataset.gender);
    try {
      wx.showLoading({ title: '保存中...' });

      // TODO: 调用后端API更新性别
      await this.mockUpdateUserInfo({ gender });

      // 更新用户信息
      const userInfo = { ...this.data.userInfo, gender };
      this.setData({
        userInfo,
        showGenderPopup: false
      });

      wx.hideLoading();
      wx.showToast({
        title: '修改成功',
        icon: 'success'
      });
    } catch (error) {
      console.error('修改性别失败:', error);
      wx.hideLoading();
      wx.showToast({
        title: '修改失败',
        icon: 'none'
      });
    }
  },

  // 修改生日
  changeBirthday() {
    this.setData({
      showBirthdayPopup: true
    });
  },

  closeBirthdayPopup() {
    this.setData({
      showBirthdayPopup: false
    });
  },

  onBirthdayChange(e) {
    this.setData({
      birthdayArray: e.detail.value
    });
  },

  async confirmBirthday() {
    const { years, months, days, birthdayArray } = this.data;
    const birthday = `${years[birthdayArray[0]]}-${String(months[birthdayArray[1]]).padStart(2, '0')}-${String(days[birthdayArray[2]]).padStart(2, '0')}`;

    try {
      wx.showLoading({ title: '保存中...' });

      // TODO: 调用后端API更新生日
      await this.mockUpdateUserInfo({ birthday });

      // 更新用户信息
      const userInfo = { ...this.data.userInfo, birthday };
      this.setData({
        userInfo,
        showBirthdayPopup: false
      });

      wx.hideLoading();
      wx.showToast({
        title: '修改成功',
        icon: 'success'
      });
    } catch (error) {
      console.error('修改生日失败:', error);
      wx.hideLoading();
      wx.showToast({
        title: '修改失败',
        icon: 'none'
      });
    }
  },

  // 修改手机号
  changePhone() {
    wx.navigateTo({
      url: '/pages/user/phone/index'
    });
  },

  // 修改密码
  changePassword() {
    wx.navigateTo({
      url: '/pages/user/password/index'
    });
  },

  // 账号管理
  manageAccount() {
    wx.navigateTo({
      url: '/pages/user/account/index'
    });
  },

  // 退出登录
  logout() {
    wx.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          // TODO: 调用后端API退出登录
          app.globalData.userInfo = null;
          wx.reLaunch({
            url: '/pages/user/index'
          });
        }
      }
    });
  },

  // Mock数据 - 实际开发时替换为真实API调用
  mockGetUserInfo() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          avatarUrl: '/assets/icons/default-avatar.png',
          nickName: '张三',
          gender: 1,
          birthday: '1990-01-01',
          phone: '13800138000'
        });
      }, 500);
    });
  },

  mockUploadAvatar(tempFilePath) {
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log('上传头像:', tempFilePath);
        resolve('/assets/icons/default-avatar.png');
      }, 500);
    });
  },

  mockUpdateUserInfo(data) {
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log('更新用户信息:', data);
        resolve();
      }, 500);
    });
  }
}); 
 