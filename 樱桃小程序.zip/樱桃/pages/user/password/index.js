const app = getApp()

Page({
  data: {
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
    showOldPassword: false,
    showNewPassword: false,
    showConfirmPassword: false,
    canSubmit: false,
    loading: false,
    loadingText: '',
    primaryColor: app.globalData.theme.primaryColor
  },

  // 原密码输入
  onOldPasswordInput(e) {
    const oldPassword = e.detail.value
    this.setData({ oldPassword })
    this.checkCanSubmit()
  },

  // 新密码输入
  onNewPasswordInput(e) {
    const newPassword = e.detail.value
    this.setData({ newPassword })
    this.checkCanSubmit()
  },

  // 确认密码输入
  onConfirmPasswordInput(e) {
    const confirmPassword = e.detail.value
    this.setData({ confirmPassword })
    this.checkCanSubmit()
  },

  // 切换原密码可见性
  toggleOldPassword() {
    this.setData({
      showOldPassword: !this.data.showOldPassword
    })
  },

  // 切换新密码可见性
  toggleNewPassword() {
    this.setData({
      showNewPassword: !this.data.showNewPassword
    })
  },

  // 切换确认密码可见性
  toggleConfirmPassword() {
    this.setData({
      showConfirmPassword: !this.data.showConfirmPassword
    })
  },

  // 检查是否可以提交
  checkCanSubmit() {
    const { oldPassword, newPassword, confirmPassword } = this.data
    const canSubmit = oldPassword.length > 0 && 
                     this.isValidPassword(newPassword) &&
                     newPassword === confirmPassword
    this.setData({ canSubmit })
  },

  // 验证密码格式
  isValidPassword(password) {
    // 8-20位，必须包含字母和数字
    return /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,20}$/.test(password)
  },

  // 提交表单
  async submitForm() {
    if (!this.data.canSubmit) return

    // 验证新旧密码不能相同
    if (this.data.oldPassword === this.data.newPassword) {
      wx.showToast({
        title: '新密码不能与原密码相同',
        icon: 'none'
      })
      return
    }

    this.setData({
      loading: true,
      loadingText: '修改中...'
    })

    try {
      await this.mockChangePassword(
        this.data.oldPassword,
        this.data.newPassword
      )
      
      wx.showToast({
        title: '修改成功',
        icon: 'success'
      })

      // 延迟返回上一页
      setTimeout(() => {
        wx.navigateBack()
      }, 1500)
    } catch (error) {
      console.error('修改密码失败:', error)
      wx.showToast({
        title: error.message || '修改失败，请重试',
        icon: 'none'
      })
      this.setData({ loading: false })
    }
  },

  // 跳转到找回密码页面
  navigateToReset() {
    wx.navigateTo({
      url: '/pages/user/password/reset/index'
    })
  },

  // Mock API: 修改密码
  mockChangePassword(oldPassword, newPassword) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (oldPassword === '123456') { // 模拟正确的原密码
          resolve()
        } else {
          reject(new Error('原密码错误'))
        }
      }, 1500)
    })
  }
}) 