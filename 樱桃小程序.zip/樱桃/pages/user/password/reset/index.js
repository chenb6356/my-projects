Page({
  data: {
    phone: '',
    code: '',
    password: '',
    confirmPassword: '',
    showPassword: false,
    showConfirmPassword: false,
    countdown: 0,
    loading: false,
    canSubmit: false
  },

  onLoad() {
    // 页面加载时的初始化
  },

  // 手机号输入处理
  onPhoneInput(e) {
    const phone = e.detail.value;
    this.setData({ phone });
    this.checkCanSubmit();
  },

  // 清除手机号
  clearPhone() {
    this.setData({ phone: '' });
    this.checkCanSubmit();
  },

  // 验证码输入处理
  onCodeInput(e) {
    const code = e.detail.value;
    this.setData({ code });
    this.checkCanSubmit();
  },

  // 密码输入处理
  onPasswordInput(e) {
    const password = e.detail.value;
    this.setData({ password });
    this.checkCanSubmit();
  },

  // 确认密码输入处理
  onConfirmPasswordInput(e) {
    const confirmPassword = e.detail.value;
    this.setData({ confirmPassword });
    this.checkCanSubmit();
  },

  // 切换密码可见性
  togglePasswordVisibility() {
    this.setData({
      showPassword: !this.data.showPassword
    });
  },

  // 切换确认密码可见性
  toggleConfirmPasswordVisibility() {
    this.setData({
      showConfirmPassword: !this.data.showConfirmPassword
    });
  },

  // 发送验证码
  async sendCode() {
    if (this.data.countdown > 0 || !this.isValidPhone(this.data.phone)) {
      return;
    }

    this.setData({ loading: true });
    try {
      await this.mockSendCode(this.data.phone);
      this.startCountdown();
      wx.showToast({
        title: '验证码已发送',
        icon: 'success'
      });
    } catch (error) {
      wx.showToast({
        title: error.message || '发送失败',
        icon: 'error'
      });
    } finally {
      this.setData({ loading: false });
    }
  },

  // 开始倒计时
  startCountdown() {
    this.setData({ countdown: 60 });
    const timer = setInterval(() => {
      if (this.data.countdown <= 1) {
        clearInterval(timer);
      }
      this.setData({
        countdown: this.data.countdown - 1
      });
    }, 1000);
  },

  // 提交表单
  async submitForm() {
    if (!this.checkFormValid()) {
      return;
    }

    this.setData({ loading: true });
    try {
      await this.mockResetPassword({
        phone: this.data.phone,
        code: this.data.code,
        password: this.data.password
      });

      wx.showToast({
        title: '密码重置成功',
        icon: 'success'
      });

      // 延迟返回，让用户看到成功提示
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    } catch (error) {
      wx.showToast({
        title: error.message || '重置失败',
        icon: 'error'
      });
    } finally {
      this.setData({ loading: false });
    }
  },

  // 检查是否可以提交
  checkCanSubmit() {
    const { phone, code, password, confirmPassword } = this.data;
    const canSubmit = this.isValidPhone(phone) &&
      code.length === 6 &&
      this.isValidPassword(password) &&
      password === confirmPassword;
    
    this.setData({ canSubmit });
  },

  // 检查表单是否有效
  checkFormValid() {
    const { phone, code, password, confirmPassword } = this.data;

    if (!this.isValidPhone(phone)) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none'
      });
      return false;
    }

    if (code.length !== 6) {
      wx.showToast({
        title: '请输入6位验证码',
        icon: 'none'
      });
      return false;
    }

    if (!this.isValidPassword(password)) {
      wx.showToast({
        title: '密码需包含字母和数字，长度8-20位',
        icon: 'none'
      });
      return false;
    }

    if (password !== confirmPassword) {
      wx.showToast({
        title: '两次输入的密码不一致',
        icon: 'none'
      });
      return false;
    }

    return true;
  },

  // 验证手机号格式
  isValidPhone(phone) {
    return /^1[3-9]\d{9}$/.test(phone);
  },

  // 验证密码格式
  isValidPassword(password) {
    return /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,20}$/.test(password);
  },

  // 返回登录页
  navigateToLogin() {
    wx.navigateBack({
      delta: 2 // 返回两层，假设从登录页进入修改密码页再进入重置密码页
    });
  },

  // 模拟发送验证码
  mockSendCode(phone) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (this.isValidPhone(phone)) {
          resolve();
        } else {
          reject(new Error('手机号格式错误'));
        }
      }, 1000);
    });
  },

  // 模拟重置密码
  mockResetPassword({ phone, code, password }) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (code === '123456') { // 模拟验证码正确
          resolve();
        } else {
          reject(new Error('验证码错误'));
        }
      }, 1500);
    });
  }
}); 