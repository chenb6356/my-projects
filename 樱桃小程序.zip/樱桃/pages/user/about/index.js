const app = getApp()

Page({
  data: {
    version: '1.0.0',
    introduction: '上王村樱桃小程序是一个专注于展示和销售优质樱桃的平台。我们致力于为消费者提供新鲜、安全、优质的樱桃产品，让更多人品尝到来自上王村的美味樱桃。',
    email: 'business@shangwang.com',
    phone: '400-888-8888',
    wechat: 'shangwangcherry',
    icp: '浙ICP备XXXXXXXX号'
  },

  onLoad() {
    // 获取主题色
    this.setData({
      primaryColor: app.globalData.theme.primaryColor
    })
  },

  // 跳转到隐私政策
  navigateToPrivacy() {
    wx.navigateTo({
      url: '/pages/user/privacy/index'
    })
  },

  // 跳转到用户协议
  navigateToTerms() {
    wx.navigateTo({
      url: '/pages/user/terms/index'
    })
  },

  // 复制邮箱
  copyEmail() {
    wx.setClipboardData({
      data: this.data.email,
      success: () => {
        wx.showToast({
          title: '邮箱已复制',
          icon: 'success'
        })
      }
    })
  },

  // 拨打电话
  makePhoneCall() {
    wx.makePhoneCall({
      phoneNumber: this.data.phone,
      fail: () => {
        // 用户取消拨打电话
        console.log('用户取消拨打电话')
      }
    })
  },

  // 复制微信号
  copyWechat() {
    wx.setClipboardData({
      data: this.data.wechat,
      success: () => {
        wx.showToast({
          title: '微信号已复制',
          icon: 'success'
        })
      }
    })
  },

  // 分享
  onShareAppMessage() {
    return {
      title: '上王村樱桃 - 品质樱桃的优选',
      path: '/pages/index/index',
      imageUrl: '/assets/images/share-cover.png'
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '上王村樱桃 - 品质樱桃的优选',
      query: '',
      imageUrl: '/assets/images/share-cover.png'
    }
  }
}) 