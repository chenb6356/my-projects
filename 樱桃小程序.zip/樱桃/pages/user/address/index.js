const app = getApp();

Page({
  data: {
    addresses: [],
    isFromOrder: false, // 是否从订单页面进入
    primaryColor: app.globalData.theme.primaryColor
  },

  onLoad(options) {
    // 判断是否从订单页面进入
    if (options.from === 'order') {
      this.setData({ isFromOrder: true });
    }
    this.loadAddresses();
  },

  onShow() {
    // 如果从新增/编辑页面返回，刷新列表
    if (app.globalData.needRefreshAddress) {
      this.loadAddresses();
      app.globalData.needRefreshAddress = false;
    }
  },

  // 加载地址列表
  async loadAddresses() {
    try {
      wx.showLoading({ title: '加载中...' });

      // TODO: 调用后端API获取地址列表
      const addresses = await this.mockGetAddresses();
      
      this.setData({ addresses });
    } catch (error) {
      console.error('加载地址列表失败:', error);
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  },

  // 选择地址
  selectAddress(e) {
    if (!this.data.isFromOrder) return;

    const { id } = e.currentTarget.dataset;
    const address = this.data.addresses.find(item => item.id === id);
    
    // 返回订单页面并传递选中的地址
    const pages = getCurrentPages();
    const prevPage = pages[pages.length - 2];
    prevPage.setData({
      selectedAddress: address
    });
    wx.navigateBack();
  },

  // 设为默认地址
  async setDefault(e) {
    const { id } = e.currentTarget.dataset;
    try {
      wx.showLoading({ title: '设置中...' });

      // TODO: 调用后端API设置默认地址
      await new Promise(resolve => setTimeout(resolve, 500));

      // 更新列表
      const addresses = this.data.addresses.map(item => ({
        ...item,
        isDefault: item.id === id
      }));
      this.setData({ addresses });

      wx.showToast({
        title: '设置成功',
        icon: 'success'
      });
    } catch (error) {
      console.error('设置默认地址失败:', error);
      wx.showToast({
        title: '设置失败，请重试',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  },

  // 编辑地址
  editAddress(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/user/address/edit?id=${id}`
    });
  },

  // 删除地址
  deleteAddress(e) {
    const { id } = e.currentTarget.dataset;
    wx.showModal({
      title: '提示',
      content: '确定要删除该地址吗？',
      success: async (res) => {
        if (res.confirm) {
          try {
            wx.showLoading({ title: '删除中...' });

            // TODO: 调用后端API删除地址
            await new Promise(resolve => setTimeout(resolve, 500));

            // 更新列表
            const addresses = this.data.addresses.filter(item => item.id !== id);
            this.setData({ addresses });

            wx.showToast({
              title: '删除成功',
              icon: 'success'
            });
          } catch (error) {
            console.error('删除地址失败:', error);
            wx.showToast({
              title: '删除失败，请重试',
              icon: 'none'
            });
          } finally {
            wx.hideLoading();
          }
        }
      }
    });
  },

  // 新增地址
  addAddress() {
    wx.navigateTo({
      url: '/pages/user/address/edit'
    });
  },

  // Mock数据 - 实际开发时替换为真实API调用
  mockGetAddresses() {
    return new Promise((resolve) => {
      setTimeout(() => {
        const addresses = [
          {
            id: '1',
            name: '张三',
            phone: '13800138000',
            province: '浙江省',
            city: '杭州市',
            district: '西湖区',
            address: '文三路 123 号',
            isDefault: true
          },
          {
            id: '2',
            name: '李四',
            phone: '13900139000',
            province: '浙江省',
            city: '杭州市',
            district: '滨江区',
            address: '江南大道 456 号',
            isDefault: false
          }
        ];
        resolve(addresses);
      }, 500);
    });
  }
}); 