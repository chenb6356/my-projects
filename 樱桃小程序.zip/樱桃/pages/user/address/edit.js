const app = getApp();

Page({
  data: {
    id: '', // 地址ID，编辑时有值
    address: {
      name: '',
      phone: '',
      region: '',
      province: '',
      city: '',
      district: '',
      address: '',
      isDefault: false
    },
    showRegionPicker: false,
    provinces: [], // 省份列表
    cities: [], // 城市列表
    districts: [], // 区县列表
    regionValue: [0, 0, 0], // 地区选择器选中值
    primaryColor: app.globalData.theme.primaryColor
  },

  onLoad(options) {
    if (options.id) {
      this.setData({ id: options.id });
      this.loadAddressDetail();
    }
    this.loadRegionData();
  },

  // 加载地址详情
  async loadAddressDetail() {
    try {
      wx.showLoading({ title: '加载中...' });

      // TODO: 调用后端API获取地址详情
      const address = await this.mockGetAddressDetail();
      
      this.setData({ address });

      // 设置地区选择器的值
      if (address.province && address.city && address.district) {
        const provinceIndex = this.data.provinces.findIndex(item => item.name === address.province);
        if (provinceIndex > -1) {
          await this.loadCities(provinceIndex);
          const cityIndex = this.data.cities.findIndex(item => item.name === address.city);
          if (cityIndex > -1) {
            await this.loadDistricts(cityIndex);
            const districtIndex = this.data.districts.findIndex(item => item.name === address.district);
            if (districtIndex > -1) {
              this.setData({
                regionValue: [provinceIndex, cityIndex, districtIndex]
              });
            }
          }
        }
      }
    } catch (error) {
      console.error('加载地址详情失败:', error);
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  },

  // 加载地区数据
  async loadRegionData() {
    try {
      // TODO: 调用后端API获取地区数据
      const provinces = await this.mockGetProvinces();
      this.setData({ provinces });
      
      // 加载默认省份的城市列表
      await this.loadCities(0);
      // 加载默认城市的区县列表
      await this.loadDistricts(0);
    } catch (error) {
      console.error('加载地区数据失败:', error);
      wx.showToast({
        title: '加载地区数据失败',
        icon: 'none'
      });
    }
  },

  // 加载城市列表
  async loadCities(provinceIndex) {
    // TODO: 调用后端API获取城市列表
    const cities = await this.mockGetCities(this.data.provinces[provinceIndex].code);
    this.setData({ cities });
  },

  // 加载区县列表
  async loadDistricts(cityIndex) {
    // TODO: 调用后端API获取区县列表
    const districts = await this.mockGetDistricts(this.data.cities[cityIndex].code);
    this.setData({ districts });
  },

  // 打开地区选择器
  openRegionPicker() {
    this.setData({ showRegionPicker: true });
  },

  // 关闭地区选择器
  closeRegionPicker() {
    this.setData({ showRegionPicker: false });
  },

  // 地区选择器值改变
  async onRegionChange(e) {
    const { value } = e.detail;
    const [provinceIndex, cityIndex] = value;

    // 如果省份改变，重新加载城市列表
    if (provinceIndex !== this.data.regionValue[0]) {
      await this.loadCities(provinceIndex);
      await this.loadDistricts(0);
      this.setData({
        regionValue: [provinceIndex, 0, 0]
      });
      return;
    }

    // 如果城市改变，重新加载区县列表
    if (cityIndex !== this.data.regionValue[1]) {
      await this.loadDistricts(cityIndex);
      this.setData({
        regionValue: [provinceIndex, cityIndex, 0]
      });
      return;
    }

    this.setData({ regionValue: value });
  },

  // 确认地区选择
  confirmRegion() {
    const { provinces, cities, districts, regionValue } = this.data;
    const [provinceIndex, cityIndex, districtIndex] = regionValue;

    const province = provinces[provinceIndex].name;
    const city = cities[cityIndex].name;
    const district = districts[districtIndex].name;
    const region = `${province}${city}${district}`;

    this.setData({
      'address.region': region,
      'address.province': province,
      'address.city': city,
      'address.district': district,
      showRegionPicker: false
    });
  },

  // 设置默认地址
  onDefaultChange(e) {
    this.setData({
      'address.isDefault': e.detail.value
    });
  },

  // 提交表单
  async submitForm(e) {
    const { name, phone, address } = e.detail.value;
    const { region, province, city, district, isDefault } = this.data.address;

    // 表单验证
    if (!name) {
      return wx.showToast({
        title: '请输入收货人姓名',
        icon: 'none'
      });
    }
    if (!phone) {
      return wx.showToast({
        title: '请输入手机号码',
        icon: 'none'
      });
    }
    if (!/^1\d{10}$/.test(phone)) {
      return wx.showToast({
        title: '手机号码格式不正确',
        icon: 'none'
      });
    }
    if (!region) {
      return wx.showToast({
        title: '请选择所在地区',
        icon: 'none'
      });
    }
    if (!address) {
      return wx.showToast({
        title: '请输入详细地址',
        icon: 'none'
      });
    }

    try {
      wx.showLoading({ title: '保存中...' });

      const data = {
        name,
        phone,
        province,
        city,
        district,
        address,
        isDefault
      };

      if (this.data.id) {
        // TODO: 调用后端API更新地址
        await this.mockUpdateAddress(this.data.id, data);
      } else {
        // TODO: 调用后端API新增地址
        await this.mockAddAddress(data);
      }

      wx.showToast({
        title: '保存成功',
        icon: 'success'
      });

      // 标记需要刷新地址列表
      app.globalData.needRefreshAddress = true;

      // 返回上一页
      wx.navigateBack();
    } catch (error) {
      console.error('保存地址失败:', error);
      wx.showToast({
        title: '保存失败，请重试',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  },

  // Mock数据 - 实际开发时替换为真实API调用
  mockGetAddressDetail() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          name: '张三',
          phone: '13800138000',
          region: '浙江省杭州市西湖区',
          province: '浙江省',
          city: '杭州市',
          district: '西湖区',
          address: '文三路 123 号',
          isDefault: true
        });
      }, 500);
    });
  },

  mockGetProvinces() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve([
          { code: '330000', name: '浙江省' },
          { code: '320000', name: '江苏省' }
        ]);
      }, 500);
    });
  },

  mockGetCities(provinceCode) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (provinceCode === '330000') {
          resolve([
            { code: '330100', name: '杭州市' },
            { code: '330200', name: '宁波市' }
          ]);
        } else {
          resolve([
            { code: '320100', name: '南京市' },
            { code: '320200', name: '无锡市' }
          ]);
        }
      }, 500);
    });
  },

  mockGetDistricts(cityCode) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (cityCode === '330100') {
          resolve([
            { code: '330106', name: '西湖区' },
            { code: '330108', name: '滨江区' }
          ]);
        } else {
          resolve([
            { code: '330203', name: '海曙区' },
            { code: '330205', name: '江北区' }
          ]);
        }
      }, 500);
    });
  },

  mockAddAddress(data) {
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log('新增地址:', data);
        resolve();
      }, 500);
    });
  },

  mockUpdateAddress(id, data) {
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log('更新地址:', id, data);
        resolve();
      }, 500);
    });
  }
}); 