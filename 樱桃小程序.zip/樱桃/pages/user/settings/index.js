Page({
  data: {
    settings: {
      orderNotification: true,
      promotionNotification: true
    },
    cacheSize: '0KB',
    version: '1.0.0'
  },

  onLoad() {
    this.loadSettings()
    this.calculateCacheSize()
  },

  // 加载设置
  loadSettings() {
    try {
      const settings = wx.getStorageSync('settings')
      if (settings) {
        this.setData({
          settings
        })
      }
    } catch (e) {
      console.error('加载设置失败:', e)
    }
  },

  // 切换订单通知
  toggleOrderNotification(e) {
    const value = e.detail.value
    this.setData({
      'settings.orderNotification': value
    })
    this.saveSettings()
    
    if (value) {
      wx.requestSubscribeMessage({
        tmplIds: ['your-template-id-for-order'],
        success: (res) => {
          console.log('订阅订单消息成功', res)
        },
        fail: (err) => {
          console.error('订阅订单消息失败', err)
          // 订阅失败时回滚开关状态
          this.setData({
            'settings.orderNotification': false
          })
          this.saveSettings()
        }
      })
    }
  },

  // 切换促销通知
  togglePromotionNotification(e) {
    const value = e.detail.value
    this.setData({
      'settings.promotionNotification': value
    })
    this.saveSettings()
    
    if (value) {
      wx.requestSubscribeMessage({
        tmplIds: ['your-template-id-for-promotion'],
        success: (res) => {
          console.log('订阅促销消息成功', res)
        },
        fail: (err) => {
          console.error('订阅促销消息失败', err)
          // 订阅失败时回滚开关状态
          this.setData({
            'settings.promotionNotification': false
          })
          this.saveSettings()
        }
      })
    }
  },

  // 保存设置
  saveSettings() {
    try {
      wx.setStorageSync('settings', this.data.settings)
    } catch (e) {
      console.error('保存设置失败:', e)
      wx.showToast({
        title: '保存设置失败',
        icon: 'none'
      })
    }
  },

  // 计算缓存大小
  calculateCacheSize() {
    wx.getStorageInfo({
      success: (res) => {
        const sizeInKB = (res.currentSize).toFixed(1)
        this.setData({
          cacheSize: sizeInKB + 'KB'
        })
      },
      fail: (err) => {
        console.error('获取缓存大小失败:', err)
      }
    })
  },

  // 清除缓存
  clearCache() {
    wx.showModal({
      title: '提示',
      content: '确定要清除缓存吗？',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({
            title: '清除中...'
          })
          
          // 保存当前设置
          const currentSettings = this.data.settings
          
          wx.clearStorage({
            success: () => {
              // 恢复设置
              wx.setStorageSync('settings', currentSettings)
              this.calculateCacheSize()
              
              wx.hideLoading()
              wx.showToast({
                title: '清除成功',
                icon: 'success'
              })
            },
            fail: (err) => {
              console.error('清除缓存失败:', err)
              wx.hideLoading()
              wx.showToast({
                title: '清除失败',
                icon: 'none'
              })
            }
          })
        }
      }
    })
  },

  // 检查更新
  checkUpdate() {
    if (wx.canIUse('getUpdateManager')) {
      const updateManager = wx.getUpdateManager()
      
      updateManager.onCheckForUpdate((res) => {
        if (res.hasUpdate) {
          wx.showModal({
            title: '更新提示',
            content: '检测到新版本，是否下载更新？',
            success: (res) => {
              if (res.confirm) {
                this.downloadUpdate(updateManager)
              }
            }
          })
        } else {
          wx.showToast({
            title: '当前已是最新版本',
            icon: 'none'
          })
        }
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      })
    }
  },

  // 下载更新
  downloadUpdate(updateManager) {
    wx.showLoading({
      title: '下载中...'
    })

    updateManager.onUpdateReady(() => {
      wx.hideLoading()
      wx.showModal({
        title: '更新提示',
        content: '新版本已经准备好，是否重启应用？',
        success: (res) => {
          if (res.confirm) {
            updateManager.applyUpdate()
          }
        }
      })
    })

    updateManager.onUpdateFailed(() => {
      wx.hideLoading()
      wx.showModal({
        title: '更新提示',
        content: '新版本下载失败，请检查网络后重试'
      })
    })
  },

  // 跳转到关于我们页面
  navigateToAbout() {
    wx.navigateTo({
      url: '/pages/user/about/index'
    })
  }
}) 