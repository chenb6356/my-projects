#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
制造企业工业数据空间环境下的数据分析与共享系统

主要功能模块：
1. 数据生成模块 - 生成模拟制造数据集
2. 数据分类与建模模块 - 对多源制造数据进行分类和建模
3. 关联规则挖掘模块 - 挖掘设备参数、工艺条件与产品质量的关系
4. 数据安全共享模块 - 基于访问控制和使用策略的数据共享
5. 验证与可视化模块 - 案例分析和结果可视化

使用方法：
    python manufacturing_data_analysis.py --help
"""

import argparse
import logging
import os
import sys

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('manufacturing_analysis.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# 导入模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from modules.data_generator import DataGenerator
from modules.data_classifier import DataClassifier
from modules.association_miner import AssociationMiner
from modules.security_sharing import SecuritySharing
from modules.visualization import Visualization

def parse_arguments():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='制造企业工业数据空间环境下的数据分析与共享系统')
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # 数据生成命令
    generate_parser = subparsers.add_parser('generate', help='生成模拟制造数据')
    generate_parser.add_argument('--output', type=str, default='data', help='输出目录')
    generate_parser.add_argument('--size', type=int, default=1000, help='数据量大小')
    generate_parser.add_argument('--devices', type=int, default=5, help='设备数量')
    
    # 数据分类命令
    classify_parser = subparsers.add_parser('classify', help='对制造数据进行分类')
    classify_parser.add_argument('--input', type=str, default='data', help='输入数据目录')
    classify_parser.add_argument('--output', type=str, default='classified_data', help='分类结果输出目录')
    
    # 关联规则挖掘命令
    mine_parser = subparsers.add_parser('mine', help='挖掘关联规则')
    mine_parser.add_argument('--input', type=str, default='classified_data', help='输入分类数据目录')
    mine_parser.add_argument('--output', type=str, default='rules', help='规则输出目录')
    mine_parser.add_argument('--min-support', type=float, default=0.1, help='最小支持度')
    mine_parser.add_argument('--min-confidence', type=float, default=0.5, help='最小置信度')
    
    # 数据安全共享命令
    share_parser = subparsers.add_parser('share', help='数据安全共享')
    share_parser.add_argument('--input', type=str, default='classified_data', help='输入数据目录')
    share_parser.add_argument('--policy', type=str, default='policies.json', help='访问控制策略文件')
    share_parser.add_argument('--user', type=str, required=True, help='用户ID')
    
    # 可视化命令
    visualize_parser = subparsers.add_parser('visualize', help='数据和分析结果可视化')
    visualize_parser.add_argument('--input', type=str, default='rules', help='输入数据目录')
    visualize_parser.add_argument('--output', type=str, default='visualization', help='可视化结果输出目录')
    
    # 完整流程命令
    pipeline_parser = subparsers.add_parser('pipeline', help='执行完整分析流程')
    pipeline_parser.add_argument('--size', type=int, default=1000, help='数据量大小')
    
    return parser.parse_args()

def main():
    """主函数"""
    args = parse_arguments()
    
    try:
        if args.command == 'generate':
            logger.info('开始生成模拟制造数据...')
            generator = DataGenerator()
            generator.generate_data(args.size, args.devices, args.output)
            logger.info('数据生成完成')
            
        elif args.command == 'classify':
            logger.info('开始对制造数据进行分类...')
            classifier = DataClassifier()
            classifier.classify_data(args.input, args.output)
            logger.info('数据分类完成')
            
        elif args.command == 'mine':
            logger.info('开始挖掘关联规则...')
            miner = AssociationMiner()
            miner.mine_rules(args.input, args.output, args.min_support, args.min_confidence)
            logger.info('关联规则挖掘完成')
            
        elif args.command == 'share':
            logger.info('开始数据安全共享...')
            security = SecuritySharing()
            security.share_data(args.input, args.policy, args.user)
            logger.info('数据安全共享完成')
            
        elif args.command == 'visualize':
            logger.info('开始数据可视化...')
            viz = Visualization()
            viz.visualize(args.input, args.output)
            logger.info('数据可视化完成')
            
        elif args.command == 'pipeline':
            logger.info('执行完整分析流程...')
            # 生成数据
            generator = DataGenerator()
            generator.generate_data(args.size, 5, 'data')
            
            # 分类数据
            classifier = DataClassifier()
            classifier.classify_data('data', 'classified_data')
            
            # 挖掘规则
            miner = AssociationMiner()
            miner.mine_rules('classified_data', 'rules', 0.1, 0.5)
            
            # 可视化
            viz = Visualization()
            viz.visualize('rules', 'visualization')
            
            logger.info('完整分析流程执行完成')
            
        else:
            logger.error('未知命令，请使用 --help 查看可用命令')
            sys.exit(1)
            
    except Exception as e:
        logger.error(f'执行过程中发生错误: {str(e)}')
        sys.exit(1)

if __name__ == '__main__':
    main()
