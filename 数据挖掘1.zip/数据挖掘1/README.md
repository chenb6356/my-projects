# 制造企业工业数据空间环境下的数据分析与共享系统

## 项目简介

本系统是一个综合性Python程序，用于实现制造企业工业数据空间环境下的数据分析与共享功能。系统包含以下核心模块：

1. **数据生成模块**：生成模拟的制造数据集，包括设备运行数据、工艺参数数据和质量检测数据
2. **数据分类与建模模块**：对多源制造数据进行分类和建模，建立统一的数据属性描述模型
3. **关联规则挖掘模块**：挖掘设备运行参数、工艺条件与产品质量指标之间的关系
4. **数据安全共享模块**：基于访问控制和使用策略实现数据安全共享
5. **验证与可视化模块**：案例分析和结果可视化

## 环境要求

- Python 3.6+
- 主要依赖包：
  - pandas
  - numpy
  - matplotlib
  - seaborn
  - networkx

## 安装依赖

```bash
pip install pandas numpy matplotlib seaborn networkx
```

## 使用方法

### 1. 数据生成

生成模拟的制造数据集：

```bash
python manufacturing_data_analysis.py generate --size 1000 --devices 5 --output data
```

参数说明：
- `--size`：每个设备的数据量大小（默认：1000）
- `--devices`：设备数量（默认：5）
- `--output`：输出目录（默认：data）

### 2. 数据分类与建模

对制造数据进行分类和建模：

```bash
python manufacturing_data_analysis.py classify --input data --output classified_data
```

参数说明：
- `--input`：输入数据目录（默认：data）
- `--output`：分类结果输出目录（默认：classified_data）

### 3. 关联规则挖掘

挖掘关联规则：

```bash
python manufacturing_data_analysis.py mine --input classified_data --output rules --min-support 0.1 --min-confidence 0.5
```

参数说明：
- `--input`：输入分类数据目录（默认：classified_data）
- `--output`：规则输出目录（默认：rules）
- `--min-support`：最小支持度（默认：0.1）
- `--min-confidence`：最小置信度（默认：0.5）

### 4. 数据安全共享

数据安全共享：

```bash
python manufacturing_data_analysis.py share --input classified_data --policy policies.json --user engineer_zhangsan
```

参数说明：
- `--input`：输入数据目录（默认：classified_data）
- `--policy`：访问控制策略文件（默认：policies.json）
- `--user`：用户ID（必填，格式：role_username）

### 5. 数据可视化

数据和分析结果可视化：

```bash
python manufacturing_data_analysis.py visualize --input rules --output visualization
```

参数说明：
- `--input`：输入数据目录（默认：rules）
- `--output`：可视化结果输出目录（默认：visualization）

### 6. 完整流程

执行完整分析流程：

```bash
python manufacturing_data_analysis.py pipeline --size 1000
```

参数说明：
- `--size`：数据量大小（默认：1000）

## 系统架构

### 模块说明

1. **data_generator.py**：数据生成模块，生成模拟制造数据
2. **data_classifier.py**：数据分类与建模模块，对数据进行分类和建模
3. **association_miner.py**：关联规则挖掘模块，挖掘关联规则
4. **security_sharing.py**：数据安全共享模块，实现安全共享
5. **visualization.py**：验证与可视化模块，实现可视化和案例分析

### 数据结构

- **设备运行数据**：包含温度、压力、转速、电流、电压等参数
- **工艺参数数据**：包含进料速度、反应时间、温度设定、压力设定等参数
- **质量检测数据**：包含硬度、强度、表面光洁度、尺寸精度等参数
- **非结构化数据**：包含设备状态描述等文本信息

## 访问控制策略

系统默认的访问控制策略如下：

| 角色 | 设备数据 | 工艺数据 | 质量数据 | 非结构化数据 |
|------|---------|---------|---------|-------------|
| admin | full | full | full | full |
| engineer | full | full | full | limited |
| operator | limited | limited | view | none |
| analyst | limited | limited | full | limited |

## 输出结果

- **数据生成**：生成的数据集保存到指定目录
- **数据分类**：分类结果和数据模型保存到指定目录
- **关联规则**：挖掘的关联规则保存到指定目录
- **安全共享**：共享数据保存到 shared_data/{user_id} 目录
- **可视化**：可视化结果保存到指定目录

## 日志记录

系统运行过程中的日志信息会保存到 `manufacturing_analysis.log` 文件中。

## 示例

### 生成数据

```bash
python manufacturing_data_analysis.py generate --size 500 --devices 3 --output sample_data
```

### 执行完整流程

```bash
python manufacturing_data_analysis.py pipeline --size 1000
```

## 注意事项

1. 确保Python环境中安装了所有必要的依赖包
2. 数据量较大时，关联规则挖掘可能会消耗较多时间和内存
3. 安全共享功能会根据用户角色自动限制数据访问权限
4. 可视化功能需要matplotlib和seaborn库的支持

## 故障排除

- **依赖包缺失**：运行 `pip install` 安装缺失的依赖包
- **数据文件不存在**：确保输入目录中存在相应的数据文件
- **权限错误**：确保用户有读写文件的权限
- **内存不足**：减小数据量大小或增加系统内存
