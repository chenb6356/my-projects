#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据分类与建模模块

功能：实现多源制造数据的分类功能，能够区分设备运行数据、工艺参数数据和质量检测数据，并建立统一的数据属性描述模型
"""

import os
import json
import pandas as pd
import logging

logger = logging.getLogger(__name__)

class DataClassifier:
    """制造数据分类器"""
    
    def __init__(self):
        """初始化数据分类器"""
        # 数据类型特征定义
        self.data_type_features = {
            'device': ['温度', '压力', '转速', '电流', '电压'],
            'process': ['进料速度', '反应时间', '温度设定', '压力设定'],
            'quality': ['硬度', '强度', '表面光洁度', '尺寸精度', 'quality_level']
        }
        
        # 统一数据属性描述模型
        self.unified_model = {
            'basic_info': {
                'timestamp': '时间戳',
                'device_id': '设备ID',
                'data_type': '数据类型'
            },
            'device_attributes': {
                '温度': {'type': '数值', 'unit': '℃', 'description': '设备运行温度'},
                '压力': {'type': '数值', 'unit': 'MPa', 'description': '设备运行压力'},
                '转速': {'type': '数值', 'unit': 'rpm', 'description': '设备运行转速'},
                '电流': {'type': '数值', 'unit': 'A', 'description': '设备运行电流'},
                '电压': {'type': '数值', 'unit': 'V', 'description': '设备运行电压'}
            },
            'process_attributes': {
                '进料速度': {'type': '数值', 'unit': 'kg/h', 'description': '原材料进料速度'},
                '反应时间': {'type': '数值', 'unit': 'min', 'description': '工艺反应时间'},
                '温度设定': {'type': '数值', 'unit': '℃', 'description': '工艺温度设定值'},
                '压力设定': {'type': '数值', 'unit': 'MPa', 'description': '工艺压力设定值'}
            },
            'quality_attributes': {
                '硬度': {'type': '数值', 'unit': 'HRB', 'description': '产品硬度'},
                '强度': {'type': '数值', 'unit': 'MPa', 'description': '产品强度'},
                '表面光洁度': {'type': '数值', 'unit': 'Ra', 'description': '产品表面光洁度'},
                '尺寸精度': {'type': '数值', 'unit': 'mm', 'description': '产品尺寸精度'},
                'quality_level': {'type': '分类', 'unit': '', 'description': '产品质量等级'}
            },
            'unstructured_attributes': {
                'content': {'type': '文本', 'unit': '', 'description': '非结构化文本内容'}
            }
        }
    
    def detect_data_type(self, data):
        """检测数据类型
        
        Args:
            data (pd.DataFrame): 输入数据
            
        Returns:
            str: 数据类型 (device/process/quality/unstructured)
        """
        # 检查数据特征
        columns = set(data.columns)
        
        # 检查是否为设备数据
        if all(feature in columns for feature in self.data_type_features['device']):
            return 'device'
        
        # 检查是否为工艺数据
        elif all(feature in columns for feature in self.data_type_features['process']):
            return 'process'
        
        # 检查是否为质量数据
        elif all(feature in columns for feature in ['硬度', '强度', '表面光洁度', '尺寸精度']):
            return 'quality'
        
        # 检查是否为非结构化数据
        elif 'content' in columns:
            return 'unstructured'
        
        else:
            return 'unknown'
    
    def normalize_data(self, data, data_type):
        """规范化数据
        
        Args:
            data (pd.DataFrame): 输入数据
            data_type (str): 数据类型
            
        Returns:
            pd.DataFrame: 规范化后的数据
        """
        # 确保基本字段存在
        if 'timestamp' not in data.columns:
            data['timestamp'] = pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
        
        if 'device_id' not in data.columns:
            data['device_id'] = 'unknown'
        
        if 'data_type' not in data.columns:
            data['data_type'] = data_type
        
        # 根据数据类型进行规范化
        if data_type == 'device':
            # 确保所有设备参数字段存在
            for feature in self.data_type_features['device']:
                if feature not in data.columns:
                    data[feature] = 0.0
        
        elif data_type == 'process':
            # 确保所有工艺参数字段存在
            for feature in self.data_type_features['process']:
                if feature not in data.columns:
                    data[feature] = 0.0
        
        elif data_type == 'quality':
            # 确保所有质量参数字段存在
            for feature in ['硬度', '强度', '表面光洁度', '尺寸精度']:
                if feature not in data.columns:
                    data[feature] = 0.0
            if 'quality_level' not in data.columns:
                data['quality_level'] = 'C'
        
        return data
    
    def build_data_model(self, data, data_type):
        """构建数据模型
        
        Args:
            data (pd.DataFrame): 输入数据
            data_type (str): 数据类型
            
        Returns:
            dict: 数据模型
        """
        model = {
            'data_type': data_type,
            'record_count': len(data),
            'attributes': {},
            'statistics': {}
        }
        
        # 添加属性信息
        if data_type == 'device':
            model['attributes'] = self.unified_model['device_attributes']
        elif data_type == 'process':
            model['attributes'] = self.unified_model['process_attributes']
        elif data_type == 'quality':
            model['attributes'] = self.unified_model['quality_attributes']
        elif data_type == 'unstructured':
            model['attributes'] = self.unified_model['unstructured_attributes']
        
        # 计算统计信息
        for column in data.columns:
            if data[column].dtype in ['int64', 'float64']:
                model['statistics'][column] = {
                    'mean': float(data[column].mean()),
                    'std': float(data[column].std()),
                    'min': float(data[column].min()),
                    'max': float(data[column].max())
                }
            elif data[column].dtype == 'object':
                model['statistics'][column] = {
                    'unique_count': int(data[column].nunique()),
                    'sample_values': list(data[column].unique()[:5])
                }
        
        return model
    
    def classify_data(self, input_dir, output_dir):
        """分类数据并建立模型
        
        Args:
            input_dir (str): 输入数据目录
            output_dir (str): 输出目录
        """
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        
        # 处理CSV文件
        for file_name in os.listdir(input_dir):
            if file_name.endswith('.csv'):
                file_path = os.path.join(input_dir, file_name)
                logger.info(f'处理文件: {file_name}')
                
                try:
                    # 读取数据
                    data = pd.read_csv(file_path, encoding='utf-8')
                    
                    # 检测数据类型
                    data_type = self.detect_data_type(data)
                    logger.info(f'检测到数据类型: {data_type}')
                    
                    if data_type != 'unknown':
                        # 规范化数据
                        normalized_data = self.normalize_data(data, data_type)
                        
                        # 构建数据模型
                        data_model = self.build_data_model(normalized_data, data_type)
                        
                        # 保存分类后的数据
                        output_file = os.path.join(output_dir, f'{data_type}_data.csv')
                        normalized_data.to_csv(output_file, index=False, encoding='utf-8')
                        
                        # 保存数据模型
                        model_file = os.path.join(output_dir, f'{data_type}_model.json')
                        with open(model_file, 'w', encoding='utf-8') as f:
                            json.dump(data_model, f, ensure_ascii=False, indent=2)
                    
                except Exception as e:
                    logger.error(f'处理文件 {file_name} 时发生错误: {str(e)}')
        
        # 处理JSON文件（非结构化数据）
        for file_name in os.listdir(input_dir):
            if file_name.endswith('.json'):
                file_path = os.path.join(input_dir, file_name)
                logger.info(f'处理文件: {file_name}')
                
                try:
                    # 读取数据
                    with open(file_path, 'r', encoding='utf-8') as f:
                        unstructured_data = json.load(f)
                    
                    # 转换为DataFrame
                    data = pd.DataFrame(unstructured_data)
                    
                    # 规范化数据
                    normalized_data = self.normalize_data(data, 'unstructured')
                    
                    # 构建数据模型
                    data_model = self.build_data_model(normalized_data, 'unstructured')
                    
                    # 保存分类后的数据
                    output_file = os.path.join(output_dir, 'unstructured_data.csv')
                    normalized_data.to_csv(output_file, index=False, encoding='utf-8')
                    
                    # 保存数据模型
                    model_file = os.path.join(output_dir, 'unstructured_model.json')
                    with open(model_file, 'w', encoding='utf-8') as f:
                        json.dump(data_model, f, ensure_ascii=False, indent=2)
                    
                except Exception as e:
                    logger.error(f'处理文件 {file_name} 时发生错误: {str(e)}')
        
        # 保存统一数据属性描述模型
        model_file = os.path.join(output_dir, 'unified_model.json')
        with open(model_file, 'w', encoding='utf-8') as f:
            json.dump(self.unified_model, f, ensure_ascii=False, indent=2)
        
        logger.info(f'数据分类完成，结果保存到 {output_dir} 目录')
