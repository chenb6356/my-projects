#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
关联规则挖掘模块

功能：实现数据预处理和离散化处理功能，集成Apriori等经典关联规则算法，挖掘设备运行参数、工艺条件与产品质量指标之间的关系
"""

import os
import json
import pandas as pd
import numpy as np
import logging
from collections import defaultdict

logger = logging.getLogger(__name__)

class AssociationMiner:
    """关联规则挖掘器"""
    
    def __init__(self):
        """初始化关联规则挖掘器"""
        pass
    
    def preprocess_data(self, input_dir):
        """预处理数据
        
        Args:
            input_dir (str): 输入数据目录
            
        Returns:
            pd.DataFrame: 预处理后的数据
        """
        # 读取各类数据
        device_data = pd.DataFrame()
        process_data = pd.DataFrame()
        quality_data = pd.DataFrame()
        
        for file_name in os.listdir(input_dir):
            if file_name == 'device_data.csv':
                device_data = pd.read_csv(os.path.join(input_dir, file_name), encoding='utf-8')
            elif file_name == 'process_data.csv':
                process_data = pd.read_csv(os.path.join(input_dir, file_name), encoding='utf-8')
            elif file_name == 'quality_data.csv':
                quality_data = pd.read_csv(os.path.join(input_dir, file_name), encoding='utf-8')
        
        # 合并数据（基于时间戳和设备ID）
        if not device_data.empty and not process_data.empty and not quality_data.empty:
            # 确保时间戳格式一致
            device_data['timestamp'] = pd.to_datetime(device_data['timestamp'])
            process_data['timestamp'] = pd.to_datetime(process_data['timestamp'])
            quality_data['timestamp'] = pd.to_datetime(quality_data['timestamp'])
            
            # 合并数据
            merged_data = device_data.merge(
                process_data, 
                on=['timestamp', 'device_id'], 
                how='inner',
                suffixes=('_device', '_process')
            )
            
            merged_data = merged_data.merge(
                quality_data, 
                on=['timestamp', 'device_id'], 
                how='inner'
            )
            
            logger.info(f'合并后的数据量: {len(merged_data)}')
            return merged_data
        else:
            logger.error('缺少必要的数据文件')
            return pd.DataFrame()
    
    def discretize_data(self, data, bins=3):
        """离散化数据
        
        Args:
            data (pd.DataFrame): 输入数据
            bins (int): 离散化的 bins 数量
            
        Returns:
            pd.DataFrame: 离散化后的数据
        """
        discretized_data = data.copy()
        
        # 需要离散化的数值列
        numeric_columns = [
            '温度', '压力', '转速', '电流', '电压',
            '进料速度', '反应时间', '温度设定', '压力设定',
            '硬度', '强度', '表面光洁度', '尺寸精度'
        ]
        
        for col in numeric_columns:
            if col in discretized_data.columns:
                # 使用等宽离散化
                discretized_data[col] = pd.cut(
                    discretized_data[col], 
                    bins=bins, 
                    labels=[f'{col}_level_{i+1}' for i in range(bins)]
                )
        
        return discretized_data
    
    def apriori(self, transactions, min_support):
        """Apriori算法实现
        
        Args:
            transactions (list): 交易列表，每个交易是物品集合
            min_support (float): 最小支持度
            
        Returns:
            dict: 频繁项集及其支持度
        """
        # 计算单项的支持度
        item_counts = defaultdict(int)
        for transaction in transactions:
            for item in transaction:
                item_counts[item] += 1
        
        # 过滤出频繁单项
        n_transactions = len(transactions)
        frequent_items = {
            frozenset([item]): count / n_transactions 
            for item, count in item_counts.items() 
            if count / n_transactions >= min_support
        }
        
        logger.info(f'频繁单项数量: {len(frequent_items)}')
        
        # 生成候选项集
        k = 2
        all_frequent_items = frequent_items.copy()
        
        while frequent_items:
            # 生成候选项集
            candidates = set()
            frequent_items_list = list(frequent_items.keys())
            
            for i in range(len(frequent_items_list)):
                for j in range(i + 1, len(frequent_items_list)):
                    itemset1 = frequent_items_list[i]
                    itemset2 = frequent_items_list[j]
                    
                    # 生成k项集
                    candidate = itemset1.union(itemset2)
                    if len(candidate) == k:
                        candidates.add(candidate)
            
            # 计算候选项集的支持度
            candidate_counts = defaultdict(int)
            for transaction in transactions:
                transaction_set = set(transaction)
                for candidate in candidates:
                    if candidate.issubset(transaction_set):
                        candidate_counts[candidate] += 1
            
            # 过滤出频繁项集
            frequent_items = {
                itemset: count / n_transactions 
                for itemset, count in candidate_counts.items() 
                if count / n_transactions >= min_support
            }
            
            logger.info(f'频繁{k}项数量: {len(frequent_items)}')
            all_frequent_items.update(frequent_items)
            k += 1
        
        return all_frequent_items
    
    def generate_rules(self, frequent_items, min_confidence):
        """生成关联规则
        
        Args:
            frequent_items (dict): 频繁项集及其支持度
            min_confidence (float): 最小置信度
            
        Returns:
            list: 关联规则列表
        """
        rules = []
        
        for itemset, support in frequent_items.items():
            if len(itemset) > 1:
                # 生成所有可能的规则
                for item in itemset:
                    antecedent = frozenset(itemset - {item})
                    consequent = frozenset({item})
                    
                    # 计算置信度
                    if antecedent in frequent_items:
                        confidence = support / frequent_items[antecedent]
                        if confidence >= min_confidence:
                            # 计算提升度
                            if consequent in frequent_items:
                                lift = confidence / frequent_items[consequent]
                            else:
                                lift = 0
                            
                            rules.append({
                                'antecedent': list(antecedent),
                                'consequent': list(consequent),
                                'support': support,
                                'confidence': confidence,
                                'lift': lift
                            })
        
        # 按置信度排序
        rules.sort(key=lambda x: x['confidence'], reverse=True)
        return rules
    
    def mine_rules(self, input_dir, output_dir, min_support=0.1, min_confidence=0.5):
        """挖掘关联规则
        
        Args:
            input_dir (str): 输入数据目录
            output_dir (str): 输出目录
            min_support (float): 最小支持度
            min_confidence (float): 最小置信度
        """
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        
        # 预处理数据
        logger.info('预处理数据...')
        merged_data = self.preprocess_data(input_dir)
        
        if merged_data.empty:
            logger.error('没有足够的数据进行关联规则挖掘')
            return
        
        # 离散化数据
        logger.info('离散化数据...')
        discretized_data = self.discretize_data(merged_data)
        
        # 转换为交易格式
        logger.info('转换为交易格式...')
        transactions = []
        for _, row in discretized_data.iterrows():
            transaction = []
            # 添加设备参数
            for col in ['温度', '压力', '转速', '电流', '电压']:
                if col in row and pd.notna(row[col]):
                    transaction.append(str(row[col]))
            # 添加工艺参数
            for col in ['进料速度', '反应时间', '温度设定', '压力设定']:
                if col in row and pd.notna(row[col]):
                    transaction.append(str(row[col]))
            # 添加质量参数
            for col in ['硬度', '强度', '表面光洁度', '尺寸精度', 'quality_level']:
                if col in row and pd.notna(row[col]):
                    if col == 'quality_level':
                        transaction.append(f'quality_level_{row[col]}')
                    else:
                        transaction.append(str(row[col]))
            transactions.append(transaction)
        
        # 运行Apriori算法
        logger.info('运行Apriori算法...')
        frequent_items = self.apriori(transactions, min_support)
        
        # 生成关联规则
        logger.info('生成关联规则...')
        rules = self.generate_rules(frequent_items, min_confidence)
        
        # 保存结果
        results = {
            'min_support': min_support,
            'min_confidence': min_confidence,
            'total_transactions': len(transactions),
            'frequent_items_count': len(frequent_items),
            'rules_count': len(rules),
            'rules': rules
        }
        
        output_file = os.path.join(output_dir, 'association_rules.json')
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        
        # 保存前20条规则到CSV文件
        if rules:
            top_rules = rules[:20]
            rules_df = pd.DataFrame(top_rules)
            rules_df['antecedent'] = rules_df['antecedent'].apply(lambda x: ', '.join(x))
            rules_df['consequent'] = rules_df['consequent'].apply(lambda x: ', '.join(x))
            rules_df.to_csv(os.path.join(output_dir, 'top_rules.csv'), index=False, encoding='utf-8')
        
        logger.info(f'关联规则挖掘完成，发现 {len(rules)} 条规则')
