#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据生成模块

功能：根据制造企业多源生产数据特征，生成模拟的制造数据集，包括设备运行数据、工艺参数数据和质量检测数据
"""

import os
import json
import random
import pandas as pd
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

class DataGenerator:
    """制造数据生成器"""
    
    def __init__(self):
        """初始化数据生成器"""
        self.device_parameters = {
            '温度': {'min': 20, 'max': 80, 'unit': '℃'},
            '压力': {'min': 1, 'max': 10, 'unit': 'MPa'},
            '转速': {'min': 500, 'max': 2000, 'unit': 'rpm'},
            '电流': {'min': 5, 'max': 50, 'unit': 'A'},
            '电压': {'min': 220, 'max': 380, 'unit': 'V'}
        }
        
        self.process_parameters = {
            '进料速度': {'min': 10, 'max': 100, 'unit': 'kg/h'},
            '反应时间': {'min': 5, 'max': 60, 'unit': 'min'},
            '温度设定': {'min': 30, 'max': 70, 'unit': '℃'},
            '压力设定': {'min': 2, 'max': 8, 'unit': 'MPa'}
        }
        
        self.quality_parameters = {
            '硬度': {'min': 50, 'max': 100, 'unit': 'HRB'},
            '强度': {'min': 100, 'max': 500, 'unit': 'MPa'},
            '表面光洁度': {'min': 1, 'max': 10, 'unit': 'Ra'},
            '尺寸精度': {'min': 0.01, 'max': 0.1, 'unit': 'mm'}
        }
    
    def generate_device_data(self, size, device_id):
        """生成设备运行数据
        
        Args:
            size (int): 数据量大小
            device_id (int): 设备ID
            
        Returns:
            pd.DataFrame: 设备运行数据
        """
        data = []
        start_time = datetime.now() - timedelta(days=1)
        
        for i in range(size):
            timestamp = start_time + timedelta(minutes=i)
            record = {
                'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                'device_id': f'DEV{device_id:03d}',
                'data_type': 'device'
            }
            
            # 生成设备参数
            for param, config in self.device_parameters.items():
                # 添加一些随机性和相关性
                base_value = random.uniform(config['min'], config['max'])
                # 模拟设备运行状态的波动
                if i > 0 and i % 100 == 0:
                    # 每100条记录模拟一次异常波动
                    base_value *= random.uniform(0.8, 1.2)
                record[param] = round(base_value, 2)
            
            data.append(record)
        
        return pd.DataFrame(data)
    
    def generate_process_data(self, size, device_id):
        """生成工艺参数数据
        
        Args:
            size (int): 数据量大小
            device_id (int): 设备ID
            
        Returns:
            pd.DataFrame: 工艺参数数据
        """
        data = []
        start_time = datetime.now() - timedelta(days=1)
        
        for i in range(size):
            timestamp = start_time + timedelta(minutes=i)
            record = {
                'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                'device_id': f'DEV{device_id:03d}',
                'data_type': 'process'
            }
            
            # 生成工艺参数
            for param, config in self.process_parameters.items():
                record[param] = round(random.uniform(config['min'], config['max']), 2)
            
            data.append(record)
        
        return pd.DataFrame(data)
    
    def generate_quality_data(self, size, device_id):
        """生成质量检测数据
        
        Args:
            size (int): 数据量大小
            device_id (int): 设备ID
            
        Returns:
            pd.DataFrame: 质量检测数据
        """
        data = []
        start_time = datetime.now() - timedelta(days=1)
        
        for i in range(size):
            timestamp = start_time + timedelta(minutes=i)
            record = {
                'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                'device_id': f'DEV{device_id:03d}',
                'data_type': 'quality',
                'product_id': f'PROD{i:05d}'
            }
            
            # 生成质量参数
            for param, config in self.quality_parameters.items():
                record[param] = round(random.uniform(config['min'], config['max']), 2)
            
            # 添加质量等级
            quality_score = sum(record[param] for param in self.quality_parameters.keys()) / len(self.quality_parameters)
            if quality_score > 70:
                record['quality_level'] = 'A'
            elif quality_score > 50:
                record['quality_level'] = 'B'
            else:
                record['quality_level'] = 'C'
            
            data.append(record)
        
        return pd.DataFrame(data)
    
    def generate_unstructured_data(self, size, device_id):
        """生成非结构化数据
        
        Args:
            size (int): 数据量大小
            device_id (int): 设备ID
            
        Returns:
            list: 非结构化数据列表
        """
        unstructured_data = []
        start_time = datetime.now() - timedelta(days=1)
        
        # 设备状态描述模板
        status_templates = [
            "设备运行正常，无异常",
            "设备温度略有波动，在正常范围内",
            "设备噪音增大，建议检查轴承",
            "设备振动异常，需要维护",
            "设备运行稳定，各项参数正常"
        ]
        
        for i in range(size):
            timestamp = start_time + timedelta(minutes=i)
            record = {
                'timestamp': timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                'device_id': f'DEV{device_id:03d}',
                'data_type': 'unstructured',
                'content': random.choice(status_templates)
            }
            unstructured_data.append(record)
        
        return unstructured_data
    
    def generate_data(self, size, num_devices, output_dir):
        """生成完整的制造数据集
        
        Args:
            size (int): 每个设备的数据量大小
            num_devices (int): 设备数量
            output_dir (str): 输出目录
        """
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        
        all_device_data = []
        all_process_data = []
        all_quality_data = []
        all_unstructured_data = []
        
        for device_id in range(1, num_devices + 1):
            logger.info(f'生成设备 {device_id} 的数据...')
            
            # 生成各类数据
            device_data = self.generate_device_data(size, device_id)
            process_data = self.generate_process_data(size, device_id)
            quality_data = self.generate_quality_data(size, device_id)
            unstructured_data = self.generate_unstructured_data(size, device_id)
            
            # 合并数据
            all_device_data.append(device_data)
            all_process_data.append(process_data)
            all_quality_data.append(quality_data)
            all_unstructured_data.extend(unstructured_data)
        
        # 保存数据
        if all_device_data:
            pd.concat(all_device_data).to_csv(os.path.join(output_dir, 'device_data.csv'), index=False, encoding='utf-8')
        
        if all_process_data:
            pd.concat(all_process_data).to_csv(os.path.join(output_dir, 'process_data.csv'), index=False, encoding='utf-8')
        
        if all_quality_data:
            pd.concat(all_quality_data).to_csv(os.path.join(output_dir, 'quality_data.csv'), index=False, encoding='utf-8')
        
        if all_unstructured_data:
            with open(os.path.join(output_dir, 'unstructured_data.json'), 'w', encoding='utf-8') as f:
                json.dump(all_unstructured_data, f, ensure_ascii=False, indent=2)
        
        logger.info(f'数据生成完成，保存到 {output_dir} 目录')
