#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据安全共享模块

功能：设计基于访问控制和使用策略的数据共享流程，实现数据提供方与数据使用方的权限边界管理功能
"""

import os
import json
import pandas as pd
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class SecuritySharing:
    """数据安全共享管理器"""
    
    def __init__(self):
        """初始化数据安全共享管理器"""
        # 默认访问控制策略
        self.default_policies = {
            "admin": {
                "device_data": "full",
                "process_data": "full",
                "quality_data": "full",
                "unstructured_data": "full"
            },
            "engineer": {
                "device_data": "full",
                "process_data": "full",
                "quality_data": "full",
                "unstructured_data": "limited"
            },
            "operator": {
                "device_data": "limited",
                "process_data": "limited",
                "quality_data": "view",
                "unstructured_data": "none"
            },
            "analyst": {
                "device_data": "limited",
                "process_data": "limited",
                "quality_data": "full",
                "unstructured_data": "limited"
            }
        }
    
    def load_policies(self, policy_file):
        """加载访问控制策略
        
        Args:
            policy_file (str): 策略文件路径
            
        Returns:
            dict: 访问控制策略
        """
        if not os.path.exists(policy_file):
            # 创建默认策略文件
            with open(policy_file, 'w', encoding='utf-8') as f:
                json.dump(self.default_policies, f, ensure_ascii=False, indent=2)
            logger.info(f'创建默认策略文件: {policy_file}')
            return self.default_policies
        
        try:
            with open(policy_file, 'r', encoding='utf-8') as f:
                policies = json.load(f)
            logger.info(f'加载策略文件: {policy_file}')
            return policies
        except Exception as e:
            logger.error(f'加载策略文件失败: {str(e)}')
            return self.default_policies
    
    def get_user_policy(self, user_id, policy_file):
        """获取用户访问策略
        
        Args:
            user_id (str): 用户ID
            policy_file (str): 策略文件路径
            
        Returns:
            dict: 用户访问策略
        """
        policies = self.load_policies(policy_file)
        
        # 提取用户角色（假设用户ID格式为 role_username）
        if '_' in user_id:
            role = user_id.split('_')[0]
        else:
            role = 'operator'  # 默认角色
        
        if role in policies:
            return policies[role]
        else:
            logger.warning(f'用户角色 {role} 未定义，使用默认策略')
            return policies.get('operator', {})
    
    def anonymize_data(self, data, data_type, access_level):
        """数据匿名化处理
        
        Args:
            data (pd.DataFrame): 输入数据
            data_type (str): 数据类型
            access_level (str): 访问级别
            
        Returns:
            pd.DataFrame: 处理后的数据
        """
        if access_level == 'full':
            return data
        
        anonymized_data = data.copy()
        
        # 根据数据类型和访问级别进行处理
        if data_type == 'device':
            if access_level == 'limited':
                # 只保留部分关键参数
                keep_columns = ['timestamp', 'device_id', '温度', '压力']
                anonymized_data = anonymized_data[[col for col in keep_columns if col in anonymized_data.columns]]
            elif access_level == 'view':
                # 只保留基本信息和统计数据
                anonymized_data = pd.DataFrame({
                    'device_id': anonymized_data['device_id'].unique(),
                    'temperature_avg': [anonymized_data['温度'].mean()],
                    'pressure_avg': [anonymized_data['压力'].mean()]
                })
        
        elif data_type == 'process':
            if access_level == 'limited':
                # 只保留部分关键参数
                keep_columns = ['timestamp', 'device_id', '温度设定', '压力设定']
                anonymized_data = anonymized_data[[col for col in keep_columns if col in anonymized_data.columns]]
            elif access_level == 'view':
                # 只保留基本信息和统计数据
                anonymized_data = pd.DataFrame({
                    'device_id': anonymized_data['device_id'].unique(),
                    'temperature_setpoint_avg': [anonymized_data['温度设定'].mean()],
                    'pressure_setpoint_avg': [anonymized_data['压力设定'].mean()]
                })
        
        elif data_type == 'quality':
            if access_level == 'limited':
                # 移除详细质量参数，只保留质量等级
                keep_columns = ['timestamp', 'device_id', 'product_id', 'quality_level']
                anonymized_data = anonymized_data[[col for col in keep_columns if col in anonymized_data.columns]]
            elif access_level == 'view':
                # 只保留质量等级分布
                quality_dist = anonymized_data['quality_level'].value_counts().to_dict()
                anonymized_data = pd.DataFrame([quality_dist])
        
        elif data_type == 'unstructured':
            if access_level == 'limited':
                # 只保留基本信息，移除详细内容
                keep_columns = ['timestamp', 'device_id']
                anonymized_data = anonymized_data[[col for col in keep_columns if col in anonymized_data.columns]]
            elif access_level == 'view':
                # 不返回任何数据
                anonymized_data = pd.DataFrame()
        
        return anonymized_data
    
    def share_data(self, input_dir, policy_file, user_id):
        """安全共享数据
        
        Args:
            input_dir (str): 输入数据目录
            policy_file (str): 访问控制策略文件
            user_id (str): 用户ID
        """
        # 获取用户访问策略
        user_policy = self.get_user_policy(user_id, policy_file)
        logger.info(f'用户 {user_id} 的访问策略: {user_policy}')
        
        # 创建共享目录
        share_dir = os.path.join('shared_data', user_id)
        os.makedirs(share_dir, exist_ok=True)
        
        # 处理各类数据
        data_files = {
            'device_data': 'device_data.csv',
            'process_data': 'process_data.csv',
            'quality_data': 'quality_data.csv',
            'unstructured_data': 'unstructured_data.csv'
        }
        
        for data_type, file_name in data_files.items():
            file_path = os.path.join(input_dir, file_name)
            if os.path.exists(file_path):
                try:
                    # 读取数据
                    data = pd.read_csv(file_path, encoding='utf-8')
                    
                    # 获取访问级别
                    access_level = user_policy.get(data_type, 'none')
                    
                    if access_level != 'none':
                        # 匿名化处理
                        processed_data = self.anonymize_data(data, data_type, access_level)
                        
                        if not processed_data.empty:
                            # 保存处理后的数据
                            output_file = os.path.join(share_dir, f'{data_type}_shared.csv')
                            processed_data.to_csv(output_file, index=False, encoding='utf-8')
                            logger.info(f'共享 {data_type} 数据给用户 {user_id}，访问级别: {access_level}')
                        else:
                            logger.info(f'用户 {user_id} 对 {data_type} 没有访问权限')
                    else:
                        logger.info(f'用户 {user_id} 对 {data_type} 没有访问权限')
                    
                except Exception as e:
                    logger.error(f'处理 {data_type} 数据时发生错误: {str(e)}')
        
        # 生成访问日志
        access_log = {
            'user_id': user_id,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'policy': user_policy,
            'shared_files': [f for f in os.listdir(share_dir) if f.endswith('.csv')]
        }
        
        # 保存访问日志
        log_dir = 'access_logs'
        os.makedirs(log_dir, exist_ok=True)
        log_file = os.path.join(log_dir, f'{user_id}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json')
        with open(log_file, 'w', encoding='utf-8') as f:
            json.dump(access_log, f, ensure_ascii=False, indent=2)
        
        logger.info(f'数据安全共享完成，结果保存到 {share_dir} 目录')
