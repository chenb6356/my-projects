#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
验证与可视化模块

功能：开发案例分析功能，验证所提方案的可行性和实用性，实现数据和分析结果的可视化展示功能
"""

import os
import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import logging
import networkx as nx
from datetime import datetime

logger = logging.getLogger(__name__)

class Visualization:
    """数据可视化器"""
    
    def __init__(self):
        """初始化数据可视化器"""
        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
        plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
    
    def visualize_data_distribution(self, data_dir, output_dir):
        """可视化数据分布
        
        Args:
            data_dir (str): 数据目录
            output_dir (str): 输出目录
        """
        # 处理设备数据
        device_file = os.path.join(data_dir, 'device_data.csv')
        if os.path.exists(device_file):
            device_data = pd.read_csv(device_file, encoding='utf-8')
            
            # 设备参数分布
            fig, axes = plt.subplots(2, 3, figsize=(15, 10))
            axes = axes.flatten()
            
            parameters = ['温度', '压力', '转速', '电流', '电压']
            for i, param in enumerate(parameters):
                if param in device_data.columns:
                    sns.histplot(device_data[param], ax=axes[i], kde=True)
                    axes[i].set_title(f'{param}分布')
                    axes[i].set_xlabel(param)
                    axes[i].set_ylabel('频率')
            
            plt.tight_layout()
            plt.savefig(os.path.join(output_dir, 'device_parameters_distribution.png'))
            plt.close()
            logger.info('设备参数分布可视化完成')
        
        # 处理质量数据
        quality_file = os.path.join(data_dir, 'quality_data.csv')
        if os.path.exists(quality_file):
            quality_data = pd.read_csv(quality_file, encoding='utf-8')
            
            # 质量等级分布
            plt.figure(figsize=(10, 6))
            sns.countplot(x='quality_level', data=quality_data, order=['A', 'B', 'C'])
            plt.title('质量等级分布')
            plt.xlabel('质量等级')
            plt.ylabel('数量')
            plt.savefig(os.path.join(output_dir, 'quality_level_distribution.png'))
            plt.close()
            logger.info('质量等级分布可视化完成')
    
    def visualize_association_rules(self, rules_dir, output_dir):
        """可视化关联规则
        
        Args:
            rules_dir (str): 规则目录
            output_dir (str): 输出目录
        """
        rules_file = os.path.join(rules_dir, 'association_rules.json')
        if os.path.exists(rules_file):
            with open(rules_file, 'r', encoding='utf-8') as f:
                rules_data = json.load(f)
            
            rules = rules_data.get('rules', [])
            if rules:
                # 可视化前10条规则
                top_rules = rules[:10]
                
                # 规则置信度和支持度
                plt.figure(figsize=(12, 8))
                confidence = [rule['confidence'] for rule in top_rules]
                support = [rule['support'] for rule in top_rules]
                rule_names = [f"规则{i+1}" for i in range(len(top_rules))]
                
                x = range(len(top_rules))
                width = 0.35
                
                plt.bar([i - width/2 for i in x], confidence, width, label='置信度')
                plt.bar([i + width/2 for i in x], support, width, label='支持度')
                plt.xticks(x, rule_names, rotation=45)
                plt.xlabel('规则')
                plt.ylabel('值')
                plt.title('关联规则置信度和支持度')
                plt.legend()
                plt.tight_layout()
                plt.savefig(os.path.join(output_dir, 'rules_confidence_support.png'))
                plt.close()
                logger.info('关联规则置信度和支持度可视化完成')
                
                # 规则网络图
                G = nx.DiGraph()
                
                # 添加节点和边
                for rule in top_rules:
                    antecedent = ', '.join(rule['antecedent'])
                    consequent = ', '.join(rule['consequent'])
                    confidence = rule['confidence']
                    
                    G.add_node(antecedent)
                    G.add_node(consequent)
                    G.add_edge(antecedent, consequent, weight=confidence)
                
                plt.figure(figsize=(15, 10))
                pos = nx.spring_layout(G, k=0.3)
                
                # 绘制节点
                nx.draw_networkx_nodes(G, pos, node_size=3000, node_color='lightblue')
                
                # 绘制边
                edges = G.edges(data=True)
                weights = [edge[2]['weight'] * 5 for edge in edges]
                nx.draw_networkx_edges(G, pos, width=weights, edge_color='gray', arrowsize=20)
                
                # 绘制标签
                nx.draw_networkx_labels(G, pos, font_size=10, font_family='SimHei')
                
                plt.title('关联规则网络图')
                plt.axis('off')
                plt.tight_layout()
                plt.savefig(os.path.join(output_dir, 'rules_network.png'))
                plt.close()
                logger.info('关联规则网络图可视化完成')
    
    def visualize_security_sharing(self, shared_dir, output_dir):
        """可视化安全共享结果
        
        Args:
            shared_dir (str): 共享数据目录
            output_dir (str): 输出目录
        """
        if os.path.exists(shared_dir):
            # 统计各用户的访问权限
            user_access = {}
            
            for user_dir in os.listdir(shared_dir):
                user_path = os.path.join(shared_dir, user_dir)
                if os.path.isdir(user_path):
                    shared_files = [f for f in os.listdir(user_path) if f.endswith('.csv')]
                    user_access[user_dir] = len(shared_files)
            
            if user_access:
                plt.figure(figsize=(12, 6))
                users = list(user_access.keys())
                file_counts = list(user_access.values())
                
                sns.barplot(x=users, y=file_counts)
                plt.title('用户访问文件数量')
                plt.xlabel('用户')
                plt.ylabel('文件数量')
                plt.xticks(rotation=45)
                plt.tight_layout()
                plt.savefig(os.path.join(output_dir, 'user_access_files.png'))
                plt.close()
                logger.info('用户访问权限可视化完成')
    
    def case_analysis(self, data_dir, rules_dir, output_dir):
        """案例分析
        
        Args:
            data_dir (str): 数据目录
            rules_dir (str): 规则目录
            output_dir (str): 输出目录
        """
        # 加载关联规则
        rules_file = os.path.join(rules_dir, 'association_rules.json')
        if os.path.exists(rules_file):
            with open(rules_file, 'r', encoding='utf-8') as f:
                rules_data = json.load(f)
            
            rules = rules_data.get('rules', [])
            
            # 分析质量等级与设备参数的关系
            quality_file = os.path.join(data_dir, 'quality_data.csv')
            device_file = os.path.join(data_dir, 'device_data.csv')
            
            if os.path.exists(quality_file) and os.path.exists(device_file):
                quality_data = pd.read_csv(quality_file, encoding='utf-8')
                device_data = pd.read_csv(device_file, encoding='utf-8')
                
                # 合并数据
                merged_data = pd.merge(
                    device_data, 
                    quality_data, 
                    on=['timestamp', 'device_id'], 
                    how='inner'
                )
                
                # 分析设备参数与质量等级的关系
                plt.figure(figsize=(15, 10))
                parameters = ['温度', '压力', '转速', '电流', '电压']
                
                for i, param in enumerate(parameters):
                    if param in merged_data.columns:
                        plt.subplot(2, 3, i+1)
                        sns.boxplot(x='quality_level', y=param, data=merged_data, order=['A', 'B', 'C'])
                        plt.title(f'{param}与质量等级的关系')
                        plt.xlabel('质量等级')
                        plt.ylabel(param)
                
                plt.tight_layout()
                plt.savefig(os.path.join(output_dir, 'device_params_vs_quality.png'))
                plt.close()
                logger.info('设备参数与质量等级关系分析完成')
    
    def visualize(self, input_dir, output_dir):
        """数据可视化
        
        Args:
            input_dir (str): 输入数据目录
            output_dir (str): 输出目录
        """
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        
        # 可视化数据分布
        self.visualize_data_distribution(input_dir, output_dir)
        
        # 可视化关联规则
        self.visualize_association_rules(input_dir, output_dir)
        
        # 可视化安全共享结果
        shared_dir = 'shared_data'
        if os.path.exists(shared_dir):
            self.visualize_security_sharing(shared_dir, output_dir)
        
        # 案例分析
        self.case_analysis(input_dir, input_dir, output_dir)
        
        logger.info(f'数据可视化完成，结果保存到 {output_dir} 目录')
