#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
制造企业工业数据空间环境下的数据分析与共享系统测试脚本

功能：测试系统的各个功能模块是否正常工作
"""

import os
import sys
import unittest
import shutil
from datetime import datetime

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from modules.data_generator import DataGenerator
from modules.data_classifier import DataClassifier
from modules.association_miner import AssociationMiner
from modules.security_sharing import SecuritySharing
from modules.visualization import Visualization

class TestManufacturingAnalysis(unittest.TestCase):
    """制造企业工业数据分析与共享系统测试"""
    
    def setUp(self):
        """设置测试环境"""
        self.test_dir = f'test_{datetime.now().strftime("%Y%m%d_%H%M%S")}'
        os.makedirs(self.test_dir, exist_ok=True)
        self.test_data_dir = os.path.join(self.test_dir, 'data')
        self.test_classified_dir = os.path.join(self.test_dir, 'classified_data')
        self.test_rules_dir = os.path.join(self.test_dir, 'rules')
        self.test_visualization_dir = os.path.join(self.test_dir, 'visualization')
    
    def tearDown(self):
        """清理测试环境"""
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)
        # 清理共享数据目录
        if os.path.exists('shared_data'):
            shutil.rmtree('shared_data')
        # 清理访问日志目录
        if os.path.exists('access_logs'):
            shutil.rmtree('access_logs')
    
    def test_data_generator(self):
        """测试数据生成模块"""
        print("测试数据生成模块...")
        generator = DataGenerator()
        generator.generate_data(100, 2, self.test_data_dir)
        
        # 验证生成的数据文件
        expected_files = ['device_data.csv', 'process_data.csv', 'quality_data.csv', 'unstructured_data.json']
        for file_name in expected_files:
            file_path = os.path.join(self.test_data_dir, file_name)
            self.assertTrue(os.path.exists(file_path), f"文件 {file_name} 未生成")
        print("数据生成模块测试通过")
    
    def test_data_classifier(self):
        """测试数据分类与建模模块"""
        print("测试数据分类与建模模块...")
        # 先生成测试数据
        generator = DataGenerator()
        generator.generate_data(100, 2, self.test_data_dir)
        
        # 测试分类功能
        classifier = DataClassifier()
        classifier.classify_data(self.test_data_dir, self.test_classified_dir)
        
        # 验证分类结果
        expected_files = ['device_data.csv', 'process_data.csv', 'quality_data.csv', 'unstructured_data.csv']
        expected_model_files = ['device_model.json', 'process_model.json', 'quality_model.json', 'unstructured_model.json', 'unified_model.json']
        
        for file_name in expected_files:
            file_path = os.path.join(self.test_classified_dir, file_name)
            self.assertTrue(os.path.exists(file_path), f"文件 {file_name} 未分类")
        
        for file_name in expected_model_files:
            file_path = os.path.join(self.test_classified_dir, file_name)
            self.assertTrue(os.path.exists(file_path), f"模型文件 {file_name} 未生成")
        print("数据分类与建模模块测试通过")
    
    def test_association_miner(self):
        """测试关联规则挖掘模块"""
        print("测试关联规则挖掘模块...")
        # 先生成测试数据
        generator = DataGenerator()
        generator.generate_data(500, 3, self.test_data_dir)
        
        # 分类数据
        classifier = DataClassifier()
        classifier.classify_data(self.test_data_dir, self.test_classified_dir)
        
        # 测试关联规则挖掘
        miner = AssociationMiner()
        miner.mine_rules(self.test_classified_dir, self.test_rules_dir, 0.1, 0.5)
        
        # 验证挖掘结果
        expected_files = ['association_rules.json', 'top_rules.csv']
        for file_name in expected_files:
            file_path = os.path.join(self.test_rules_dir, file_name)
            self.assertTrue(os.path.exists(file_path), f"文件 {file_name} 未生成")
        print("关联规则挖掘模块测试通过")
    
    def test_security_sharing(self):
        """测试数据安全共享模块"""
        print("测试数据安全共享模块...")
        # 先生成测试数据
        generator = DataGenerator()
        generator.generate_data(100, 2, self.test_data_dir)
        
        # 分类数据
        classifier = DataClassifier()
        classifier.classify_data(self.test_data_dir, self.test_classified_dir)
        
        # 测试安全共享
        security = SecuritySharing()
        test_users = ['admin_test', 'engineer_test', 'operator_test', 'analyst_test']
        
        for user in test_users:
            security.share_data(self.test_classified_dir, 'policies.json', user)
            # 验证共享结果
            share_dir = os.path.join('shared_data', user)
            self.assertTrue(os.path.exists(share_dir), f"用户 {user} 的共享目录未创建")
        print("数据安全共享模块测试通过")
    
    def test_visualization(self):
        """测试验证与可视化模块"""
        print("测试验证与可视化模块...")
        # 先生成测试数据
        generator = DataGenerator()
        generator.generate_data(500, 3, self.test_data_dir)
        
        # 分类数据
        classifier = DataClassifier()
        classifier.classify_data(self.test_data_dir, self.test_classified_dir)
        
        # 挖掘关联规则
        miner = AssociationMiner()
        miner.mine_rules(self.test_classified_dir, self.test_rules_dir, 0.1, 0.5)
        
        # 测试可视化
        viz = Visualization()
        viz.visualize(self.test_rules_dir, self.test_visualization_dir)
        
        # 验证可视化结果
        self.assertTrue(os.path.exists(self.test_visualization_dir), "可视化结果目录未创建")
        print("验证与可视化模块测试通过")
    
    def test_full_pipeline(self):
        """测试完整流程"""
        print("测试完整流程...")
        # 测试完整流程
        import subprocess
        result = subprocess.run([sys.executable, 'manufacturing_data_analysis.py', 'pipeline', '--size', '200'], 
                              capture_output=True, text=True)
        
        # 验证流程执行成功
        self.assertEqual(result.returncode, 0, f"完整流程执行失败: {result.stderr}")
        
        # 验证生成的目录
        expected_dirs = ['data', 'classified_data', 'rules', 'visualization']
        for dir_name in expected_dirs:
            self.assertTrue(os.path.exists(dir_name), f"目录 {dir_name} 未创建")
        
        # 清理生成的目录
        for dir_name in expected_dirs:
            if os.path.exists(dir_name):
                shutil.rmtree(dir_name)
        print("完整流程测试通过")

if __name__ == '__main__':
    unittest.main()
