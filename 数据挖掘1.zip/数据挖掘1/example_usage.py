#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
制造企业工业数据空间环境下的数据分析与共享系统使用示例

功能：展示系统的基本使用方法
"""

import os
import sys
import shutil

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def main():
    """主函数"""
    print("制造企业工业数据空间环境下的数据分析与共享系统使用示例")
    print("=" * 80)
    
    # 清理之前的结果
    clean_directories()
    
    # 1. 生成数据
    print("\n1. 分析制造数据...")
    os.system('python manufacturing_data_analysis.py generate --size 1000 --devices 5 --output data')
    
    # 2. 分类数据
    print("\n2. 对制造数据进行分类...")
    os.system('python manufacturing_data_analysis.py classify --input data --output classified_data')
    
    # 3. 挖掘关联规则
    print("\n3. 挖掘关联规则...")
    os.system('python manufacturing_data_analysis.py mine --input classified_data --output rules --min-support 0.1 --min-confidence 0.5')
    
    # 4. 数据安全共享
    print("\n4. 数据安全共享...")
    test_users = ['admin_test', 'engineer_test', 'operator_test', 'analyst_test']
    for user in test_users:
        print(f"   共享数据给用户: {user}")
        os.system(f'python manufacturing_data_analysis.py share --input classified_data --policy policies.json --user {user}')
    
    # 5. 数据可视化
    print("\n5. 数据和分析结果可视化...")
    os.system('python manufacturing_data_analysis.py visualize --input rules --output visualization')
    
    # 6. 执行完整流程
    print("\n6. 执行完整分析流程...")
    os.system('python manufacturing_data_analysis.py pipeline --size 500')
    
    print("\n" + "=" * 80)
    print("使用示例执行完成！")
    print("\n生成的结果目录：")
    print("- data: 原始数据")
    print("- classified_data: 分类后的数据和模型")
    print("- rules: 挖掘的关联规则")
    print("- visualization: 可视化结果")
    print("- shared_data: 安全共享的数据")
    print("- access_logs: 访问日志")

def clean_directories():
    """清理之前的结果目录"""
    directories = ['data', 'classified_data', 'rules', 'visualization', 'shared_data', 'access_logs']
    for directory in directories:
        if os.path.exists(directory):
            shutil.rmtree(directory)
            print(f"清理目录: {directory}")

if __name__ == '__main__':
    main()
