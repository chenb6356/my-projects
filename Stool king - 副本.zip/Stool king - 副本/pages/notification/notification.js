const app = getApp()

const notificationPage = {
  data: {
    records: [],
    currentDate: ''
  },

  onLoad() {
    this.loadRecords()
    this.setCurrentDate()
  },

  onShow() {
    this.loadRecords()
  },

  setCurrentDate() {
    const now = new Date()
    const year = now.getFullYear()
    const month = String(now.getMonth() + 1).padStart(2, '0')
    const day = String(now.getDate()).padStart(2, '0')
    this.setData({
      currentDate: `${year}年${month}月${day}日`
    })
  },

  loadRecords() {
    if (app.globalData && app.globalData.records) {
      const records = [...app.globalData.records].sort((a, b) => {
        return new Date(b.date) - new Date(a.date)
      })
      this.setData({ records })
    }
  },

  formatDate(date) {
    if (!date) return ''
    const d = new Date(date)
    const year = d.getFullYear()
    const month = String(d.getMonth() + 1).padStart(2, '0')
    const day = String(d.getDate()).padStart(2, '0')
    const hours = String(d.getHours()).padStart(2, '0')
    const minutes = String(d.getMinutes()).padStart(2, '0')
    return `${year}/${month}/${day} ${hours}:${minutes}`
  },

  getHealthTip(content) {
    if (!content) return ''
    const tips = []
    if (content.includes('💩💩💩')) {
      tips.push('宝宝你一泻千里！棒棒哒！')
    } else if (content.includes('💩💩')) {
      tips.push('今天量还可以，继续保持！')
    } else if (content.includes('💩')) {
      tips.push('今天量少，多吃蔬菜和饭饭！')
    }
    if (content.includes('🤢')) tips.push('今天有点臭哟~')
    if (content.includes('🔥')) tips.push('上火了~多喝水！')
    if (content.includes('💧')) tips.push('小心别吃坏肚子啦！')
    return tips.join(' ')
  }
}

Page(notificationPage) 