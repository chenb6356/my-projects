const contactPage = {
  data: {
    contactText: `此小程序为个人研发，有建议请反馈至DY等平台，有缘分的话，刷到我就采取了你的建议，谢谢。

有实力的可以打赏打赏，开发不易...`
  },

  onLoad() {
    // 页面加载时的逻辑
  }
}

Page(contactPage) 