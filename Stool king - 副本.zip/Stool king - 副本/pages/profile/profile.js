// 获取应用实例
const app = getApp()

const profilePage = {
  data: {
    userInfo: null,
    isLoggedIn: false,
    todayRecord: null,
    hasUserInfo: false,
    tempUserInfo: {
      avatarUrl: '',
      nickName: ''
    }
  },

  onLoad() {
    // 检查是否已经登录
    const userInfo = wx.getStorageSync('userInfo')
    if (userInfo) {
      this.setData({
        userInfo: userInfo,
        isLoggedIn: true,
        hasUserInfo: true
      })
    } else {
      // 确保未登录状态下的数据正确
      this.setData({
        userInfo: null,
        isLoggedIn: false,
        hasUserInfo: false
      })
    }
  },

  onShow() {
    // 获取今日记录
    const today = new Date()
    const records = app.globalData.records || []
    const todayRecord = records.find(record => {
      const recordDate = new Date(record.date)
      return recordDate.toDateString() === today.toDateString()
    }) || null  // 如果没找到记录，设置为 null 而不是 undefined
    
    this.setData({
      todayRecord: todayRecord
    })
  },

  onChooseAvatar(e) {
    const { avatarUrl } = e.detail 
    this.setData({
      'tempUserInfo.avatarUrl': avatarUrl
    })
  },

  onInputNickname(e) {
    const nickName = e.detail.value
    this.setData({
      'tempUserInfo.nickName': nickName
    })
  },

  handleLogin() {
    const { avatarUrl, nickName } = this.data.tempUserInfo
    if (!avatarUrl || !nickName) {
      wx.showToast({
        title: '请选择头像并输入昵称',
        icon: 'none'
      })
      return
    }

    wx.login({
      success: (loginRes) => {
        if (loginRes.code) {
          const userInfo = {
            avatarUrl,
            nickName
          }
          this.setData({
            userInfo,
            isLoggedIn: true,
            hasUserInfo: true
          })
          // 保存用户信息
          wx.setStorageSync('userInfo', userInfo)
          wx.showToast({
            title: '登录成功',
            icon: 'success'
          })
        }
      },
      fail: (err) => {
        console.log("登录失败", err)
        wx.showToast({
          title: '登录失败',
          icon: 'none'
        })
      }
    })
  },

  chooseAvatar() {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const userInfo = this.data.userInfo || {}
        userInfo.avatarUrl = res.tempFilePaths[0]
        this.setData({ userInfo })
        this.saveUserInfo()
      }
    })
  },

  onNameChange(e) {
    const userInfo = this.data.userInfo || {}
    userInfo.nickName = e.detail.value
    this.setData({ userInfo })
  },

  onSignatureChange(e) {
    const userInfo = this.data.userInfo || {}
    userInfo.signature = e.detail.value
    this.setData({ userInfo })
  },

  saveUserInfo() {
    app.globalData.userInfo = this.data.userInfo
    wx.setStorageSync('userInfo', this.data.userInfo)
  },

  getHealthTip(content) {
    if (!content) return ''
    const tips = []
    if (content.includes('💩💩💩')) tips.push('宝宝你一泻千里！棒棒哒！')
    else if (content.includes('💩💩')) tips.push('今天量还可以，继续保持！')
    else if (content.includes('💩')) tips.push('今天量少，多吃蔬菜和饭饭！')
    if (content.includes('🤢')) tips.push('今天有点臭哟~')
    if (content.includes('🔥')) tips.push('上火了~多喝水！')
    if (content.includes('💧')) tips.push('小心别吃坏肚子啦！')
    return tips.join(' ')
  },

  goToNotification() {
    wx.navigateTo({ url: '/pages/notification/notification' })
  },

  goToPrivacy() {
    wx.navigateTo({ url: '/pages/privacy/privacy' })
  },

  goToContact() {
    wx.navigateTo({ url: '/pages/contact/contact' })
  }
}

Page(profilePage)

