const recordPage = {
  data: {
    year: new Date().getFullYear(),
    month: new Date().getMonth() + 1,
    days: [],
    selectedDate: '',
    selectedRecord: null,
    isModalOpen: false,
    records: [],
    calendarConfig: {
      theme: 'default',
      width: '90%',         // 增加日历宽度
      height: '650rpx',    // 增加日历高度
      dateStyle: {
        width: '90rpx',    // 增加日期格子的宽度
        height: '90rpx',   // 增加日期格子的高度
        fontSize: '32rpx'  // 增加日期文字大小
      }
    }
  },

  onLoad() {
    this.generateCalendar()
  },

  onShow() {
    // 从全局数据获取记录并排序
    const records = getApp().globalData.records.sort((a, b) => {
      return new Date(b.date) - new Date(a.date)
    })
    
    // 更新页面数据
    this.setData({ records })
    
    // 重新生成日历
    this.generateCalendar()
  },

  // 生成日历数据
  generateCalendar() {
    const { year, month } = this.data
    const days = []
    
    // 获取当月第一天是星期几
    const firstDay = new Date(year, month - 1, 1).getDay()
    // 获取当月天数
    const daysInMonth = new Date(year, month, 0).getDate()
    // 获取上月天数
    const daysInPrevMonth = new Date(year, month - 1, 0).getDate()
    
    // 添加上月末尾的日期
    for (let i = firstDay - 1; i >= 0; i--) {
      days.push({
        day: daysInPrevMonth - i,
        current: false,
        fullDate: `${month === 1 ? year - 1 : year}-${month === 1 ? 12 : month - 1}-${daysInPrevMonth - i}`
      })
    }
    
    // 添加当月日期
    const today = new Date()
    const isCurrentMonth = today.getFullYear() === year && today.getMonth() + 1 === month
    
    for (let i = 1; i <= daysInMonth; i++) {
      const fullDate = `${year}-${month}-${i}`
      days.push({
        day: i,
        current: true,
        isToday: isCurrentMonth && today.getDate() === i,
        fullDate,
        hasRecord: this.checkHasRecord(fullDate)
      })
    }
    
    // 添加下月开头的日期
    const remainingDays = 42 - days.length // 保持6行
    for (let i = 1; i <= remainingDays; i++) {
      days.push({
        day: i,
        current: false,
        fullDate: `${month === 12 ? year + 1 : year}-${month === 12 ? 1 : month + 1}-${i}`
      })
    }
    
    this.setData({ days })
  },

  // 检查某天是否有记录
  checkHasRecord(date) {
    const records = getApp().globalData.records
    return records.some(record => {
      const recordDate = new Date(record.date)
      const checkDate = new Date(date)
      return recordDate.toDateString() === checkDate.toDateString()
    })
  },

  // 选择日期
  selectDate(e) {
    const date = e.currentTarget.dataset.date
    const recordContent = this.getRecordContent(date)
    // 只有当有记录时才显示弹窗
    if (recordContent) {
      this.setData({
        selectedDate: date,
        isModalOpen: true,
        selectedRecord: {
          content: recordContent,
          date: date
        }
      })
    }
  },

  // 获取选中日期的记录内容
  getRecordContent(date) {
    const records = getApp().globalData.records
    const record = records.find(r => {
      const recordDate = new Date(r.date)
      const checkDate = new Date(date)
      return recordDate.toDateString() === checkDate.toDateString()
    })
    return record ? record.content : ''
  },

  // 上个月
  prevMonth() {
    let { year, month } = this.data
    if (month === 1) {
      year--
      month = 12
    } else {
      month--
    }
    this.setData({ year, month }, () => {
      this.generateCalendar()
    })
  },

  // 下个月
  nextMonth() {
    let { year, month } = this.data
    if (month === 12) {
      year++
      month = 1
    } else {
      month++
    }
    this.setData({ year, month }, () => {
      this.generateCalendar()
    })
  },

  showRecordDetail(e) {
    const index = e.currentTarget.dataset.index
    const record = this.data.records[index]
    
    // 设置选中的记录和日期
    this.setData({
      selectedDate: this.formatDate(record.date),  // 格式化日期显示
      selectedRecord: record,  // 保存选中的记录
      isModalOpen: true
    })
  },
  hideModal() {
    this.setData({ isModalOpen: false })
  },
  getHealthTip(content) {
    const tips = []
    
    // 先判断💩的数量
    if (content.includes('💩💩💩')) {
      tips.push('宝宝你一泻千里！棒棒哒！')
    } else if (content.includes('💩💩')) {
      tips.push('今天量还可以，继续保持！')
    } else if (content.includes('💩')) {
      tips.push('今天量少，多吃蔬菜和饭饭！')
    }
    
    // 其他表情的提示词
    if (content.includes('🤢')) tips.push('今天有点臭哟~')
    if (content.includes('🔥')) tips.push('上火了~多喝水！')
    if (content.includes('💧')) tips.push('小心别吃坏肚子啦！')
    
    return tips.join(' ')
  },
  stopPropagation() {
    // 阻止事件冒泡
  },
  // 格式化日期显示
  formatDate(date) {
    const d = new Date(date)
    const year = d.getFullYear()
    const month = String(d.getMonth() + 1).padStart(2, '0')
    const day = String(d.getDate()).padStart(2, '0')
    const hours = String(d.getHours()).padStart(2, '0')
    const minutes = String(d.getMinutes()).padStart(2, '0')
    return `${year}/${month}/${day} ${hours}:${minutes}`
  }
}

Page(recordPage)

