const indexPage = {
  data: {
    isModalOpen: false,
    inputText: ''
  },
  showModal() {
    this.setData({ isModalOpen: true })
  },
  hideModal() {
    this.setData({ isModalOpen: false, inputText: '' })
  },
  stopPropagation() {
    // 阻止事件冒泡
  },
  inputChange(e) {
    this.setData({ inputText: e.detail.value })
  },
  addEmoji(e) {
    const emoji = e.currentTarget.dataset.emoji
    this.setData({
      inputText: this.data.inputText + emoji
    })
  },
  submitRecord() {
    if (this.data.inputText.trim()) {
      const now = new Date()
      const newRecord = {
        date: now,  // 保存当前时间
        content: this.data.inputText,  // 保存输入的内容
        tips: this.getHealthTip(this.data.inputText)  // 保存对应的提示词
      }
      
      // 获取全局数据
      const app = getApp()
      const records = app.globalData.records
      
      // 添加新记录
      records.push(newRecord)
      
      // 更新全局数据并保存到本地存储
      app.globalData.records = records
      wx.setStorageSync('records', records)
      
      this.hideModal()
      wx.showToast({
        title: '记录成功',
        icon: 'success'
      })
    } else {
      wx.showToast({
        title: '请输入内容',
        icon: 'none'
      })
    }
  },
  // 添加获取提示词的方法
  getHealthTip(content) {
    const tips = []
    
    // 先判断💩的数量
    if (content.includes('💩💩💩')) {
      tips.push('宝宝你一泻千里！棒棒哒！')
    } else if (content.includes('💩💩')) {
      tips.push('今天量还可以，继续保持！')
    } else if (content.includes('💩')) {
      tips.push('今天量少，多吃蔬菜和饭饭！')
    }
    
    // 其他表情的提示词
    if (content.includes('🤢')) tips.push('今天有点臭哟~')
    if (content.includes('🔥')) tips.push('上火了~多喝水！')
    if (content.includes('💧')) tips.push('小心别吃坏肚子啦！')
    
    return tips.join(' ')
  }
}

Page(indexPage)

