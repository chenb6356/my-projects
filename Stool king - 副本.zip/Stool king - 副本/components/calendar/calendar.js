const calendar = {
  properties: {
    markedDates: {
      type: Array,
      value: []
    },
    selectedDate: {
      type: null,
      value: null
    }
  },

  data: {
    days: [],
    currentYear: new Date().getFullYear(),
    currentMonth: new Date().getMonth() + 1
  },

  lifetimes: {
    attached() {
      this.generateCalendar()
    }
  },

  methods: {
    generateCalendar() {
      const days = []
      const firstDay = new Date(this.data.currentYear, this.data.currentMonth - 1, 1).getDay()
      const daysInMonth = new Date(this.data.currentYear, this.data.currentMonth, 0).getDate()

      for (let i = 1; i <= daysInMonth; i++) {
        const date = new Date(this.data.currentYear, this.data.currentMonth - 1, i)
        days.push({
          day: i,
          isMarked: this.isDateMarked(date),
          date: date
        })
      }

      this.setData({ days })
    },

    isDateMarked(date) {
      return this.data.markedDates.some(markedDate => 
        new Date(markedDate).toDateString() === date.toDateString()
      )
    },

    onDateClick(e) {
      const { date } = e.currentTarget.dataset
      this.triggerEvent('dateclick', { date })
    }
  }
}

Component(calendar) 