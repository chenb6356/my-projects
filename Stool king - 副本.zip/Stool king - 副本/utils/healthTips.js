const healthTips = {
  getHealthTip(content) {
    const tips = [];

    if (content.includes('💩💩💩')) {
      tips.push('宝宝你一泻千里！棒棒哒！');
    } else if (content.includes('💩💩')) {
      tips.push('今天量还可以，继续保持！');
    } else if (content.includes('💩')) {
      tips.push('今天量少，多吃蔬菜和饭饭！');
    }
    
    if (content.includes('🤢')) tips.push('今天有点臭哟~');
    if (content.includes('🔥')) tips.push('上火了~多喝水！');
    if (content.includes('💧')) tips.push('小心别吃坏肚子啦！');
    
    return tips.join(' ');
  }
}

module.exports = healthTips 