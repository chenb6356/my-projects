const app = {
  globalData: {
    userInfo: null,
    records: []
  },

  onLaunch() {
    // 清除用户登录信息
    wx.removeStorageSync('userInfo')
    this.globalData.userInfo = null
    
    // 只在真机环境下调用 getABTestConfig
    if (!wx.getSystemInfoSync().platform.includes('devtools')) {
      wx.getABTestConfig({
        complete: (res) => {
          // 忽略错误，不做任何处理
        }
      })
    }

    // 从本地存储获取记录
    const records = wx.getStorageSync('records')
    if (records) {
      this.globalData.records = records
    }
  },

  // 添加记录
  addRecord(content) {
    const newRecord = {
      date: new Date(),
      content: content
    }
    this.globalData.records.push(newRecord)
    wx.setStorageSync('records', this.globalData.records)
  },

  // 获取今日记录
  getTodayRecord() {
    const today = new Date().toDateString()
    return this.globalData.records.find(
      record => new Date(record.date).toDateString() === today
    )
  }
}

App(app)

